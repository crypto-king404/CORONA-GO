// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.button;

import java.util.Comparator;

// Referenced classes of package com.google.android.material.button:
//            MaterialButtonToggleGroup, MaterialButton

class this._cls0
    implements Comparator
{

    final MaterialButtonToggleGroup this$0;

    public int compare(MaterialButton materialbutton, MaterialButton materialbutton1)
    {
        int i = Boolean.valueOf(materialbutton.isChecked()).compareTo(Boolean.valueOf(materialbutton1.isChecked()));
        if (i != 0)
        {
            return i;
        }
        i = Boolean.valueOf(materialbutton.isPressed()).compareTo(Boolean.valueOf(materialbutton1.isPressed()));
        if (i != 0)
        {
            return i;
        } else
        {
            return Integer.valueOf(indexOfChild(materialbutton)).compareTo(Integer.valueOf(indexOfChild(materialbutton1)));
        }
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((MaterialButton)obj, (MaterialButton)obj1);
    }

    ()
    {
        this$0 = MaterialButtonToggleGroup.this;
        super();
    }
}
