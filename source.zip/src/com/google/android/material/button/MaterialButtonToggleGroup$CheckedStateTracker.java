// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.button;


// Referenced classes of package com.google.android.material.button:
//            MaterialButtonToggleGroup, MaterialButton

private class <init>
    implements <init>
{

    final MaterialButtonToggleGroup this$0;

    public void onCheckedChanged(MaterialButton materialbutton, boolean flag)
    {
        if (MaterialButtonToggleGroup.access$300(MaterialButtonToggleGroup.this))
        {
            return;
        }
        if (MaterialButtonToggleGroup.access$400(MaterialButtonToggleGroup.this))
        {
            MaterialButtonToggleGroup materialbuttontogglegroup = MaterialButtonToggleGroup.this;
            int i;
            if (flag)
            {
                i = materialbutton.getId();
            } else
            {
                i = -1;
            }
            MaterialButtonToggleGroup.access$502(materialbuttontogglegroup, i);
        }
        if (MaterialButtonToggleGroup.access$600(MaterialButtonToggleGroup.this, materialbutton.getId(), flag))
        {
            MaterialButtonToggleGroup.access$700(MaterialButtonToggleGroup.this, materialbutton.getId(), materialbutton.isChecked());
        }
        invalidate();
    }

    private ()
    {
        this$0 = MaterialButtonToggleGroup.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
