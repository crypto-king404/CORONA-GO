// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.button;

import android.view.View;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;

// Referenced classes of package com.google.android.material.button:
//            MaterialButtonToggleGroup, MaterialButton

class this._cls0 extends AccessibilityDelegateCompat
{

    final MaterialButtonToggleGroup this$0;

    public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilitynodeinfocompat)
    {
        super.onInitializeAccessibilityNodeInfo(view, accessibilitynodeinfocompat);
        accessibilitynodeinfocompat.setCollectionItemInfo(androidx.core.view.accessibility.CollectionItemInfoCompat.obtain(0, 1, MaterialButtonToggleGroup.access$200(MaterialButtonToggleGroup.this, view), 1, false, ((MaterialButton)view).isChecked()));
    }

    llectionItemInfoCompat()
    {
        this$0 = MaterialButtonToggleGroup.this;
        super();
    }
}
