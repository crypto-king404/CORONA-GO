// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.button;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.MarginLayoutParamsCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import com.google.android.material.internal.ThemeEnforcement;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.shape.AbsoluteCornerSize;
import com.google.android.material.shape.CornerSize;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.theme.overlay.MaterialThemeOverlay;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

// Referenced classes of package com.google.android.material.button:
//            MaterialButton

public class MaterialButtonToggleGroup extends LinearLayout
{
    private class CheckedStateTracker
        implements MaterialButton.OnCheckedChangeListener
    {

        final MaterialButtonToggleGroup this$0;

        public void onCheckedChanged(MaterialButton materialbutton, boolean flag)
        {
            if (skipCheckedStateTracker)
            {
                return;
            }
            if (singleSelection)
            {
                MaterialButtonToggleGroup materialbuttontogglegroup = MaterialButtonToggleGroup.this;
                int i;
                if (flag)
                {
                    i = materialbutton.getId();
                } else
                {
                    i = -1;
                }
                materialbuttontogglegroup.checkedId = i;
            }
            if (updateCheckedStates(materialbutton.getId(), flag))
            {
                dispatchOnButtonChecked(materialbutton.getId(), materialbutton.isChecked());
            }
            invalidate();
        }

        private CheckedStateTracker()
        {
            this$0 = MaterialButtonToggleGroup.this;
            super();
        }

    }

    private static class CornerData
    {

        private static final CornerSize noCorner = new AbsoluteCornerSize(0.0F);
        CornerSize bottomLeft;
        CornerSize bottomRight;
        CornerSize topLeft;
        CornerSize topRight;

        public static CornerData bottom(CornerData cornerdata)
        {
            CornerSize cornersize = noCorner;
            return new CornerData(cornersize, cornerdata.bottomLeft, cornersize, cornerdata.bottomRight);
        }

        public static CornerData end(CornerData cornerdata, View view)
        {
            if (ViewUtils.isLayoutRtl(view))
            {
                return left(cornerdata);
            } else
            {
                return right(cornerdata);
            }
        }

        public static CornerData left(CornerData cornerdata)
        {
            CornerSize cornersize = cornerdata.topLeft;
            cornerdata = cornerdata.bottomLeft;
            CornerSize cornersize1 = noCorner;
            return new CornerData(cornersize, cornerdata, cornersize1, cornersize1);
        }

        public static CornerData right(CornerData cornerdata)
        {
            CornerSize cornersize = noCorner;
            return new CornerData(cornersize, cornersize, cornerdata.topRight, cornerdata.bottomRight);
        }

        public static CornerData start(CornerData cornerdata, View view)
        {
            if (ViewUtils.isLayoutRtl(view))
            {
                return right(cornerdata);
            } else
            {
                return left(cornerdata);
            }
        }

        public static CornerData top(CornerData cornerdata)
        {
            CornerSize cornersize = cornerdata.topLeft;
            CornerSize cornersize1 = noCorner;
            return new CornerData(cornersize, cornersize1, cornerdata.topRight, cornersize1);
        }


        CornerData(CornerSize cornersize, CornerSize cornersize1, CornerSize cornersize2, CornerSize cornersize3)
        {
            topLeft = cornersize;
            topRight = cornersize2;
            bottomRight = cornersize3;
            bottomLeft = cornersize1;
        }
    }

    public static interface OnButtonCheckedListener
    {

        public abstract void onButtonChecked(MaterialButtonToggleGroup materialbuttontogglegroup, int i, boolean flag);
    }

    private class PressedStateTracker
        implements MaterialButton.OnPressedChangeListener
    {

        final MaterialButtonToggleGroup this$0;

        public void onPressedChanged(MaterialButton materialbutton, boolean flag)
        {
            invalidate();
        }

        private PressedStateTracker()
        {
            this$0 = MaterialButtonToggleGroup.this;
            super();
        }

    }


    private static final int DEF_STYLE_RES;
    private static final String LOG_TAG = com/google/android/material/button/MaterialButtonToggleGroup.getSimpleName();
    private int checkedId;
    private final CheckedStateTracker checkedStateTracker;
    private Integer childOrder[];
    private final Comparator childOrderComparator;
    private final LinkedHashSet onButtonCheckedListeners;
    private final List originalCornerData;
    private final PressedStateTracker pressedStateTracker;
    private boolean selectionRequired;
    private boolean singleSelection;
    private boolean skipCheckedStateTracker;

    public MaterialButtonToggleGroup(Context context)
    {
        this(context, null);
    }

    public MaterialButtonToggleGroup(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, com.google.android.material.R.attr.materialButtonToggleGroupStyle);
    }

    public MaterialButtonToggleGroup(Context context, AttributeSet attributeset, int i)
    {
        int j = DEF_STYLE_RES;
        super(MaterialThemeOverlay.wrap(context, attributeset, i, j), attributeset, i);
        originalCornerData = new ArrayList();
        checkedStateTracker = new CheckedStateTracker();
        pressedStateTracker = new PressedStateTracker();
        onButtonCheckedListeners = new LinkedHashSet();
        childOrderComparator = new Comparator() {

            final MaterialButtonToggleGroup this$0;

            public int compare(MaterialButton materialbutton, MaterialButton materialbutton1)
            {
                int k = Boolean.valueOf(materialbutton.isChecked()).compareTo(Boolean.valueOf(materialbutton1.isChecked()));
                if (k != 0)
                {
                    return k;
                }
                k = Boolean.valueOf(materialbutton.isPressed()).compareTo(Boolean.valueOf(materialbutton1.isPressed()));
                if (k != 0)
                {
                    return k;
                } else
                {
                    return Integer.valueOf(indexOfChild(materialbutton)).compareTo(Integer.valueOf(indexOfChild(materialbutton1)));
                }
            }

            public volatile int compare(Object obj, Object obj1)
            {
                return compare((MaterialButton)obj, (MaterialButton)obj1);
            }

            
            {
                this$0 = MaterialButtonToggleGroup.this;
                super();
            }
        };
        skipCheckedStateTracker = false;
        context = ThemeEnforcement.obtainStyledAttributes(getContext(), attributeset, com.google.android.material.R.styleable.MaterialButtonToggleGroup, i, j, new int[0]);
        setSingleSelection(context.getBoolean(com.google.android.material.R.styleable.MaterialButtonToggleGroup_singleSelection, false));
        checkedId = context.getResourceId(com.google.android.material.R.styleable.MaterialButtonToggleGroup_checkedButton, -1);
        selectionRequired = context.getBoolean(com.google.android.material.R.styleable.MaterialButtonToggleGroup_selectionRequired, false);
        setChildrenDrawingOrderEnabled(true);
        context.recycle();
        ViewCompat.setImportantForAccessibility(this, 1);
    }

    private void adjustChildMarginsAndUpdateLayout()
    {
        int j = getFirstVisibleChildIndex();
        if (j == -1)
        {
            return;
        }
        for (int i = j + 1; i < getChildCount(); i++)
        {
            MaterialButton materialbutton = getChildButton(i);
            Object obj = getChildButton(i - 1);
            int k = Math.min(materialbutton.getStrokeWidth(), ((MaterialButton) (obj)).getStrokeWidth());
            obj = buildLayoutParams(materialbutton);
            if (getOrientation() == 0)
            {
                MarginLayoutParamsCompat.setMarginEnd(((android.view.ViewGroup.MarginLayoutParams) (obj)), 0);
                MarginLayoutParamsCompat.setMarginStart(((android.view.ViewGroup.MarginLayoutParams) (obj)), -k);
            } else
            {
                obj.bottomMargin = 0;
                obj.topMargin = -k;
            }
            materialbutton.setLayoutParams(((android.view.ViewGroup.LayoutParams) (obj)));
        }

        resetChildMargins(j);
    }

    private android.widget.LinearLayout.LayoutParams buildLayoutParams(View view)
    {
        view = view.getLayoutParams();
        if (view instanceof android.widget.LinearLayout.LayoutParams)
        {
            return (android.widget.LinearLayout.LayoutParams)view;
        } else
        {
            return new android.widget.LinearLayout.LayoutParams(((android.view.ViewGroup.LayoutParams) (view)).width, ((android.view.ViewGroup.LayoutParams) (view)).height);
        }
    }

    private void checkForced(int i)
    {
        setCheckedStateForView(i, true);
        updateCheckedStates(i, true);
        setCheckedId(i);
    }

    private void dispatchOnButtonChecked(int i, boolean flag)
    {
        for (Iterator iterator = onButtonCheckedListeners.iterator(); iterator.hasNext(); ((OnButtonCheckedListener)iterator.next()).onButtonChecked(this, i, flag)) { }
    }

    private MaterialButton getChildButton(int i)
    {
        return (MaterialButton)getChildAt(i);
    }

    private int getFirstVisibleChildIndex()
    {
        int j = getChildCount();
        for (int i = 0; i < j; i++)
        {
            if (isChildVisible(i))
            {
                return i;
            }
        }

        return -1;
    }

    private int getIndexWithinVisibleButtons(View view)
    {
        if (!(view instanceof MaterialButton))
        {
            return -1;
        }
        int j = 0;
        for (int i = 0; i < getChildCount();)
        {
            if (getChildAt(i) == view)
            {
                return j;
            }
            int k = j;
            if (getChildAt(i) instanceof MaterialButton)
            {
                k = j;
                if (isChildVisible(i))
                {
                    k = j + 1;
                }
            }
            i++;
            j = k;
        }

        return -1;
    }

    private int getLastVisibleChildIndex()
    {
        for (int i = getChildCount() - 1; i >= 0; i--)
        {
            if (isChildVisible(i))
            {
                return i;
            }
        }

        return -1;
    }

    private CornerData getNewCornerData(int i, int j, int k)
    {
        CornerData cornerdata = (CornerData)originalCornerData.get(i);
        if (j == k)
        {
            return cornerdata;
        }
        boolean flag;
        if (getOrientation() == 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (i == j)
        {
            if (flag)
            {
                return CornerData.start(cornerdata, this);
            } else
            {
                return CornerData.top(cornerdata);
            }
        }
        if (i == k)
        {
            if (flag)
            {
                return CornerData.end(cornerdata, this);
            } else
            {
                return CornerData.bottom(cornerdata);
            }
        } else
        {
            return null;
        }
    }

    private int getVisibleButtonCount()
    {
        int j = 0;
        for (int i = 0; i < getChildCount();)
        {
            int k = j;
            if (getChildAt(i) instanceof MaterialButton)
            {
                k = j;
                if (isChildVisible(i))
                {
                    k = j + 1;
                }
            }
            i++;
            j = k;
        }

        return j;
    }

    private boolean isChildVisible(int i)
    {
        return getChildAt(i).getVisibility() != 8;
    }

    private void resetChildMargins(int i)
    {
        if (getChildCount() != 0)
        {
            if (i == -1)
            {
                return;
            }
            android.widget.LinearLayout.LayoutParams layoutparams = (android.widget.LinearLayout.LayoutParams)getChildButton(i).getLayoutParams();
            if (getOrientation() == 1)
            {
                layoutparams.topMargin = 0;
                layoutparams.bottomMargin = 0;
                return;
            } else
            {
                MarginLayoutParamsCompat.setMarginEnd(layoutparams, 0);
                MarginLayoutParamsCompat.setMarginStart(layoutparams, 0);
                layoutparams.leftMargin = 0;
                layoutparams.rightMargin = 0;
                return;
            }
        } else
        {
            return;
        }
    }

    private void setCheckedId(int i)
    {
        checkedId = i;
        dispatchOnButtonChecked(i, true);
    }

    private void setCheckedStateForView(int i, boolean flag)
    {
        View view = findViewById(i);
        if (view instanceof MaterialButton)
        {
            skipCheckedStateTracker = true;
            ((MaterialButton)view).setChecked(flag);
            skipCheckedStateTracker = false;
        }
    }

    private void setGeneratedIdIfNeeded(MaterialButton materialbutton)
    {
        if (materialbutton.getId() == -1)
        {
            materialbutton.setId(ViewCompat.generateViewId());
        }
    }

    private void setupButtonChild(MaterialButton materialbutton)
    {
        materialbutton.setMaxLines(1);
        materialbutton.setEllipsize(android.text.TextUtils.TruncateAt.END);
        materialbutton.setCheckable(true);
        materialbutton.addOnCheckedChangeListener(checkedStateTracker);
        materialbutton.setOnPressedChangeListenerInternal(pressedStateTracker);
        materialbutton.setShouldDrawSurfaceColorStroke(true);
    }

    private static void updateBuilderWithCornerData(com.google.android.material.shape.ShapeAppearanceModel.Builder builder, CornerData cornerdata)
    {
        if (cornerdata == null)
        {
            builder.setAllCornerSizes(0.0F);
            return;
        } else
        {
            builder.setTopLeftCornerSize(cornerdata.topLeft).setBottomLeftCornerSize(cornerdata.bottomLeft).setTopRightCornerSize(cornerdata.topRight).setBottomRightCornerSize(cornerdata.bottomRight);
            return;
        }
    }

    private boolean updateCheckedStates(int i, boolean flag)
    {
        Object obj = getCheckedButtonIds();
        if (selectionRequired && ((List) (obj)).isEmpty())
        {
            setCheckedStateForView(i, true);
            checkedId = i;
            return false;
        }
        if (flag && singleSelection)
        {
            ((List) (obj)).remove(Integer.valueOf(i));
            for (obj = ((List) (obj)).iterator(); ((Iterator) (obj)).hasNext(); dispatchOnButtonChecked(i, false))
            {
                i = ((Integer)((Iterator) (obj)).next()).intValue();
                setCheckedStateForView(i, false);
            }

        }
        return true;
    }

    private void updateChildOrder()
    {
        TreeMap treemap = new TreeMap(childOrderComparator);
        int j = getChildCount();
        for (int i = 0; i < j; i++)
        {
            treemap.put(getChildButton(i), Integer.valueOf(i));
        }

        childOrder = (Integer[])treemap.values().toArray(new Integer[0]);
    }

    public void addOnButtonCheckedListener(OnButtonCheckedListener onbuttoncheckedlistener)
    {
        onButtonCheckedListeners.add(onbuttoncheckedlistener);
    }

    public void addView(View view, int i, android.view.ViewGroup.LayoutParams layoutparams)
    {
        if (!(view instanceof MaterialButton))
        {
            Log.e(LOG_TAG, "Child views must be of type MaterialButton.");
            return;
        }
        super.addView(view, i, layoutparams);
        view = (MaterialButton)view;
        setGeneratedIdIfNeeded(view);
        setupButtonChild(view);
        if (view.isChecked())
        {
            updateCheckedStates(view.getId(), true);
            setCheckedId(view.getId());
        }
        layoutparams = view.getShapeAppearanceModel();
        originalCornerData.add(new CornerData(layoutparams.getTopLeftCornerSize(), layoutparams.getBottomLeftCornerSize(), layoutparams.getTopRightCornerSize(), layoutparams.getBottomRightCornerSize()));
        ViewCompat.setAccessibilityDelegate(view, new AccessibilityDelegateCompat() {

            final MaterialButtonToggleGroup this$0;

            public void onInitializeAccessibilityNodeInfo(View view1, AccessibilityNodeInfoCompat accessibilitynodeinfocompat)
            {
                super.onInitializeAccessibilityNodeInfo(view1, accessibilitynodeinfocompat);
                accessibilitynodeinfocompat.setCollectionItemInfo(androidx.core.view.accessibility.AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(0, 1, getIndexWithinVisibleButtons(view1), 1, false, ((MaterialButton)view1).isChecked()));
            }

            
            {
                this$0 = MaterialButtonToggleGroup.this;
                super();
            }
        });
    }

    public void check(int i)
    {
        if (i == checkedId)
        {
            return;
        } else
        {
            checkForced(i);
            return;
        }
    }

    public void clearChecked()
    {
        skipCheckedStateTracker = true;
        for (int i = 0; i < getChildCount(); i++)
        {
            MaterialButton materialbutton = getChildButton(i);
            materialbutton.setChecked(false);
            dispatchOnButtonChecked(materialbutton.getId(), false);
        }

        skipCheckedStateTracker = false;
        setCheckedId(-1);
    }

    public void clearOnButtonCheckedListeners()
    {
        onButtonCheckedListeners.clear();
    }

    protected void dispatchDraw(Canvas canvas)
    {
        updateChildOrder();
        super.dispatchDraw(canvas);
    }

    public CharSequence getAccessibilityClassName()
    {
        return com/google/android/material/button/MaterialButtonToggleGroup.getName();
    }

    public int getCheckedButtonId()
    {
        if (singleSelection)
        {
            return checkedId;
        } else
        {
            return -1;
        }
    }

    public List getCheckedButtonIds()
    {
        ArrayList arraylist = new ArrayList();
        for (int i = 0; i < getChildCount(); i++)
        {
            MaterialButton materialbutton = getChildButton(i);
            if (materialbutton.isChecked())
            {
                arraylist.add(Integer.valueOf(materialbutton.getId()));
            }
        }

        return arraylist;
    }

    protected int getChildDrawingOrder(int i, int j)
    {
        Integer ainteger[] = childOrder;
        if (ainteger != null && j < ainteger.length)
        {
            return ainteger[j].intValue();
        } else
        {
            Log.w(LOG_TAG, "Child order wasn't updated");
            return j;
        }
    }

    public boolean isSelectionRequired()
    {
        return selectionRequired;
    }

    public boolean isSingleSelection()
    {
        return singleSelection;
    }

    protected void onFinishInflate()
    {
        super.onFinishInflate();
        int i = checkedId;
        if (i != -1)
        {
            checkForced(i);
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilitynodeinfo)
    {
        super.onInitializeAccessibilityNodeInfo(accessibilitynodeinfo);
        accessibilitynodeinfo = AccessibilityNodeInfoCompat.wrap(accessibilitynodeinfo);
        int i = getVisibleButtonCount();
        byte byte0;
        if (isSingleSelection())
        {
            byte0 = 1;
        } else
        {
            byte0 = 2;
        }
        accessibilitynodeinfo.setCollectionInfo(androidx.core.view.accessibility.AccessibilityNodeInfoCompat.CollectionInfoCompat.obtain(1, i, false, byte0));
    }

    protected void onMeasure(int i, int j)
    {
        updateChildShapes();
        adjustChildMarginsAndUpdateLayout();
        super.onMeasure(i, j);
    }

    public void onViewRemoved(View view)
    {
        super.onViewRemoved(view);
        if (view instanceof MaterialButton)
        {
            ((MaterialButton)view).removeOnCheckedChangeListener(checkedStateTracker);
            ((MaterialButton)view).setOnPressedChangeListenerInternal(null);
        }
        int i = indexOfChild(view);
        if (i >= 0)
        {
            originalCornerData.remove(i);
        }
        updateChildShapes();
        adjustChildMarginsAndUpdateLayout();
    }

    public void removeOnButtonCheckedListener(OnButtonCheckedListener onbuttoncheckedlistener)
    {
        onButtonCheckedListeners.remove(onbuttoncheckedlistener);
    }

    public void setSelectionRequired(boolean flag)
    {
        selectionRequired = flag;
    }

    public void setSingleSelection(int i)
    {
        setSingleSelection(getResources().getBoolean(i));
    }

    public void setSingleSelection(boolean flag)
    {
        if (singleSelection != flag)
        {
            singleSelection = flag;
            clearChecked();
        }
    }

    public void uncheck(int i)
    {
        setCheckedStateForView(i, false);
        updateCheckedStates(i, false);
        checkedId = -1;
        dispatchOnButtonChecked(i, false);
    }

    void updateChildShapes()
    {
        int j = getChildCount();
        int k = getFirstVisibleChildIndex();
        int l = getLastVisibleChildIndex();
        for (int i = 0; i < j; i++)
        {
            MaterialButton materialbutton = getChildButton(i);
            if (materialbutton.getVisibility() != 8)
            {
                com.google.android.material.shape.ShapeAppearanceModel.Builder builder = materialbutton.getShapeAppearanceModel().toBuilder();
                updateBuilderWithCornerData(builder, getNewCornerData(i, k, l));
                materialbutton.setShapeAppearanceModel(builder.build());
            }
        }

    }

    static 
    {
        DEF_STYLE_RES = com.google.android.material.R.style.Widget_MaterialComponents_MaterialButtonToggleGroup;
    }





/*
    static int access$502(MaterialButtonToggleGroup materialbuttontogglegroup, int i)
    {
        materialbuttontogglegroup.checkedId = i;
        return i;
    }

*/


}
