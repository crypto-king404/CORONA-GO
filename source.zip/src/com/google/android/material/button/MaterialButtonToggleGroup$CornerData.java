// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.button;

import android.view.View;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.shape.AbsoluteCornerSize;
import com.google.android.material.shape.CornerSize;

// Referenced classes of package com.google.android.material.button:
//            MaterialButtonToggleGroup

private static class bottomLeft
{

    private static final CornerSize noCorner = new AbsoluteCornerSize(0.0F);
    CornerSize bottomLeft;
    CornerSize bottomRight;
    CornerSize topLeft;
    CornerSize topRight;

    public static bottomLeft bottom(bottomLeft bottomleft)
    {
        CornerSize cornersize = noCorner;
        return new <init>(cornersize, bottomleft.bottomLeft, cornersize, bottomleft.bottomRight);
    }

    public static bottomRight end(bottomRight bottomright, View view)
    {
        if (ViewUtils.isLayoutRtl(view))
        {
            return left(bottomright);
        } else
        {
            return right(bottomright);
        }
    }

    public static right left(right right1)
    {
        CornerSize cornersize = right1.topLeft;
        right1 = right1.bottomLeft;
        CornerSize cornersize1 = noCorner;
        return new <init>(cornersize, right1, cornersize1, cornersize1);
    }

    public static <init> right(<init> <init>1)
    {
        CornerSize cornersize = noCorner;
        return new <init>(cornersize, cornersize, <init>1.topRight, <init>1.bottomRight);
    }

    public static bottomRight start(bottomRight bottomright, View view)
    {
        if (ViewUtils.isLayoutRtl(view))
        {
            return right(bottomright);
        } else
        {
            return left(bottomright);
        }
    }

    public static left top(left left1)
    {
        CornerSize cornersize = left1.topLeft;
        CornerSize cornersize1 = noCorner;
        return new <init>(cornersize, cornersize1, left1.topRight, cornersize1);
    }


    (CornerSize cornersize, CornerSize cornersize1, CornerSize cornersize2, CornerSize cornersize3)
    {
        topLeft = cornersize;
        topRight = cornersize2;
        bottomRight = cornersize3;
        bottomLeft = cornersize1;
    }
}
