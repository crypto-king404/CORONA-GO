// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;


class FadeModeResult
{

    final int endAlpha;
    final boolean endOnTop;
    final int startAlpha;

    private FadeModeResult(int i, int j, boolean flag)
    {
        startAlpha = i;
        endAlpha = j;
        endOnTop = flag;
    }

    static FadeModeResult endOnTop(int i, int j)
    {
        return new FadeModeResult(i, j, true);
    }

    static FadeModeResult startOnTop(int i, int j)
    {
        return new FadeModeResult(i, j, false);
    }
}
