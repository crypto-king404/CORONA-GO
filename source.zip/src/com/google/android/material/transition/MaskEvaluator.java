// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.ShapeAppearancePathProvider;

// Referenced classes of package com.google.android.material.transition:
//            TransitionUtils

class MaskEvaluator
{

    private ShapeAppearanceModel currentShapeAppearanceModel;
    private final Path endPath = new Path();
    private final Path path = new Path();
    private final ShapeAppearancePathProvider pathProvider = new ShapeAppearancePathProvider();
    private final Path startPath = new Path();

    MaskEvaluator()
    {
    }

    void clip(Canvas canvas)
    {
        if (android.os.Build.VERSION.SDK_INT >= 23)
        {
            canvas.clipPath(path);
            return;
        } else
        {
            canvas.clipPath(startPath);
            canvas.clipPath(endPath, android.graphics.Region.Op.UNION);
            return;
        }
    }

    void evaluate(float f, ShapeAppearanceModel shapeappearancemodel, ShapeAppearanceModel shapeappearancemodel1, RectF rectf, RectF rectf1, RectF rectf2, MaterialContainerTransform.ProgressThresholds progressthresholds)
    {
        shapeappearancemodel = TransitionUtils.lerp(shapeappearancemodel, shapeappearancemodel1, rectf, rectf2, progressthresholds.getStart(), progressthresholds.getEnd(), f);
        currentShapeAppearanceModel = shapeappearancemodel;
        pathProvider.calculatePath(shapeappearancemodel, 1.0F, rectf1, startPath);
        pathProvider.calculatePath(currentShapeAppearanceModel, 1.0F, rectf2, endPath);
        if (android.os.Build.VERSION.SDK_INT >= 23)
        {
            path.op(startPath, endPath, android.graphics.Path.Op.UNION);
        }
    }

    ShapeAppearanceModel getCurrentShapeAppearanceModel()
    {
        return currentShapeAppearanceModel;
    }

    Path getPath()
    {
        return path;
    }
}
