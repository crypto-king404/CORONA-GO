// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.view.View;
import androidx.transition.Transition;
import com.google.android.material.internal.ViewOverlayImpl;
import com.google.android.material.internal.ViewUtils;

// Referenced classes of package com.google.android.material.transition:
//            TransitionListenerAdapter, MaterialContainerTransform

class it> extends TransitionListenerAdapter
{

    final MaterialContainerTransform this$0;
    final View val$drawingView;
    final View val$endView;
    final View val$startView;
    final ansitionDrawable val$transitionDrawable;

    public void onTransitionEnd(Transition transition)
    {
        removeListener(this);
        if (MaterialContainerTransform.access$300(MaterialContainerTransform.this))
        {
            return;
        } else
        {
            val$startView.setAlpha(1.0F);
            val$endView.setAlpha(1.0F);
            ViewUtils.getOverlay(val$drawingView).remove(val$transitionDrawable);
            return;
        }
    }

    public void onTransitionStart(Transition transition)
    {
        ViewUtils.getOverlay(val$drawingView).add(val$transitionDrawable);
        val$startView.setAlpha(0.0F);
        val$endView.setAlpha(0.0F);
    }

    ansitionDrawable()
    {
        this$0 = final_materialcontainertransform;
        val$drawingView = view;
        val$transitionDrawable = ansitiondrawable;
        val$startView = view1;
        val$endView = View.this;
        super();
    }
}
