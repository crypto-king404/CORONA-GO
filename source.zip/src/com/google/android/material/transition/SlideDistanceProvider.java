// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Annotation;

// Referenced classes of package com.google.android.material.transition:
//            VisibilityAnimatorProvider

public final class SlideDistanceProvider
    implements VisibilityAnimatorProvider
{
    public static interface GravityFlag
        extends Annotation
    {
    }


    private static final int DEFAULT_DISTANCE = -1;
    private int slideDistance;
    private int slideEdge;

    public SlideDistanceProvider(int i)
    {
        slideDistance = -1;
        slideEdge = i;
    }

    private static Animator createTranslationAppearAnimator(View view, View view1, int i, int j)
    {
        if (i != 3)
        {
            if (i != 5)
            {
                if (i != 48)
                {
                    if (i != 80)
                    {
                        if (i != 0x800003)
                        {
                            if (i == 0x800005)
                            {
                                float f;
                                if (isRtl(view))
                                {
                                    f = -j;
                                } else
                                {
                                    f = j;
                                }
                                return createTranslationXAnimator(view1, f, 0.0F);
                            } else
                            {
                                view = new StringBuilder();
                                view.append("Invalid slide direction: ");
                                view.append(i);
                                throw new IllegalArgumentException(view.toString());
                            }
                        }
                        float f1;
                        if (isRtl(view))
                        {
                            f1 = j;
                        } else
                        {
                            f1 = -j;
                        }
                        return createTranslationXAnimator(view1, f1, 0.0F);
                    } else
                    {
                        return createTranslationYAnimator(view1, j, 0.0F);
                    }
                } else
                {
                    return createTranslationYAnimator(view1, -j, 0.0F);
                }
            } else
            {
                return createTranslationXAnimator(view1, -j, 0.0F);
            }
        } else
        {
            return createTranslationXAnimator(view1, j, 0.0F);
        }
    }

    private static Animator createTranslationDisappearAnimator(View view, View view1, int i, int j)
    {
        if (i != 3)
        {
            if (i != 5)
            {
                if (i != 48)
                {
                    if (i != 80)
                    {
                        if (i != 0x800003)
                        {
                            if (i == 0x800005)
                            {
                                float f;
                                if (isRtl(view))
                                {
                                    f = j;
                                } else
                                {
                                    f = -j;
                                }
                                return createTranslationXAnimator(view1, 0.0F, f);
                            } else
                            {
                                view = new StringBuilder();
                                view.append("Invalid slide direction: ");
                                view.append(i);
                                throw new IllegalArgumentException(view.toString());
                            }
                        }
                        float f1;
                        if (isRtl(view))
                        {
                            f1 = -j;
                        } else
                        {
                            f1 = j;
                        }
                        return createTranslationXAnimator(view1, 0.0F, f1);
                    } else
                    {
                        return createTranslationYAnimator(view1, 0.0F, -j);
                    }
                } else
                {
                    return createTranslationYAnimator(view1, 0.0F, j);
                }
            } else
            {
                return createTranslationXAnimator(view1, 0.0F, j);
            }
        } else
        {
            return createTranslationXAnimator(view1, 0.0F, -j);
        }
    }

    private static Animator createTranslationXAnimator(View view, float f, float f1)
    {
        return ObjectAnimator.ofPropertyValuesHolder(view, new PropertyValuesHolder[] {
            PropertyValuesHolder.ofFloat(View.TRANSLATION_X, new float[] {
                f, f1
            })
        });
    }

    private static Animator createTranslationYAnimator(View view, float f, float f1)
    {
        return ObjectAnimator.ofPropertyValuesHolder(view, new PropertyValuesHolder[] {
            PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, new float[] {
                f, f1
            })
        });
    }

    private int getSlideDistanceOrDefault(Context context)
    {
        int i = slideDistance;
        if (i != -1)
        {
            return i;
        } else
        {
            return context.getResources().getDimensionPixelSize(com.google.android.material.R.dimen.mtrl_transition_shared_axis_slide_distance);
        }
    }

    private static boolean isRtl(View view)
    {
        return ViewCompat.getLayoutDirection(view) == 1;
    }

    public Animator createAppear(ViewGroup viewgroup, View view)
    {
        return createTranslationAppearAnimator(viewgroup, view, slideEdge, getSlideDistanceOrDefault(view.getContext()));
    }

    public Animator createDisappear(ViewGroup viewgroup, View view)
    {
        return createTranslationDisappearAnimator(viewgroup, view, slideEdge, getSlideDistanceOrDefault(view.getContext()));
    }

    public int getSlideDistance()
    {
        return slideDistance;
    }

    public int getSlideEdge()
    {
        return slideEdge;
    }

    public void setSlideDistance(int i)
    {
        if (i >= 0)
        {
            slideDistance = i;
            return;
        } else
        {
            throw new IllegalArgumentException("Slide distance must be positive. If attempting to reverse the direction of the slide, use setSlideEdge(int) instead.");
        }
    }

    public void setSlideEdge(int i)
    {
        slideEdge = i;
    }
}
