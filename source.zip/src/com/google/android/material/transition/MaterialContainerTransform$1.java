// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.animation.ValueAnimator;

// Referenced classes of package com.google.android.material.transition:
//            MaterialContainerTransform

class ansitionDrawable
    implements android.animation.istener
{

    final MaterialContainerTransform this$0;
    final ansitionDrawable val$transitionDrawable;

    public void onAnimationUpdate(ValueAnimator valueanimator)
    {
        ansitionDrawable.access._mth200(val$transitionDrawable, valueanimator.getAnimatedFraction());
    }

    ansitionDrawable()
    {
        this$0 = final_materialcontainertransform;
        val$transitionDrawable = ansitionDrawable.this;
        super();
    }
}
