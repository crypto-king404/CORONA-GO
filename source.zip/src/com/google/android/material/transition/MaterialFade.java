// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.animation.Animator;
import android.view.View;
import android.view.ViewGroup;
import androidx.transition.TransitionValues;

// Referenced classes of package com.google.android.material.transition:
//            MaterialVisibility, FadeProvider, ScaleProvider, VisibilityAnimatorProvider

public final class MaterialFade extends MaterialVisibility
{

    private static final float DEFAULT_FADE_END_THRESHOLD_ENTER = 0.3F;
    private static final float DEFAULT_START_SCALE = 0.8F;

    public MaterialFade()
    {
        super(createPrimaryAnimatorProvider(), createSecondaryAnimatorProvider());
    }

    private static FadeProvider createPrimaryAnimatorProvider()
    {
        FadeProvider fadeprovider = new FadeProvider();
        fadeprovider.setIncomingEndThreshold(0.3F);
        return fadeprovider;
    }

    private static VisibilityAnimatorProvider createSecondaryAnimatorProvider()
    {
        ScaleProvider scaleprovider = new ScaleProvider();
        scaleprovider.setScaleOnDisappear(false);
        scaleprovider.setIncomingStartScale(0.8F);
        return scaleprovider;
    }

    public volatile VisibilityAnimatorProvider getSecondaryAnimatorProvider()
    {
        return super.getSecondaryAnimatorProvider();
    }

    public volatile Animator onAppear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onAppear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile Animator onDisappear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onDisappear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile void setSecondaryAnimatorProvider(VisibilityAnimatorProvider visibilityanimatorprovider)
    {
        super.setSecondaryAnimatorProvider(visibilityanimatorprovider);
    }
}
