// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;


class FitModeResult
{

    final float currentEndHeight;
    final float currentEndWidth;
    final float currentStartHeight;
    final float currentStartWidth;
    final float endScale;
    final float startScale;

    FitModeResult(float f, float f1, float f2, float f3, float f4, float f5)
    {
        startScale = f;
        endScale = f1;
        currentStartWidth = f2;
        currentStartHeight = f3;
        currentEndWidth = f4;
        currentEndHeight = f5;
    }
}
