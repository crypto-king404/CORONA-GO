// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import com.google.android.material.shape.CornerSize;

// Referenced classes of package com.google.android.material.transition:
//            TransitionUtils

static interface 
{

    public abstract CornerSize apply(CornerSize cornersize, CornerSize cornersize1);
}
