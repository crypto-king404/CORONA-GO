// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;


// Referenced classes of package com.google.android.material.transition:
//            FadeModeEvaluator, TransitionUtils, FadeModeResult

class FadeModeEvaluators
{

    private static final FadeModeEvaluator CROSS = new FadeModeEvaluator() {

        public FadeModeResult evaluate(float f, float f1, float f2)
        {
            return FadeModeResult.startOnTop(TransitionUtils.lerp(255, 0, f1, f2, f), TransitionUtils.lerp(0, 255, f1, f2, f));
        }

    };
    private static final FadeModeEvaluator IN = new FadeModeEvaluator() {

        public FadeModeResult evaluate(float f, float f1, float f2)
        {
            return FadeModeResult.endOnTop(255, TransitionUtils.lerp(0, 255, f1, f2, f));
        }

    };
    private static final FadeModeEvaluator OUT = new FadeModeEvaluator() {

        public FadeModeResult evaluate(float f, float f1, float f2)
        {
            return FadeModeResult.startOnTop(TransitionUtils.lerp(255, 0, f1, f2, f), 255);
        }

    };
    private static final FadeModeEvaluator THROUGH = new FadeModeEvaluator() {

        public FadeModeResult evaluate(float f, float f1, float f2)
        {
            float f3 = 0.35F * (f2 - f1) + f1;
            return FadeModeResult.startOnTop(TransitionUtils.lerp(255, 0, f1, f3, f), TransitionUtils.lerp(0, 255, f3, f2, f));
        }

    };

    private FadeModeEvaluators()
    {
    }

    static FadeModeEvaluator get(int i, boolean flag)
    {
        if (i != 0)
        {
            if (i != 1)
            {
                if (i != 2)
                {
                    if (i == 3)
                    {
                        return THROUGH;
                    } else
                    {
                        StringBuilder stringbuilder = new StringBuilder();
                        stringbuilder.append("Invalid fade mode: ");
                        stringbuilder.append(i);
                        throw new IllegalArgumentException(stringbuilder.toString());
                    }
                } else
                {
                    return CROSS;
                }
            }
            if (flag)
            {
                return OUT;
            } else
            {
                return IN;
            }
        }
        if (flag)
        {
            return IN;
        } else
        {
            return OUT;
        }
    }

}
