// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.transition.ArcMotion;
import android.transition.PathMotion;
import android.transition.Transition;
import android.transition.TransitionValues;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import androidx.core.util.Preconditions;
import androidx.core.view.ViewCompat;
import com.google.android.material.animation.AnimationUtils;
import com.google.android.material.internal.ViewOverlayImpl;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.shape.CornerSize;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;
import java.lang.annotation.Annotation;
import java.util.Map;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialArcMotion, TransitionUtils, FadeModeEvaluators, FitModeEvaluators, 
//            MaskEvaluator, FitModeResult, FadeModeResult, FitModeEvaluator, 
//            FadeModeEvaluator, TransitionListenerAdapter

public final class MaterialContainerTransform extends Transition
{
    public static interface FadeMode
        extends Annotation
    {
    }

    public static interface FitMode
        extends Annotation
    {
    }

    public static class ProgressThresholds
    {

        private final float end;
        private final float start;

        public float getEnd()
        {
            return end;
        }

        public float getStart()
        {
            return start;
        }



        public ProgressThresholds(float f, float f1)
        {
            start = f;
            end = f1;
        }
    }

    private static class ProgressThresholdsGroup
    {

        private final ProgressThresholds fade;
        private final ProgressThresholds scale;
        private final ProgressThresholds scaleMask;
        private final ProgressThresholds shapeMask;





        private ProgressThresholdsGroup(ProgressThresholds progressthresholds, ProgressThresholds progressthresholds1, ProgressThresholds progressthresholds2, ProgressThresholds progressthresholds3)
        {
            fade = progressthresholds;
            scale = progressthresholds1;
            scaleMask = progressthresholds2;
            shapeMask = progressthresholds3;
        }

    }

    public static interface TransitionDirection
        extends Annotation
    {
    }

    private static final class TransitionDrawable extends Drawable
    {

        private static final int COMPAT_SHADOW_COLOR = 0xff888888;
        private static final int SHADOW_COLOR = 0x2d000000;
        private static final float SHADOW_DX_MULTIPLIER_ADJUSTMENT = 0.3F;
        private static final float SHADOW_DY_MULTIPLIER_ADJUSTMENT = 1.5F;
        private final MaterialShapeDrawable compatShadowDrawable;
        private final Paint containerPaint;
        private float currentElevation;
        private float currentElevationDy;
        private final RectF currentEndBounds;
        private final RectF currentEndBoundsMasked;
        private RectF currentMaskBounds;
        private final RectF currentStartBounds;
        private final RectF currentStartBoundsMasked;
        private final Paint debugPaint;
        private final Path debugPath;
        private final float displayHeight;
        private final float displayWidth;
        private final boolean drawDebugEnabled;
        private final boolean elevationShadowEnabled;
        private final RectF endBounds;
        private final Paint endContainerPaint;
        private final float endElevation;
        private final ShapeAppearanceModel endShapeAppearanceModel;
        private final View endView;
        private final boolean entering;
        private final FadeModeEvaluator fadeModeEvaluator;
        private FadeModeResult fadeModeResult;
        private final FitModeEvaluator fitModeEvaluator;
        private FitModeResult fitModeResult;
        private final MaskEvaluator maskEvaluator;
        private final float motionPathLength;
        private final PathMeasure motionPathMeasure;
        private final float motionPathPosition[];
        private float progress;
        private final ProgressThresholdsGroup progressThresholds;
        private final Paint scrimPaint;
        private final Paint shadowPaint;
        private final RectF startBounds;
        private final Paint startContainerPaint;
        private final float startElevation;
        private final ShapeAppearanceModel startShapeAppearanceModel;
        private final View startView;

        private static float calculateElevationDxMultiplier(RectF rectf, float f)
        {
            return (rectf.centerX() / (f / 2.0F) - 1.0F) * 0.3F;
        }

        private static float calculateElevationDyMultiplier(RectF rectf, float f)
        {
            return (rectf.centerY() / f) * 1.5F;
        }

        private void drawDebugCumulativePath(Canvas canvas, RectF rectf, Path path, int i)
        {
            rectf = getMotionPathPoint(rectf);
            if (progress == 0.0F)
            {
                path.reset();
                path.moveTo(((PointF) (rectf)).x, ((PointF) (rectf)).y);
                return;
            } else
            {
                path.lineTo(((PointF) (rectf)).x, ((PointF) (rectf)).y);
                debugPaint.setColor(i);
                canvas.drawPath(path, debugPaint);
                return;
            }
        }

        private void drawDebugRect(Canvas canvas, RectF rectf, int i)
        {
            debugPaint.setColor(i);
            canvas.drawRect(rectf, debugPaint);
        }

        private void drawElevationShadow(Canvas canvas)
        {
            canvas.save();
            canvas.clipPath(maskEvaluator.getPath(), android.graphics.Region.Op.DIFFERENCE);
            if (android.os.Build.VERSION.SDK_INT > 28)
            {
                drawElevationShadowWithPaintShadowLayer(canvas);
            } else
            {
                drawElevationShadowWithMaterialShapeDrawable(canvas);
            }
            canvas.restore();
        }

        private void drawElevationShadowWithMaterialShapeDrawable(Canvas canvas)
        {
            compatShadowDrawable.setBounds((int)currentMaskBounds.left, (int)currentMaskBounds.top, (int)currentMaskBounds.right, (int)currentMaskBounds.bottom);
            compatShadowDrawable.setElevation(currentElevation);
            compatShadowDrawable.setShadowVerticalOffset((int)currentElevationDy);
            compatShadowDrawable.setShapeAppearanceModel(maskEvaluator.getCurrentShapeAppearanceModel());
            compatShadowDrawable.draw(canvas);
        }

        private void drawElevationShadowWithPaintShadowLayer(Canvas canvas)
        {
            ShapeAppearanceModel shapeappearancemodel = maskEvaluator.getCurrentShapeAppearanceModel();
            if (shapeappearancemodel.isRoundRect(currentMaskBounds))
            {
                float f = shapeappearancemodel.getTopLeftCornerSize().getCornerSize(currentMaskBounds);
                canvas.drawRoundRect(currentMaskBounds, f, f, shadowPaint);
                return;
            } else
            {
                canvas.drawPath(maskEvaluator.getPath(), shadowPaint);
                return;
            }
        }

        private void drawEndView(Canvas canvas)
        {
            maybeDrawContainerColor(canvas, endContainerPaint);
            TransitionUtils.transform(canvas, getBounds(), currentEndBounds.left, currentEndBounds.top, fitModeResult.endScale, fadeModeResult.endAlpha, new TransitionUtils.CanvasOperation() {

                final TransitionDrawable this$0;

                public void run(Canvas canvas)
                {
                    endView.draw(canvas);
                }

            
            {
                this$0 = TransitionDrawable.this;
                super();
            }
            });
        }

        private void drawStartView(Canvas canvas)
        {
            maybeDrawContainerColor(canvas, startContainerPaint);
            TransitionUtils.transform(canvas, getBounds(), currentStartBounds.left, currentStartBounds.top, fitModeResult.startScale, fadeModeResult.startAlpha, new TransitionUtils.CanvasOperation() {

                final TransitionDrawable this$0;

                public void run(Canvas canvas)
                {
                    startView.draw(canvas);
                }

            
            {
                this$0 = TransitionDrawable.this;
                super();
            }
            });
        }

        private static PointF getMotionPathPoint(RectF rectf)
        {
            return new PointF(rectf.centerX(), rectf.top);
        }

        private void maybeDrawContainerColor(Canvas canvas, Paint paint)
        {
            if (paint.getColor() != 0 && paint.getAlpha() > 0)
            {
                canvas.drawRect(getBounds(), paint);
            }
        }

        private void setProgress(float f)
        {
            if (progress != f)
            {
                updateProgress(f);
            }
        }

        private void updateProgress(float f)
        {
            progress = f;
            Object obj = scrimPaint;
            float f1;
            if (entering)
            {
                f1 = TransitionUtils.lerp(0.0F, 255F, f);
            } else
            {
                f1 = TransitionUtils.lerp(255F, 0.0F, f);
            }
            ((Paint) (obj)).setAlpha((int)f1);
            motionPathMeasure.getPosTan(motionPathLength * f, motionPathPosition, null);
            float af[] = motionPathPosition;
            f1 = af[0];
            float f2 = af[1];
            float f3 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.scale.start))).floatValue();
            float f4 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.scale.end))).floatValue();
            af = fitModeEvaluator.evaluate(f, f3, f4, startBounds.width(), startBounds.height(), endBounds.width(), endBounds.height());
            fitModeResult = af;
            currentStartBounds.set(f1 - ((FitModeResult) (af)).currentStartWidth / 2.0F, f2, fitModeResult.currentStartWidth / 2.0F + f1, fitModeResult.currentStartHeight + f2);
            currentEndBounds.set(f1 - fitModeResult.currentEndWidth / 2.0F, f2, fitModeResult.currentEndWidth / 2.0F + f1, fitModeResult.currentEndHeight + f2);
            currentStartBoundsMasked.set(currentStartBounds);
            currentEndBoundsMasked.set(currentEndBounds);
            f1 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.scaleMask.start))).floatValue();
            f2 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.scaleMask.end))).floatValue();
            boolean flag = fitModeEvaluator.shouldMaskStartBounds(fitModeResult);
            if (flag)
            {
                af = currentStartBoundsMasked;
            } else
            {
                af = currentEndBoundsMasked;
            }
            f1 = TransitionUtils.lerp(0.0F, 1.0F, f1, f2, f);
            if (!flag)
            {
                f1 = 1.0F - f1;
            }
            fitModeEvaluator.applyMask(af, f1, fitModeResult);
            currentMaskBounds = new RectF(Math.min(currentStartBoundsMasked.left, currentEndBoundsMasked.left), Math.min(currentStartBoundsMasked.top, currentEndBoundsMasked.top), Math.max(currentStartBoundsMasked.right, currentEndBoundsMasked.right), Math.max(currentStartBoundsMasked.bottom, currentEndBoundsMasked.bottom));
            maskEvaluator.evaluate(f, startShapeAppearanceModel, endShapeAppearanceModel, currentStartBounds, currentStartBoundsMasked, currentEndBoundsMasked, progressThresholds.shapeMask);
            currentElevation = TransitionUtils.lerp(startElevation, endElevation, f);
            f3 = calculateElevationDxMultiplier(currentMaskBounds, displayWidth);
            f2 = calculateElevationDyMultiplier(currentMaskBounds, displayHeight);
            f1 = currentElevation;
            f3 = (int)(f1 * f3);
            f2 = (int)(f1 * f2);
            currentElevationDy = f2;
            shadowPaint.setShadowLayer(f1, f3, f2, 0x2d000000);
            f1 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.fade.start))).floatValue();
            f2 = ((Float)Preconditions.checkNotNull(Float.valueOf(progressThresholds.fade.end))).floatValue();
            fadeModeResult = fadeModeEvaluator.evaluate(f, f1, f2);
            if (startContainerPaint.getColor() != 0)
            {
                startContainerPaint.setAlpha(fadeModeResult.startAlpha);
            }
            if (endContainerPaint.getColor() != 0)
            {
                endContainerPaint.setAlpha(fadeModeResult.endAlpha);
            }
            invalidateSelf();
        }

        public void draw(Canvas canvas)
        {
            if (scrimPaint.getAlpha() > 0)
            {
                canvas.drawRect(getBounds(), scrimPaint);
            }
            int i;
            if (drawDebugEnabled)
            {
                i = canvas.save();
            } else
            {
                i = -1;
            }
            if (elevationShadowEnabled && currentElevation > 0.0F)
            {
                drawElevationShadow(canvas);
            }
            maskEvaluator.clip(canvas);
            maybeDrawContainerColor(canvas, containerPaint);
            if (fadeModeResult.endOnTop)
            {
                drawStartView(canvas);
                drawEndView(canvas);
            } else
            {
                drawEndView(canvas);
                drawStartView(canvas);
            }
            if (drawDebugEnabled)
            {
                canvas.restoreToCount(i);
                drawDebugCumulativePath(canvas, currentStartBounds, debugPath, -65281);
                drawDebugRect(canvas, currentStartBoundsMasked, -256);
                drawDebugRect(canvas, currentStartBounds, 0xff00ff00);
                drawDebugRect(canvas, currentEndBoundsMasked, 0xff00ffff);
                drawDebugRect(canvas, currentEndBounds, 0xff0000ff);
            }
        }

        public int getOpacity()
        {
            return -3;
        }

        public void setAlpha(int i)
        {
            throw new UnsupportedOperationException("Setting alpha on is not supported");
        }

        public void setColorFilter(ColorFilter colorfilter)
        {
            throw new UnsupportedOperationException("Setting a color filter is not supported");
        }




        private TransitionDrawable(PathMotion pathmotion, View view, RectF rectf, ShapeAppearanceModel shapeappearancemodel, float f, View view1, RectF rectf1, 
                ShapeAppearanceModel shapeappearancemodel1, float f1, int i, int j, int k, int l, boolean flag, 
                boolean flag1, FadeModeEvaluator fademodeevaluator, FitModeEvaluator fitmodeevaluator, ProgressThresholdsGroup progressthresholdsgroup, boolean flag2)
        {
            Paint paint2 = new Paint();
            containerPaint = paint2;
            Paint paint3 = new Paint();
            startContainerPaint = paint3;
            Paint paint4 = new Paint();
            endContainerPaint = paint4;
            shadowPaint = new Paint();
            Paint paint = new Paint();
            scrimPaint = paint;
            maskEvaluator = new MaskEvaluator();
            float af[] = new float[2];
            motionPathPosition = af;
            MaterialShapeDrawable materialshapedrawable = new MaterialShapeDrawable();
            compatShadowDrawable = materialshapedrawable;
            Paint paint1 = new Paint();
            debugPaint = paint1;
            debugPath = new Path();
            startView = view;
            startBounds = rectf;
            startShapeAppearanceModel = shapeappearancemodel;
            startElevation = f;
            endView = view1;
            endBounds = rectf1;
            endShapeAppearanceModel = shapeappearancemodel1;
            endElevation = f1;
            entering = flag;
            elevationShadowEnabled = flag1;
            fadeModeEvaluator = fademodeevaluator;
            fitModeEvaluator = fitmodeevaluator;
            progressThresholds = progressthresholdsgroup;
            drawDebugEnabled = flag2;
            view = (WindowManager)view.getContext().getSystemService("window");
            shapeappearancemodel = new DisplayMetrics();
            view.getDefaultDisplay().getMetrics(shapeappearancemodel);
            displayWidth = ((DisplayMetrics) (shapeappearancemodel)).widthPixels;
            displayHeight = ((DisplayMetrics) (shapeappearancemodel)).heightPixels;
            paint2.setColor(i);
            paint3.setColor(j);
            paint4.setColor(k);
            materialshapedrawable.setFillColor(ColorStateList.valueOf(0));
            materialshapedrawable.setShadowCompatibilityMode(2);
            materialshapedrawable.setShadowBitmapDrawingEnable(false);
            materialshapedrawable.setShadowColor(0xff888888);
            view = new RectF(rectf);
            currentStartBounds = view;
            currentStartBoundsMasked = new RectF(view);
            view = new RectF(view);
            currentEndBounds = view;
            currentEndBoundsMasked = new RectF(view);
            view = getMotionPathPoint(rectf);
            shapeappearancemodel = getMotionPathPoint(rectf1);
            pathmotion = new PathMeasure(pathmotion.getPath(((PointF) (view)).x, ((PointF) (view)).y, ((PointF) (shapeappearancemodel)).x, ((PointF) (shapeappearancemodel)).y), false);
            motionPathMeasure = pathmotion;
            motionPathLength = pathmotion.getLength();
            af[0] = rectf.centerX();
            af[1] = rectf.top;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setShader(TransitionUtils.createColorShader(l));
            paint1.setStyle(android.graphics.Paint.Style.STROKE);
            paint1.setStrokeWidth(10F);
            updateProgress(0.0F);
        }

    }


    private static final ProgressThresholdsGroup DEFAULT_ENTER_THRESHOLDS = new ProgressThresholdsGroup(new ProgressThresholds(0.0F, 0.25F), new ProgressThresholds(0.0F, 1.0F), new ProgressThresholds(0.0F, 1.0F), new ProgressThresholds(0.0F, 0.75F));
    private static final ProgressThresholdsGroup DEFAULT_ENTER_THRESHOLDS_ARC = new ProgressThresholdsGroup(new ProgressThresholds(0.1F, 0.4F), new ProgressThresholds(0.1F, 1.0F), new ProgressThresholds(0.1F, 1.0F), new ProgressThresholds(0.1F, 0.9F));
    private static final ProgressThresholdsGroup DEFAULT_RETURN_THRESHOLDS = new ProgressThresholdsGroup(new ProgressThresholds(0.6F, 0.9F), new ProgressThresholds(0.0F, 1.0F), new ProgressThresholds(0.0F, 0.9F), new ProgressThresholds(0.3F, 0.9F));
    private static final ProgressThresholdsGroup DEFAULT_RETURN_THRESHOLDS_ARC = new ProgressThresholdsGroup(new ProgressThresholds(0.6F, 0.9F), new ProgressThresholds(0.0F, 0.9F), new ProgressThresholds(0.0F, 0.9F), new ProgressThresholds(0.2F, 0.9F));
    private static final float ELEVATION_NOT_SET = -1F;
    public static final int FADE_MODE_CROSS = 2;
    public static final int FADE_MODE_IN = 0;
    public static final int FADE_MODE_OUT = 1;
    public static final int FADE_MODE_THROUGH = 3;
    public static final int FIT_MODE_AUTO = 0;
    public static final int FIT_MODE_HEIGHT = 2;
    public static final int FIT_MODE_WIDTH = 1;
    private static final String PROP_BOUNDS = "materialContainerTransition:bounds";
    private static final String PROP_SHAPE_APPEARANCE = "materialContainerTransition:shapeAppearance";
    private static final String TAG = com/google/android/material/transition/platform/MaterialContainerTransform.getSimpleName();
    public static final int TRANSITION_DIRECTION_AUTO = 0;
    public static final int TRANSITION_DIRECTION_ENTER = 1;
    public static final int TRANSITION_DIRECTION_RETURN = 2;
    private static final String TRANSITION_PROPS[] = {
        "materialContainerTransition:bounds", "materialContainerTransition:shapeAppearance"
    };
    private int containerColor;
    private boolean drawDebugEnabled;
    private int drawingViewId;
    private boolean elevationShadowEnabled;
    private int endContainerColor;
    private float endElevation;
    private ShapeAppearanceModel endShapeAppearanceModel;
    private View endView;
    private int endViewId;
    private int fadeMode;
    private ProgressThresholds fadeProgressThresholds;
    private int fitMode;
    private boolean holdAtEndEnabled;
    private ProgressThresholds scaleMaskProgressThresholds;
    private ProgressThresholds scaleProgressThresholds;
    private int scrimColor;
    private ProgressThresholds shapeMaskProgressThresholds;
    private int startContainerColor;
    private float startElevation;
    private ShapeAppearanceModel startShapeAppearanceModel;
    private View startView;
    private int startViewId;
    private int transitionDirection;

    public MaterialContainerTransform()
    {
        boolean flag = false;
        drawDebugEnabled = false;
        holdAtEndEnabled = false;
        drawingViewId = 0x1020002;
        startViewId = -1;
        endViewId = -1;
        containerColor = 0;
        startContainerColor = 0;
        endContainerColor = 0;
        scrimColor = 0x52000000;
        transitionDirection = 0;
        fadeMode = 0;
        fitMode = 0;
        if (android.os.Build.VERSION.SDK_INT >= 28)
        {
            flag = true;
        }
        elevationShadowEnabled = flag;
        startElevation = -1F;
        endElevation = -1F;
        setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
    }

    private ProgressThresholdsGroup buildThresholdsGroup(boolean flag)
    {
        PathMotion pathmotion = getPathMotion();
        if (!(pathmotion instanceof ArcMotion) && !(pathmotion instanceof MaterialArcMotion))
        {
            return getThresholdsOrDefault(flag, DEFAULT_ENTER_THRESHOLDS, DEFAULT_RETURN_THRESHOLDS);
        } else
        {
            return getThresholdsOrDefault(flag, DEFAULT_ENTER_THRESHOLDS_ARC, DEFAULT_RETURN_THRESHOLDS_ARC);
        }
    }

    private static RectF calculateDrawableBounds(View view, View view1, float f, float f1)
    {
        if (view1 != null)
        {
            view = TransitionUtils.getLocationOnScreen(view1);
            view.offset(f, f1);
            return view;
        } else
        {
            return new RectF(0.0F, 0.0F, view.getWidth(), view.getHeight());
        }
    }

    private static ShapeAppearanceModel captureShapeAppearance(View view, RectF rectf, ShapeAppearanceModel shapeappearancemodel)
    {
        return TransitionUtils.convertToRelativeCornerSizes(getShapeAppearance(view, shapeappearancemodel), rectf);
    }

    private static void captureValues(TransitionValues transitionvalues, View view, int i, ShapeAppearanceModel shapeappearancemodel)
    {
        if (i != -1)
        {
            transitionvalues.view = TransitionUtils.findDescendantOrAncestorById(transitionvalues.view, i);
        } else
        if (view != null)
        {
            transitionvalues.view = view;
        } else
        if (transitionvalues.view.getTag(com.google.android.material.R.id.mtrl_motion_snapshot_view) instanceof View)
        {
            view = (View)transitionvalues.view.getTag(com.google.android.material.R.id.mtrl_motion_snapshot_view);
            transitionvalues.view.setTag(com.google.android.material.R.id.mtrl_motion_snapshot_view, null);
            transitionvalues.view = view;
        }
        View view1 = transitionvalues.view;
        if (ViewCompat.isLaidOut(view1) || view1.getWidth() != 0 || view1.getHeight() != 0)
        {
            if (view1.getParent() == null)
            {
                view = TransitionUtils.getRelativeBounds(view1);
            } else
            {
                view = TransitionUtils.getLocationOnScreen(view1);
            }
            transitionvalues.values.put("materialContainerTransition:bounds", view);
            transitionvalues.values.put("materialContainerTransition:shapeAppearance", captureShapeAppearance(view1, view, shapeappearancemodel));
        }
    }

    private static float getElevationOrDefault(float f, View view)
    {
        if (f != -1F)
        {
            return f;
        } else
        {
            return ViewCompat.getElevation(view);
        }
    }

    private static ShapeAppearanceModel getShapeAppearance(View view, ShapeAppearanceModel shapeappearancemodel)
    {
        if (shapeappearancemodel != null)
        {
            return shapeappearancemodel;
        }
        if (view.getTag(com.google.android.material.R.id.mtrl_motion_snapshot_view) instanceof ShapeAppearanceModel)
        {
            return (ShapeAppearanceModel)view.getTag(com.google.android.material.R.id.mtrl_motion_snapshot_view);
        }
        shapeappearancemodel = view.getContext();
        int i = getTransitionShapeAppearanceResId(shapeappearancemodel);
        if (i != -1)
        {
            return ShapeAppearanceModel.builder(shapeappearancemodel, i, 0).build();
        }
        if (view instanceof Shapeable)
        {
            return ((Shapeable)view).getShapeAppearanceModel();
        } else
        {
            return ShapeAppearanceModel.builder().build();
        }
    }

    private ProgressThresholdsGroup getThresholdsOrDefault(boolean flag, ProgressThresholdsGroup progressthresholdsgroup, ProgressThresholdsGroup progressthresholdsgroup1)
    {
        if (!flag)
        {
            progressthresholdsgroup = progressthresholdsgroup1;
        }
        return new ProgressThresholdsGroup((ProgressThresholds)TransitionUtils.defaultIfNull(fadeProgressThresholds, progressthresholdsgroup.fade), (ProgressThresholds)TransitionUtils.defaultIfNull(scaleProgressThresholds, progressthresholdsgroup.scale), (ProgressThresholds)TransitionUtils.defaultIfNull(scaleMaskProgressThresholds, progressthresholdsgroup.scaleMask), (ProgressThresholds)TransitionUtils.defaultIfNull(shapeMaskProgressThresholds, progressthresholdsgroup.shapeMask));
    }

    private static int getTransitionShapeAppearanceResId(Context context)
    {
        context = context.obtainStyledAttributes(new int[] {
            com.google.android.material.R.attr.transitionShapeAppearance
        });
        int i = context.getResourceId(0, -1);
        context.recycle();
        return i;
    }

    private boolean isEntering(RectF rectf, RectF rectf1)
    {
        int i = transitionDirection;
        boolean flag = false;
        if (i != 0)
        {
            if (i != 1)
            {
                if (i == 2)
                {
                    return false;
                } else
                {
                    rectf = new StringBuilder();
                    rectf.append("Invalid transition direction: ");
                    rectf.append(transitionDirection);
                    throw new IllegalArgumentException(rectf.toString());
                }
            } else
            {
                return true;
            }
        }
        if (TransitionUtils.calculateArea(rectf1) > TransitionUtils.calculateArea(rectf))
        {
            flag = true;
        }
        return flag;
    }

    public void captureEndValues(TransitionValues transitionvalues)
    {
        captureValues(transitionvalues, endView, endViewId, endShapeAppearanceModel);
    }

    public void captureStartValues(TransitionValues transitionvalues)
    {
        captureValues(transitionvalues, startView, startViewId, startShapeAppearanceModel);
    }

    public Animator createAnimator(final ViewGroup drawingView, TransitionValues transitionvalues, final TransitionValues endView)
    {
        if (transitionvalues != null)
        {
            if (endView == null)
            {
                return null;
            }
            RectF rectf = (RectF)transitionvalues.values.get("materialContainerTransition:bounds");
            ShapeAppearanceModel shapeappearancemodel = (ShapeAppearanceModel)transitionvalues.values.get("materialContainerTransition:shapeAppearance");
            if (rectf != null && shapeappearancemodel != null)
            {
                RectF rectf1 = (RectF)endView.values.get("materialContainerTransition:bounds");
                ShapeAppearanceModel shapeappearancemodel1 = (ShapeAppearanceModel)endView.values.get("materialContainerTransition:shapeAppearance");
                if (rectf1 != null && shapeappearancemodel1 != null)
                {
                    final View startView = transitionvalues.view;
                    endView = endView.view;
                    if (endView.getParent() != null)
                    {
                        drawingView = endView;
                    } else
                    {
                        drawingView = startView;
                    }
                    if (drawingViewId == drawingView.getId())
                    {
                        View view = (View)drawingView.getParent();
                        transitionvalues = drawingView;
                        drawingView = view;
                    } else
                    {
                        drawingView = TransitionUtils.findAncestorById(drawingView, drawingViewId);
                        transitionvalues = null;
                    }
                    final TransitionDrawable transitionDrawable = TransitionUtils.getLocationOnScreen(drawingView);
                    float f = -((RectF) (transitionDrawable)).left;
                    float f1 = -((RectF) (transitionDrawable)).top;
                    transitionvalues = calculateDrawableBounds(drawingView, transitionvalues, f, f1);
                    rectf.offset(f, f1);
                    rectf1.offset(f, f1);
                    boolean flag = isEntering(rectf, rectf1);
                    transitionDrawable = new TransitionDrawable(getPathMotion(), startView, rectf, shapeappearancemodel, getElevationOrDefault(startElevation, startView), endView, rectf1, shapeappearancemodel1, getElevationOrDefault(endElevation, endView), containerColor, startContainerColor, endContainerColor, scrimColor, flag, elevationShadowEnabled, FadeModeEvaluators.get(fadeMode, flag), FitModeEvaluators.get(fitMode, flag, rectf, rectf1), buildThresholdsGroup(flag), drawDebugEnabled);
                    transitionDrawable.setBounds(Math.round(((RectF) (transitionvalues)).left), Math.round(((RectF) (transitionvalues)).top), Math.round(((RectF) (transitionvalues)).right), Math.round(((RectF) (transitionvalues)).bottom));
                    transitionvalues = ValueAnimator.ofFloat(new float[] {
                        0.0F, 1.0F
                    });
                    transitionvalues.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {

                        final MaterialContainerTransform this$0;
                        final TransitionDrawable val$transitionDrawable;

                        public void onAnimationUpdate(ValueAnimator valueanimator)
                        {
                            transitionDrawable.setProgress(valueanimator.getAnimatedFraction());
                        }

            
            {
                this$0 = MaterialContainerTransform.this;
                transitionDrawable = transitiondrawable;
                super();
            }
                    });
                    addListener(new TransitionListenerAdapter() {

                        final MaterialContainerTransform this$0;
                        final View val$drawingView;
                        final View val$endView;
                        final View val$startView;
                        final TransitionDrawable val$transitionDrawable;

                        public void onTransitionEnd(Transition transition)
                        {
                            removeListener(this);
                            if (holdAtEndEnabled)
                            {
                                return;
                            } else
                            {
                                startView.setAlpha(1.0F);
                                endView.setAlpha(1.0F);
                                ViewUtils.getOverlay(drawingView).remove(transitionDrawable);
                                return;
                            }
                        }

                        public void onTransitionStart(Transition transition)
                        {
                            ViewUtils.getOverlay(drawingView).add(transitionDrawable);
                            startView.setAlpha(0.0F);
                            endView.setAlpha(0.0F);
                        }

            
            {
                this$0 = MaterialContainerTransform.this;
                drawingView = view;
                transitionDrawable = transitiondrawable;
                startView = view1;
                endView = view2;
                super();
            }
                    });
                    return transitionvalues;
                } else
                {
                    Log.w(TAG, "Skipping due to null end bounds. Ensure end view is laid out and measured.");
                    return null;
                }
            } else
            {
                Log.w(TAG, "Skipping due to null start bounds. Ensure start view is laid out and measured.");
                return null;
            }
        } else
        {
            return null;
        }
    }

    public int getContainerColor()
    {
        return containerColor;
    }

    public int getDrawingViewId()
    {
        return drawingViewId;
    }

    public int getEndContainerColor()
    {
        return endContainerColor;
    }

    public float getEndElevation()
    {
        return endElevation;
    }

    public ShapeAppearanceModel getEndShapeAppearanceModel()
    {
        return endShapeAppearanceModel;
    }

    public View getEndView()
    {
        return endView;
    }

    public int getEndViewId()
    {
        return endViewId;
    }

    public int getFadeMode()
    {
        return fadeMode;
    }

    public ProgressThresholds getFadeProgressThresholds()
    {
        return fadeProgressThresholds;
    }

    public int getFitMode()
    {
        return fitMode;
    }

    public ProgressThresholds getScaleMaskProgressThresholds()
    {
        return scaleMaskProgressThresholds;
    }

    public ProgressThresholds getScaleProgressThresholds()
    {
        return scaleProgressThresholds;
    }

    public int getScrimColor()
    {
        return scrimColor;
    }

    public ProgressThresholds getShapeMaskProgressThresholds()
    {
        return shapeMaskProgressThresholds;
    }

    public int getStartContainerColor()
    {
        return startContainerColor;
    }

    public float getStartElevation()
    {
        return startElevation;
    }

    public ShapeAppearanceModel getStartShapeAppearanceModel()
    {
        return startShapeAppearanceModel;
    }

    public View getStartView()
    {
        return startView;
    }

    public int getStartViewId()
    {
        return startViewId;
    }

    public int getTransitionDirection()
    {
        return transitionDirection;
    }

    public String[] getTransitionProperties()
    {
        return TRANSITION_PROPS;
    }

    public boolean isDrawDebugEnabled()
    {
        return drawDebugEnabled;
    }

    public boolean isElevationShadowEnabled()
    {
        return elevationShadowEnabled;
    }

    public boolean isHoldAtEndEnabled()
    {
        return holdAtEndEnabled;
    }

    public void setAllContainerColors(int i)
    {
        containerColor = i;
        startContainerColor = i;
        endContainerColor = i;
    }

    public void setContainerColor(int i)
    {
        containerColor = i;
    }

    public void setDrawDebugEnabled(boolean flag)
    {
        drawDebugEnabled = flag;
    }

    public void setDrawingViewId(int i)
    {
        drawingViewId = i;
    }

    public void setElevationShadowEnabled(boolean flag)
    {
        elevationShadowEnabled = flag;
    }

    public void setEndContainerColor(int i)
    {
        endContainerColor = i;
    }

    public void setEndElevation(float f)
    {
        endElevation = f;
    }

    public void setEndShapeAppearanceModel(ShapeAppearanceModel shapeappearancemodel)
    {
        endShapeAppearanceModel = shapeappearancemodel;
    }

    public void setEndView(View view)
    {
        endView = view;
    }

    public void setEndViewId(int i)
    {
        endViewId = i;
    }

    public void setFadeMode(int i)
    {
        fadeMode = i;
    }

    public void setFadeProgressThresholds(ProgressThresholds progressthresholds)
    {
        fadeProgressThresholds = progressthresholds;
    }

    public void setFitMode(int i)
    {
        fitMode = i;
    }

    public void setHoldAtEndEnabled(boolean flag)
    {
        holdAtEndEnabled = flag;
    }

    public void setScaleMaskProgressThresholds(ProgressThresholds progressthresholds)
    {
        scaleMaskProgressThresholds = progressthresholds;
    }

    public void setScaleProgressThresholds(ProgressThresholds progressthresholds)
    {
        scaleProgressThresholds = progressthresholds;
    }

    public void setScrimColor(int i)
    {
        scrimColor = i;
    }

    public void setShapeMaskProgressThresholds(ProgressThresholds progressthresholds)
    {
        shapeMaskProgressThresholds = progressthresholds;
    }

    public void setStartContainerColor(int i)
    {
        startContainerColor = i;
    }

    public void setStartElevation(float f)
    {
        startElevation = f;
    }

    public void setStartShapeAppearanceModel(ShapeAppearanceModel shapeappearancemodel)
    {
        startShapeAppearanceModel = shapeappearancemodel;
    }

    public void setStartView(View view)
    {
        startView = view;
    }

    public void setStartViewId(int i)
    {
        startViewId = i;
    }

    public void setTransitionDirection(int i)
    {
        transitionDirection = i;
    }


}
