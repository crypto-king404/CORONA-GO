// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.transition.Transition;
import android.view.Window;

// Referenced classes of package com.google.android.material.transition.platform:
//            TransitionListenerAdapter, MaterialContainerTransformSharedElementCallback

class val.window extends TransitionListenerAdapter
{

    final MaterialContainerTransformSharedElementCallback this$0;
    final Window val$window;

    public void onTransitionStart(Transition transition)
    {
        MaterialContainerTransformSharedElementCallback.access$000(val$window);
    }

    ()
    {
        this$0 = final_materialcontainertransformsharedelementcallback;
        val$window = Window.this;
        super();
    }
}
