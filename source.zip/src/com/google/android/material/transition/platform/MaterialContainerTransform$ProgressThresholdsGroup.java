// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;


// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialContainerTransform

private static class <init>
{

    private final <init> fade;
    private final <init> scale;
    private final <init> scaleMask;
    private final <init> shapeMask;





    private ( ,  1,  2,  3)
    {
        fade = ;
        scale = 1;
        scaleMask = 2;
        shapeMask = 3;
    }

    shapeMask(shapeMask shapemask, shapeMask shapemask1, shapeMask shapemask2, shapeMask shapemask3, shapeMask shapemask4)
    {
        this(shapemask, shapemask1, shapemask2, shapemask3);
    }
}
