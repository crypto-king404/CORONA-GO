// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.graphics.RectF;

// Referenced classes of package com.google.android.material.transition.platform:
//            FitModeEvaluator, FitModeEvaluators, FitModeResult, TransitionUtils

static final class I
    implements FitModeEvaluator
{

    public void applyMask(RectF rectf, float f, FitModeResult fitmoderesult)
    {
        float f1 = Math.abs(fitmoderesult.currentEndHeight - fitmoderesult.currentStartHeight);
        rectf.bottom = rectf.bottom - f1 * f;
    }

    public FitModeResult evaluate(float f, float f1, float f2, float f3, float f4, float f5, float f6)
    {
        f = TransitionUtils.lerp(f3, f5, f1, f2, f);
        f1 = f / f3;
        f2 = f / f5;
        return new FitModeResult(f1, f2, f, f4 * f1, f, f6 * f2);
    }

    public boolean shouldMaskStartBounds(FitModeResult fitmoderesult)
    {
        return fitmoderesult.currentStartHeight > fitmoderesult.currentEndHeight;
    }

    I()
    {
    }
}
