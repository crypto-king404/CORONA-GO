// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.graphics.RectF;

// Referenced classes of package com.google.android.material.transition.platform:
//            FitModeEvaluator, FitModeEvaluators, FitModeResult, TransitionUtils

static final class I
    implements FitModeEvaluator
{

    public void applyMask(RectF rectf, float f, FitModeResult fitmoderesult)
    {
        float f1 = Math.abs(fitmoderesult.currentEndWidth - fitmoderesult.currentStartWidth);
        rectf.left = rectf.left + (f1 / 2.0F) * f;
        rectf.right = rectf.right - (f1 / 2.0F) * f;
    }

    public FitModeResult evaluate(float f, float f1, float f2, float f3, float f4, float f5, float f6)
    {
        f = TransitionUtils.lerp(f4, f6, f1, f2, f);
        f1 = f / f4;
        f2 = f / f6;
        return new FitModeResult(f1, f2, f3 * f1, f, f5 * f2, f);
    }

    public boolean shouldMaskStartBounds(FitModeResult fitmoderesult)
    {
        return fitmoderesult.currentStartWidth > fitmoderesult.currentEndWidth;
    }

    I()
    {
    }
}
