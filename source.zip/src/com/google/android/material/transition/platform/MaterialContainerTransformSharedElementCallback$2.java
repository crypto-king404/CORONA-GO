// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.app.Activity;
import android.transition.Transition;
import android.view.View;
import java.lang.ref.WeakReference;

// Referenced classes of package com.google.android.material.transition.platform:
//            TransitionListenerAdapter, MaterialContainerTransformSharedElementCallback

class val.activity extends TransitionListenerAdapter
{

    final MaterialContainerTransformSharedElementCallback this$0;
    final Activity val$activity;

    public void onTransitionEnd(Transition transition)
    {
        if (MaterialContainerTransformSharedElementCallback.access$200() != null)
        {
            transition = (View)MaterialContainerTransformSharedElementCallback.access$200().get();
            if (transition != null)
            {
                transition.setAlpha(1.0F);
                WeakReference _tmp = MaterialContainerTransformSharedElementCallback.access$202(null);
            }
        }
        val$activity.finish();
        val$activity.overridePendingTransition(0, 0);
    }

    ()
    {
        this$0 = final_materialcontainertransformsharedelementcallback;
        val$activity = Activity.this;
        super();
    }
}
