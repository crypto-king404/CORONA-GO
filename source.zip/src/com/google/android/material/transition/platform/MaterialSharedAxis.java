// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;
import java.lang.annotation.Annotation;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialVisibility, ScaleProvider, SlideDistanceProvider, FadeThroughProvider, 
//            VisibilityAnimatorProvider

public final class MaterialSharedAxis extends MaterialVisibility
{
    public static interface Axis
        extends Annotation
    {
    }


    public static final int X = 0;
    public static final int Y = 1;
    public static final int Z = 2;
    private final int axis;
    private final boolean forward;

    public MaterialSharedAxis(int i, boolean flag)
    {
        super(createPrimaryAnimatorProvider(i, flag), createSecondaryAnimatorProvider());
        axis = i;
        forward = flag;
    }

    private static VisibilityAnimatorProvider createPrimaryAnimatorProvider(int i, boolean flag)
    {
        if (i != 0)
        {
            if (i != 1)
            {
                if (i == 2)
                {
                    return new ScaleProvider(flag);
                } else
                {
                    StringBuilder stringbuilder = new StringBuilder();
                    stringbuilder.append("Invalid axis: ");
                    stringbuilder.append(i);
                    throw new IllegalArgumentException(stringbuilder.toString());
                }
            }
            if (flag)
            {
                i = 80;
            } else
            {
                i = 48;
            }
            return new SlideDistanceProvider(i);
        }
        if (flag)
        {
            i = 0x800005;
        } else
        {
            i = 0x800003;
        }
        return new SlideDistanceProvider(i);
    }

    private static VisibilityAnimatorProvider createSecondaryAnimatorProvider()
    {
        return new FadeThroughProvider();
    }

    public int getAxis()
    {
        return axis;
    }

    public volatile VisibilityAnimatorProvider getPrimaryAnimatorProvider()
    {
        return super.getPrimaryAnimatorProvider();
    }

    public volatile VisibilityAnimatorProvider getSecondaryAnimatorProvider()
    {
        return super.getSecondaryAnimatorProvider();
    }

    public boolean isForward()
    {
        return forward;
    }

    public volatile Animator onAppear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onAppear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile Animator onDisappear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onDisappear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile void setSecondaryAnimatorProvider(VisibilityAnimatorProvider visibilityanimatorprovider)
    {
        super.setSecondaryAnimatorProvider(visibilityanimatorprovider);
    }
}
