// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewGroup;

// Referenced classes of package com.google.android.material.transition.platform:
//            VisibilityAnimatorProvider, TransitionUtils

public final class FadeProvider
    implements VisibilityAnimatorProvider
{

    private float incomingEndThreshold;

    public FadeProvider()
    {
        incomingEndThreshold = 1.0F;
    }

    private static Animator createFadeAnimator(View view, float f, float f1, float f2, float f3)
    {
        ValueAnimator valueanimator = ValueAnimator.ofFloat(new float[] {
            0.0F, 1.0F
        });
        valueanimator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener(view, f, f1, f2, f3) {

            final float val$endFraction;
            final float val$endValue;
            final float val$startFraction;
            final float val$startValue;
            final View val$view;

            public void onAnimationUpdate(ValueAnimator valueanimator1)
            {
                float f4 = ((Float)valueanimator1.getAnimatedValue()).floatValue();
                view.setAlpha(TransitionUtils.lerp(startValue, endValue, startFraction, endFraction, f4));
            }

            
            {
                view = view1;
                startValue = f;
                endValue = f1;
                startFraction = f2;
                endFraction = f3;
                super();
            }
        });
        return valueanimator;
    }

    public Animator createAppear(ViewGroup viewgroup, View view)
    {
        return createFadeAnimator(view, 0.0F, 1.0F, 0.0F, incomingEndThreshold);
    }

    public Animator createDisappear(ViewGroup viewgroup, View view)
    {
        return createFadeAnimator(view, 1.0F, 0.0F, 0.0F, 1.0F);
    }

    public float getIncomingEndThreshold()
    {
        return incomingEndThreshold;
    }

    public void setIncomingEndThreshold(float f)
    {
        incomingEndThreshold = f;
    }
}
