// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.transition.Transition;

abstract class TransitionListenerAdapter
    implements android.transition.Transition.TransitionListener
{

    TransitionListenerAdapter()
    {
    }

    public void onTransitionCancel(Transition transition)
    {
    }

    public void onTransitionEnd(Transition transition)
    {
    }

    public void onTransitionPause(Transition transition)
    {
    }

    public void onTransitionResume(Transition transition)
    {
    }

    public void onTransitionStart(Transition transition)
    {
    }
}
