// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.animation.AnimationUtils;
import com.google.android.material.animation.AnimatorSetCompat;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.android.material.transition.platform:
//            VisibilityAnimatorProvider

abstract class MaterialVisibility extends Visibility
{

    private final VisibilityAnimatorProvider primaryAnimatorProvider;
    private VisibilityAnimatorProvider secondaryAnimatorProvider;

    protected MaterialVisibility(VisibilityAnimatorProvider visibilityanimatorprovider, VisibilityAnimatorProvider visibilityanimatorprovider1)
    {
        primaryAnimatorProvider = visibilityanimatorprovider;
        secondaryAnimatorProvider = visibilityanimatorprovider1;
        setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
    }

    private Animator createAnimator(ViewGroup viewgroup, View view, boolean flag)
    {
        AnimatorSet animatorset = new AnimatorSet();
        ArrayList arraylist = new ArrayList();
        Object obj;
        if (flag)
        {
            obj = primaryAnimatorProvider.createAppear(viewgroup, view);
        } else
        {
            obj = primaryAnimatorProvider.createDisappear(viewgroup, view);
        }
        if (obj != null)
        {
            arraylist.add(obj);
        }
        obj = secondaryAnimatorProvider;
        if (obj != null)
        {
            if (flag)
            {
                viewgroup = ((VisibilityAnimatorProvider) (obj)).createAppear(viewgroup, view);
            } else
            {
                viewgroup = ((VisibilityAnimatorProvider) (obj)).createDisappear(viewgroup, view);
            }
            if (viewgroup != null)
            {
                arraylist.add(viewgroup);
            }
        }
        AnimatorSetCompat.playTogether(animatorset, arraylist);
        return animatorset;
    }

    public VisibilityAnimatorProvider getPrimaryAnimatorProvider()
    {
        return primaryAnimatorProvider;
    }

    public VisibilityAnimatorProvider getSecondaryAnimatorProvider()
    {
        return secondaryAnimatorProvider;
    }

    public Animator onAppear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return createAnimator(viewgroup, view, true);
    }

    public Animator onDisappear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return createAnimator(viewgroup, view, false);
    }

    public void setSecondaryAnimatorProvider(VisibilityAnimatorProvider visibilityanimatorprovider)
    {
        secondaryAnimatorProvider = visibilityanimatorprovider;
    }
}
