// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.transition.Transition;
import android.transition.TransitionSet;
import android.view.View;
import com.google.android.material.shape.AbsoluteCornerSize;
import com.google.android.material.shape.CornerSize;
import com.google.android.material.shape.RelativeCornerSize;
import com.google.android.material.shape.ShapeAppearanceModel;

class TransitionUtils
{
    static interface CanvasOperation
    {

        public abstract void run(Canvas canvas);
    }

    static interface CornerSizeBinaryOperator
    {

        public abstract CornerSize apply(CornerSize cornersize, CornerSize cornersize1);
    }


    private static final RectF transformAlphaRectF = new RectF();

    private TransitionUtils()
    {
    }

    static float calculateArea(RectF rectf)
    {
        return rectf.width() * rectf.height();
    }

    static ShapeAppearanceModel convertToRelativeCornerSizes(ShapeAppearanceModel shapeappearancemodel, RectF rectf)
    {
        return shapeappearancemodel.withTransformedCornerSizes(new com.google.android.material.shape.ShapeAppearanceModel.CornerSizeUnaryOperator(rectf) {

            final RectF val$bounds;

            public CornerSize apply(CornerSize cornersize)
            {
                if (cornersize instanceof RelativeCornerSize)
                {
                    return cornersize;
                } else
                {
                    return new RelativeCornerSize(cornersize.getCornerSize(bounds) / bounds.height());
                }
            }

            
            {
                bounds = rectf;
                super();
            }
        });
    }

    static Shader createColorShader(int i)
    {
        return new LinearGradient(0.0F, 0.0F, 0.0F, 0.0F, i, i, android.graphics.Shader.TileMode.CLAMP);
    }

    static Object defaultIfNull(Object obj, Object obj1)
    {
        if (obj != null)
        {
            return obj;
        } else
        {
            return obj1;
        }
    }

    static View findAncestorById(View view, int i)
    {
        String s = view.getResources().getResourceName(i);
        do
        {
            if (view == null)
            {
                break;
            }
            if (view.getId() == i)
            {
                return view;
            }
            view = view.getParent();
            if (!(view instanceof View))
            {
                break;
            }
            view = (View)view;
        } while (true);
        view = new StringBuilder();
        view.append(s);
        view.append(" is not a valid ancestor");
        throw new IllegalArgumentException(view.toString());
    }

    static View findDescendantOrAncestorById(View view, int i)
    {
        View view1 = view.findViewById(i);
        if (view1 != null)
        {
            return view1;
        } else
        {
            return findAncestorById(view, i);
        }
    }

    static RectF getLocationOnScreen(View view)
    {
        int ai[] = new int[2];
        view.getLocationOnScreen(ai);
        int i = ai[0];
        int j = ai[1];
        int k = view.getWidth();
        int l = view.getHeight();
        return new RectF(i, j, k + i, l + j);
    }

    static RectF getRelativeBounds(View view)
    {
        return new RectF(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    }

    static Rect getRelativeBoundsRect(View view)
    {
        return new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    }

    private static boolean isShapeAppearanceSignificant(ShapeAppearanceModel shapeappearancemodel, RectF rectf)
    {
        return shapeappearancemodel.getTopLeftCornerSize().getCornerSize(rectf) != 0.0F || shapeappearancemodel.getTopRightCornerSize().getCornerSize(rectf) != 0.0F || shapeappearancemodel.getBottomRightCornerSize().getCornerSize(rectf) != 0.0F || shapeappearancemodel.getBottomLeftCornerSize().getCornerSize(rectf) != 0.0F;
    }

    static float lerp(float f, float f1, float f2)
    {
        return (f1 - f) * f2 + f;
    }

    static float lerp(float f, float f1, float f2, float f3, float f4)
    {
        if (f4 < f2)
        {
            return f;
        }
        if (f4 > f3)
        {
            return f1;
        } else
        {
            return lerp(f, f1, (f4 - f2) / (f3 - f2));
        }
    }

    static int lerp(int i, int j, float f, float f1, float f2)
    {
        if (f2 < f)
        {
            return i;
        }
        if (f2 > f1)
        {
            return j;
        } else
        {
            return (int)lerp(i, j, (f2 - f) / (f1 - f));
        }
    }

    static ShapeAppearanceModel lerp(ShapeAppearanceModel shapeappearancemodel, ShapeAppearanceModel shapeappearancemodel1, RectF rectf, RectF rectf1, float f, float f1, float f2)
    {
        if (f2 < f)
        {
            return shapeappearancemodel;
        }
        if (f2 > f1)
        {
            return shapeappearancemodel1;
        } else
        {
            return transformCornerSizes(shapeappearancemodel, shapeappearancemodel1, rectf, new CornerSizeBinaryOperator(rectf, rectf1, f, f1, f2) {

                final RectF val$endBounds;
                final float val$endFraction;
                final float val$fraction;
                final RectF val$startBounds;
                final float val$startFraction;

                public CornerSize apply(CornerSize cornersize, CornerSize cornersize1)
                {
                    return new AbsoluteCornerSize(TransitionUtils.lerp(cornersize.getCornerSize(startBounds), cornersize1.getCornerSize(endBounds), startFraction, endFraction, fraction));
                }

            
            {
                startBounds = rectf;
                endBounds = rectf1;
                startFraction = f;
                endFraction = f1;
                fraction = f2;
                super();
            }
            });
        }
    }

    static void maybeAddTransition(TransitionSet transitionset, Transition transition)
    {
        if (transition != null)
        {
            transitionset.addTransition(transition);
        }
    }

    static void maybeRemoveTransition(TransitionSet transitionset, Transition transition)
    {
        if (transition != null)
        {
            transitionset.removeTransition(transition);
        }
    }

    private static int saveLayerAlphaCompat(Canvas canvas, Rect rect, int i)
    {
        RectF rectf = transformAlphaRectF;
        rectf.set(rect);
        if (android.os.Build.VERSION.SDK_INT >= 21)
        {
            return canvas.saveLayerAlpha(rectf, i);
        } else
        {
            return canvas.saveLayerAlpha(rectf.left, rectf.top, rectf.right, rectf.bottom, i, 31);
        }
    }

    static void transform(Canvas canvas, Rect rect, float f, float f1, float f2, int i, CanvasOperation canvasoperation)
    {
        if (i <= 0)
        {
            return;
        }
        int j = canvas.save();
        canvas.translate(f, f1);
        canvas.scale(f2, f2);
        if (i < 255)
        {
            saveLayerAlphaCompat(canvas, rect, i);
        }
        canvasoperation.run(canvas);
        canvas.restoreToCount(j);
    }

    static ShapeAppearanceModel transformCornerSizes(ShapeAppearanceModel shapeappearancemodel, ShapeAppearanceModel shapeappearancemodel1, RectF rectf, CornerSizeBinaryOperator cornersizebinaryoperator)
    {
        if (isShapeAppearanceSignificant(shapeappearancemodel, rectf))
        {
            rectf = shapeappearancemodel;
        } else
        {
            rectf = shapeappearancemodel1;
        }
        return rectf.toBuilder().setTopLeftCornerSize(cornersizebinaryoperator.apply(shapeappearancemodel.getTopLeftCornerSize(), shapeappearancemodel1.getTopLeftCornerSize())).setTopRightCornerSize(cornersizebinaryoperator.apply(shapeappearancemodel.getTopRightCornerSize(), shapeappearancemodel1.getTopRightCornerSize())).setBottomLeftCornerSize(cornersizebinaryoperator.apply(shapeappearancemodel.getBottomLeftCornerSize(), shapeappearancemodel1.getBottomLeftCornerSize())).setBottomRightCornerSize(cornersizebinaryoperator.apply(shapeappearancemodel.getBottomRightCornerSize(), shapeappearancemodel1.getBottomRightCornerSize())).build();
    }

}
