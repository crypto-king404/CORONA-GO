// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.graphics.Path;
import android.graphics.PointF;
import android.transition.PathMotion;

public final class MaterialArcMotion extends PathMotion
{

    public MaterialArcMotion()
    {
    }

    private static PointF getControlPoint(float f, float f1, float f2, float f3)
    {
        if (f1 > f3)
        {
            return new PointF(f2, f1);
        } else
        {
            return new PointF(f, f3);
        }
    }

    public Path getPath(float f, float f1, float f2, float f3)
    {
        Path path = new Path();
        path.moveTo(f, f1);
        PointF pointf = getControlPoint(f, f1, f2, f3);
        path.quadTo(pointf.x, pointf.y, f2, f3);
        return path;
    }
}
