// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialVisibility, FadeThroughProvider, ScaleProvider, VisibilityAnimatorProvider

public final class MaterialFadeThrough extends MaterialVisibility
{

    private static final float DEFAULT_START_SCALE = 0.92F;

    public MaterialFadeThrough()
    {
        super(createPrimaryAnimatorProvider(), createSecondaryAnimatorProvider());
    }

    private static FadeThroughProvider createPrimaryAnimatorProvider()
    {
        return new FadeThroughProvider();
    }

    private static VisibilityAnimatorProvider createSecondaryAnimatorProvider()
    {
        ScaleProvider scaleprovider = new ScaleProvider();
        scaleprovider.setScaleOnDisappear(false);
        scaleprovider.setIncomingStartScale(0.92F);
        return scaleprovider;
    }

    public volatile VisibilityAnimatorProvider getSecondaryAnimatorProvider()
    {
        return super.getSecondaryAnimatorProvider();
    }

    public volatile Animator onAppear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onAppear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile Animator onDisappear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onDisappear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile void setSecondaryAnimatorProvider(VisibilityAnimatorProvider visibilityanimatorprovider)
    {
        super.setSecondaryAnimatorProvider(visibilityanimatorprovider);
    }
}
