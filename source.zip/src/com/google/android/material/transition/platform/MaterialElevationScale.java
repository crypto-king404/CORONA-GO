// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.Animator;
import android.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialVisibility, ScaleProvider, FadeProvider, VisibilityAnimatorProvider

public final class MaterialElevationScale extends MaterialVisibility
{

    private static final float DEFAULT_SCALE = 0.85F;
    private final boolean growing;

    public MaterialElevationScale(boolean flag)
    {
        super(createPrimaryAnimatorProvider(flag), createSecondaryAnimatorProvider());
        growing = flag;
    }

    private static ScaleProvider createPrimaryAnimatorProvider(boolean flag)
    {
        ScaleProvider scaleprovider = new ScaleProvider(flag);
        scaleprovider.setOutgoingEndScale(0.85F);
        scaleprovider.setIncomingStartScale(0.85F);
        return scaleprovider;
    }

    private static VisibilityAnimatorProvider createSecondaryAnimatorProvider()
    {
        return new FadeProvider();
    }

    public volatile VisibilityAnimatorProvider getSecondaryAnimatorProvider()
    {
        return super.getSecondaryAnimatorProvider();
    }

    public boolean isGrowing()
    {
        return growing;
    }

    public volatile Animator onAppear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onAppear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile Animator onDisappear(ViewGroup viewgroup, View view, TransitionValues transitionvalues, TransitionValues transitionvalues1)
    {
        return super.onDisappear(viewgroup, view, transitionvalues, transitionvalues1);
    }

    public volatile void setSecondaryAnimatorProvider(VisibilityAnimatorProvider visibilityanimatorprovider)
    {
        super.setSecondaryAnimatorProvider(visibilityanimatorprovider);
    }
}
