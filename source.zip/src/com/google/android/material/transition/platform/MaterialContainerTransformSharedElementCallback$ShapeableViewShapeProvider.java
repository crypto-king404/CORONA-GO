// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.view.View;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialContainerTransformSharedElementCallback

public static class 
    implements 
{

    public ShapeAppearanceModel provideShape(View view)
    {
        if (view instanceof Shapeable)
        {
            return ((Shapeable)view).getShapeAppearanceModel();
        } else
        {
            return null;
        }
    }

    public ()
    {
    }
}
