// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.transition.Transition;
import android.view.View;
import android.view.Window;
import androidx.core.graphics.BlendModeColorFilterCompat;
import androidx.core.graphics.BlendModeCompat;
import com.google.android.material.internal.ContextUtils;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialContainerTransform, TransitionUtils, TransitionListenerAdapter

public class MaterialContainerTransformSharedElementCallback extends SharedElementCallback
{
    public static interface ShapeProvider
    {

        public abstract ShapeAppearanceModel provideShape(View view);
    }

    public static class ShapeableViewShapeProvider
        implements ShapeProvider
    {

        public ShapeAppearanceModel provideShape(View view)
        {
            if (view instanceof Shapeable)
            {
                return ((Shapeable)view).getShapeAppearanceModel();
            } else
            {
                return null;
            }
        }

        public ShapeableViewShapeProvider()
        {
        }
    }


    private static WeakReference capturedSharedElement;
    private boolean entering;
    private Rect returnEndBounds;
    private ShapeProvider shapeProvider;
    private boolean sharedElementReenterTransitionEnabled;
    private boolean transparentWindowBackgroundEnabled;

    public MaterialContainerTransformSharedElementCallback()
    {
        entering = true;
        transparentWindowBackgroundEnabled = true;
        sharedElementReenterTransitionEnabled = false;
        shapeProvider = new ShapeableViewShapeProvider();
    }

    private static void removeWindowBackground(Window window)
    {
        window.getDecorView().getBackground().mutate().setColorFilter(BlendModeColorFilterCompat.createBlendModeColorFilterCompat(0, BlendModeCompat.CLEAR));
    }

    private static void restoreWindowBackground(Window window)
    {
        window.getDecorView().getBackground().mutate().clearColorFilter();
    }

    private void setUpEnterTransform(final Window window)
    {
        Object obj = window.getSharedElementEnterTransition();
        if (obj instanceof MaterialContainerTransform)
        {
            obj = (MaterialContainerTransform)obj;
            if (!sharedElementReenterTransitionEnabled)
            {
                window.setSharedElementReenterTransition(null);
            }
            if (transparentWindowBackgroundEnabled)
            {
                updateBackgroundFadeDuration(window, ((MaterialContainerTransform) (obj)));
                ((MaterialContainerTransform) (obj)).addListener(new TransitionListenerAdapter() {

                    final MaterialContainerTransformSharedElementCallback this$0;
                    final Window val$window;

                    public void onTransitionEnd(Transition transition)
                    {
                        MaterialContainerTransformSharedElementCallback.restoreWindowBackground(window);
                    }

                    public void onTransitionStart(Transition transition)
                    {
                        MaterialContainerTransformSharedElementCallback.removeWindowBackground(window);
                    }

            
            {
                this$0 = MaterialContainerTransformSharedElementCallback.this;
                window = window1;
                super();
            }
                });
            }
        }
    }

    private void setUpReturnTransform(final Activity activity, final Window window)
    {
        Object obj = window.getSharedElementReturnTransition();
        if (obj instanceof MaterialContainerTransform)
        {
            obj = (MaterialContainerTransform)obj;
            ((MaterialContainerTransform) (obj)).setHoldAtEndEnabled(true);
            ((MaterialContainerTransform) (obj)).addListener(new TransitionListenerAdapter() {

                final MaterialContainerTransformSharedElementCallback this$0;
                final Activity val$activity;

                public void onTransitionEnd(Transition transition)
                {
                    if (MaterialContainerTransformSharedElementCallback.capturedSharedElement != null)
                    {
                        transition = (View)MaterialContainerTransformSharedElementCallback.capturedSharedElement.get();
                        if (transition != null)
                        {
                            transition.setAlpha(1.0F);
                            MaterialContainerTransformSharedElementCallback.capturedSharedElement = null;
                        }
                    }
                    activity.finish();
                    activity.overridePendingTransition(0, 0);
                }

            
            {
                this$0 = MaterialContainerTransformSharedElementCallback.this;
                activity = activity1;
                super();
            }
            });
            if (transparentWindowBackgroundEnabled)
            {
                updateBackgroundFadeDuration(window, ((MaterialContainerTransform) (obj)));
                ((MaterialContainerTransform) (obj)).addListener(new TransitionListenerAdapter() {

                    final MaterialContainerTransformSharedElementCallback this$0;
                    final Window val$window;

                    public void onTransitionStart(Transition transition)
                    {
                        MaterialContainerTransformSharedElementCallback.removeWindowBackground(window);
                    }

            
            {
                this$0 = MaterialContainerTransformSharedElementCallback.this;
                window = window1;
                super();
            }
                });
            }
        }
    }

    private static void updateBackgroundFadeDuration(Window window, MaterialContainerTransform materialcontainertransform)
    {
        window.setTransitionBackgroundFadeDuration(materialcontainertransform.getDuration());
    }

    public ShapeProvider getShapeProvider()
    {
        return shapeProvider;
    }

    public boolean isSharedElementReenterTransitionEnabled()
    {
        return sharedElementReenterTransitionEnabled;
    }

    public boolean isTransparentWindowBackgroundEnabled()
    {
        return transparentWindowBackgroundEnabled;
    }

    public Parcelable onCaptureSharedElementSnapshot(View view, Matrix matrix, RectF rectf)
    {
        capturedSharedElement = new WeakReference(view);
        return super.onCaptureSharedElementSnapshot(view, matrix, rectf);
    }

    public View onCreateSnapshotView(Context context, Parcelable parcelable)
    {
        context = super.onCreateSnapshotView(context, parcelable);
        if (context != null)
        {
            parcelable = capturedSharedElement;
            if (parcelable != null && shapeProvider != null)
            {
                parcelable = (View)parcelable.get();
                if (parcelable != null)
                {
                    parcelable = shapeProvider.provideShape(parcelable);
                    if (parcelable != null)
                    {
                        context.setTag(com.google.android.material.R.id.mtrl_motion_snapshot_view, parcelable);
                    }
                }
            }
        }
        return context;
    }

    public void onMapSharedElements(List list, Map map)
    {
        if (!list.isEmpty() && !map.isEmpty())
        {
            list = (View)map.get(list.get(0));
            if (list != null)
            {
                list = ContextUtils.getActivity(list.getContext());
                if (list != null)
                {
                    map = list.getWindow();
                    if (entering)
                    {
                        setUpEnterTransform(map);
                        return;
                    }
                    setUpReturnTransform(list, map);
                }
            }
        }
    }

    public void onSharedElementEnd(List list, List list1, List list2)
    {
        if (!list1.isEmpty() && (((View)list1.get(0)).getTag(com.google.android.material.R.id.mtrl_motion_snapshot_view) instanceof View))
        {
            ((View)list1.get(0)).setTag(com.google.android.material.R.id.mtrl_motion_snapshot_view, null);
        }
        if (!entering && !list1.isEmpty())
        {
            returnEndBounds = TransitionUtils.getRelativeBoundsRect((View)list1.get(0));
        }
        entering = false;
    }

    public void onSharedElementStart(List list, List list1, List list2)
    {
        if (!list1.isEmpty() && !list2.isEmpty())
        {
            ((View)list1.get(0)).setTag(com.google.android.material.R.id.mtrl_motion_snapshot_view, list2.get(0));
        }
        if (!entering && !list1.isEmpty() && returnEndBounds != null)
        {
            list = (View)list1.get(0);
            list.measure(android.view.View.MeasureSpec.makeMeasureSpec(returnEndBounds.width(), 0x40000000), android.view.View.MeasureSpec.makeMeasureSpec(returnEndBounds.height(), 0x40000000));
            list.layout(returnEndBounds.left, returnEndBounds.top, returnEndBounds.right, returnEndBounds.bottom);
        }
    }

    public void setShapeProvider(ShapeProvider shapeprovider)
    {
        shapeProvider = shapeprovider;
    }

    public void setSharedElementReenterTransitionEnabled(boolean flag)
    {
        sharedElementReenterTransitionEnabled = flag;
    }

    public void setTransparentWindowBackgroundEnabled(boolean flag)
    {
        transparentWindowBackgroundEnabled = flag;
    }





/*
    static WeakReference access$202(WeakReference weakreference)
    {
        capturedSharedElement = weakreference;
        return weakreference;
    }

*/
}
