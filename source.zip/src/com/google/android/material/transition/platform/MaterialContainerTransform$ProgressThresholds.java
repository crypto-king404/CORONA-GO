// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;


// Referenced classes of package com.google.android.material.transition.platform:
//            MaterialContainerTransform

public static class end
{

    private final float end;
    private final float start;

    public float getEnd()
    {
        return end;
    }

    public float getStart()
    {
        return start;
    }



    public (float f, float f1)
    {
        start = f;
        end = f1;
    }
}
