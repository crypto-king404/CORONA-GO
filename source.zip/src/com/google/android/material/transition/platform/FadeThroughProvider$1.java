// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition.platform;

import android.animation.ValueAnimator;
import android.view.View;

// Referenced classes of package com.google.android.material.transition.platform:
//            FadeThroughProvider, TransitionUtils

static final class val.endFraction
    implements android.animation.UpdateListener
{

    final float val$endFraction;
    final float val$endValue;
    final float val$startFraction;
    final float val$startValue;
    final View val$view;

    public void onAnimationUpdate(ValueAnimator valueanimator)
    {
        float f = ((Float)valueanimator.getAnimatedValue()).floatValue();
        val$view.setAlpha(TransitionUtils.lerp(val$startValue, val$endValue, val$startFraction, val$endFraction, f));
    }

    (View view1, float f, float f1, float f2, float f3)
    {
        val$view = view1;
        val$startValue = f;
        val$endValue = f1;
        val$startFraction = f2;
        val$endFraction = f3;
        super();
    }
}
