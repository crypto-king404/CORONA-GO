// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.view.View;
import android.view.ViewGroup;

// Referenced classes of package com.google.android.material.transition:
//            VisibilityAnimatorProvider

public final class ScaleProvider
    implements VisibilityAnimatorProvider
{

    private boolean growing;
    private float incomingEndScale;
    private float incomingStartScale;
    private float outgoingEndScale;
    private float outgoingStartScale;
    private boolean scaleOnDisappear;

    public ScaleProvider()
    {
        this(true);
    }

    public ScaleProvider(boolean flag)
    {
        outgoingStartScale = 1.0F;
        outgoingEndScale = 1.1F;
        incomingStartScale = 0.8F;
        incomingEndScale = 1.0F;
        scaleOnDisappear = true;
        growing = flag;
    }

    private static Animator createScaleAnimator(View view, float f, float f1)
    {
        return ObjectAnimator.ofPropertyValuesHolder(view, new PropertyValuesHolder[] {
            PropertyValuesHolder.ofFloat(View.SCALE_X, new float[] {
                f, f1
            }), PropertyValuesHolder.ofFloat(View.SCALE_Y, new float[] {
                f, f1
            })
        });
    }

    public Animator createAppear(ViewGroup viewgroup, View view)
    {
        if (growing)
        {
            return createScaleAnimator(view, incomingStartScale, incomingEndScale);
        } else
        {
            return createScaleAnimator(view, outgoingEndScale, outgoingStartScale);
        }
    }

    public Animator createDisappear(ViewGroup viewgroup, View view)
    {
        if (!scaleOnDisappear)
        {
            return null;
        }
        if (growing)
        {
            return createScaleAnimator(view, outgoingStartScale, outgoingEndScale);
        } else
        {
            return createScaleAnimator(view, incomingEndScale, incomingStartScale);
        }
    }

    public float getIncomingEndScale()
    {
        return incomingEndScale;
    }

    public float getIncomingStartScale()
    {
        return incomingStartScale;
    }

    public float getOutgoingEndScale()
    {
        return outgoingEndScale;
    }

    public float getOutgoingStartScale()
    {
        return outgoingStartScale;
    }

    public boolean isGrowing()
    {
        return growing;
    }

    public boolean isScaleOnDisappear()
    {
        return scaleOnDisappear;
    }

    public void setGrowing(boolean flag)
    {
        growing = flag;
    }

    public void setIncomingEndScale(float f)
    {
        incomingEndScale = f;
    }

    public void setIncomingStartScale(float f)
    {
        incomingStartScale = f;
    }

    public void setOutgoingEndScale(float f)
    {
        outgoingEndScale = f;
    }

    public void setOutgoingStartScale(float f)
    {
        outgoingStartScale = f;
    }

    public void setScaleOnDisappear(boolean flag)
    {
        scaleOnDisappear = flag;
    }
}
