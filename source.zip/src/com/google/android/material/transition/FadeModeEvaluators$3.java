// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;


// Referenced classes of package com.google.android.material.transition:
//            FadeModeEvaluator, FadeModeEvaluators, TransitionUtils, FadeModeResult

static final class A
    implements FadeModeEvaluator
{

    public FadeModeResult evaluate(float f, float f1, float f2)
    {
        return FadeModeResult.startOnTop(TransitionUtils.lerp(255, 0, f1, f2, f), TransitionUtils.lerp(0, 255, f1, f2, f));
    }

    A()
    {
    }
}
