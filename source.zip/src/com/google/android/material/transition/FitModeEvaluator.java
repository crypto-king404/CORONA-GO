// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.graphics.RectF;

// Referenced classes of package com.google.android.material.transition:
//            FitModeResult

interface FitModeEvaluator
{

    public abstract void applyMask(RectF rectf, float f, FitModeResult fitmoderesult);

    public abstract FitModeResult evaluate(float f, float f1, float f2, float f3, float f4, float f5, float f6);

    public abstract boolean shouldMaskStartBounds(FitModeResult fitmoderesult);
}
