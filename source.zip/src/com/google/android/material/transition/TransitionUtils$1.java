// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transition;

import android.graphics.RectF;
import com.google.android.material.shape.CornerSize;
import com.google.android.material.shape.RelativeCornerSize;

// Referenced classes of package com.google.android.material.transition:
//            TransitionUtils

static final class val.bounds
    implements com.google.android.material.shape.el.CornerSizeUnaryOperator
{

    final RectF val$bounds;

    public CornerSize apply(CornerSize cornersize)
    {
        if (cornersize instanceof RelativeCornerSize)
        {
            return cornersize;
        } else
        {
            return new RelativeCornerSize(cornersize.getCornerSize(val$bounds) / val$bounds.height());
        }
    }

    rnerSizeUnaryOperator(RectF rectf)
    {
        val$bounds = rectf;
        super();
    }
}
