// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.internal.ViewUtils;
import java.lang.ref.WeakReference;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

class this._cls0
    implements android.view.ner
{

    final  this$0;

    public void onLayoutChange(View view, int i, int j, int k, int l, int i1, int j1, 
            int k1, int l1)
    {
        BottomAppBar bottomappbar = (BottomAppBar)cess._mth2100(this._cls0.this).get();
        if (bottomappbar != null && (view instanceof FloatingActionButton))
        {
            FloatingActionButton floatingactionbutton = (FloatingActionButton)view;
            floatingactionbutton.getMeasuredContentRect(cess._mth2200(this._cls0.this));
            i = cess._mth2200(this._cls0.this).height();
            bottomappbar.setFabDiameter(i);
            view = (androidx.coordinatorlayout.widget.Params)view.getLayoutParams();
            if (cess._mth2300(this._cls0.this) == 0)
            {
                i = (floatingactionbutton.getMeasuredHeight() - i) / 2;
                j = bottomappbar.getResources().getDimensionPixelOffset(com.google.android.material.r_fab_bottom_margin);
                view.bottomMargin = BottomAppBar.access$2400(bottomappbar) + (j - i);
                view.leftMargin = BottomAppBar.access$2500(bottomappbar);
                view.rightMargin = BottomAppBar.access$2600(bottomappbar);
                if (ViewUtils.isLayoutRtl(floatingactionbutton))
                {
                    view.leftMargin = ((androidx.coordinatorlayout.widget.Params) (view)).leftMargin + BottomAppBar.access$2700(bottomappbar);
                    return;
                }
                view.rightMargin = ((androidx.coordinatorlayout.widget.Params) (view)).rightMargin + BottomAppBar.access$2700(bottomappbar);
            }
            return;
        } else
        {
            view.removeOnLayoutChangeListener(this);
            return;
        }
    }

    tton()
    {
        this$0 = this._cls0.this;
        super();
    }
}
