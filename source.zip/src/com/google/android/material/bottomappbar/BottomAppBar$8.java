// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

class this._cls0 extends AnimatorListenerAdapter
{

    final BottomAppBar this$0;

    public void onAnimationStart(Animator animator)
    {
        fabAnimationListener.onAnimationStart(animator);
        animator = BottomAppBar.access$1900(BottomAppBar.this);
        if (animator != null)
        {
            animator.setTranslationX(BottomAppBar.access$2000(BottomAppBar.this));
        }
    }

    gActionButton()
    {
        this$0 = BottomAppBar.this;
        super();
    }
}
