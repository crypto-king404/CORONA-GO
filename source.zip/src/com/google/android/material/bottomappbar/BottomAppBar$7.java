// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import androidx.appcompat.widget.ActionMenuView;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

class val.targetAttached extends AnimatorListenerAdapter
{

    public boolean cancelled;
    final BottomAppBar this$0;
    final ActionMenuView val$actionMenuView;
    final boolean val$targetAttached;
    final int val$targetMode;

    public void onAnimationCancel(Animator animator)
    {
        cancelled = true;
    }

    public void onAnimationEnd(Animator animator)
    {
        if (!cancelled)
        {
            BottomAppBar.access$1800(BottomAppBar.this, val$actionMenuView, val$targetMode, val$targetAttached);
        }
    }

    ()
    {
        this$0 = final_bottomappbar;
        val$actionMenuView = actionmenuview;
        val$targetMode = i;
        val$targetAttached = Z.this;
        super();
    }
}
