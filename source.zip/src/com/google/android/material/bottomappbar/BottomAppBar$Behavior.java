// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.internal.ViewUtils;
import java.lang.ref.WeakReference;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

public static class fabContentRect extends HideBottomViewOnScrollBehavior
{

    private final Rect fabContentRect;
    private final android.view.tener fabLayoutListener;
    private int originalBottomMargin;
    private WeakReference viewRef;

    public volatile boolean onLayoutChild(CoordinatorLayout coordinatorlayout, View view, int i)
    {
        return onLayoutChild(coordinatorlayout, (BottomAppBar)view, i);
    }

    public boolean onLayoutChild(CoordinatorLayout coordinatorlayout, BottomAppBar bottomappbar, int i)
    {
        viewRef = new WeakReference(bottomappbar);
        Object obj = BottomAppBar.access$2800(bottomappbar);
        if (obj != null && !ViewCompat.isLaidOut(((View) (obj))))
        {
            androidx.coordinatorlayout.widget.utParams utparams = (androidx.coordinatorlayout.widget.utParams)((View) (obj)).getLayoutParams();
            utparams.anchorGravity = 49;
            originalBottomMargin = utparams.bottomMargin;
            if (obj instanceof FloatingActionButton)
            {
                obj = (FloatingActionButton)obj;
                ((FloatingActionButton) (obj)).addOnLayoutChangeListener(fabLayoutListener);
                BottomAppBar.access$2900(bottomappbar, ((FloatingActionButton) (obj)));
            }
            BottomAppBar.access$1200(bottomappbar);
        }
        coordinatorlayout.onLayoutChild(bottomappbar, i);
        return super.onLayoutChild(coordinatorlayout, bottomappbar, i);
    }

    public volatile boolean onStartNestedScroll(CoordinatorLayout coordinatorlayout, View view, View view1, View view2, int i, int j)
    {
        return onStartNestedScroll(coordinatorlayout, (BottomAppBar)view, view1, view2, i, j);
    }

    public boolean onStartNestedScroll(CoordinatorLayout coordinatorlayout, BottomAppBar bottomappbar, View view, View view1, int i, int j)
    {
        return bottomappbar.getHideOnScroll() && super.onStartNestedScroll(coordinatorlayout, bottomappbar, view, view1, i, j);
    }




    public _cls1.this._cls0()
    {
        fabLayoutListener = new android.view.View.OnLayoutChangeListener() {

            final BottomAppBar.Behavior this$0;

            public void onLayoutChange(View view, int i, int j, int k, int l, int i1, int j1, 
                    int k1, int l1)
            {
                BottomAppBar bottomappbar = (BottomAppBar)viewRef.get();
                if (bottomappbar != null && (view instanceof FloatingActionButton))
                {
                    FloatingActionButton floatingactionbutton = (FloatingActionButton)view;
                    floatingactionbutton.getMeasuredContentRect(fabContentRect);
                    i = fabContentRect.height();
                    bottomappbar.setFabDiameter(i);
                    view = (androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)view.getLayoutParams();
                    if (originalBottomMargin == 0)
                    {
                        i = (floatingactionbutton.getMeasuredHeight() - i) / 2;
                        j = bottomappbar.getResources().getDimensionPixelOffset(com.google.android.material.R.dimen.mtrl_bottomappbar_fab_bottom_margin);
                        view.bottomMargin = BottomAppBar.access$2400(bottomappbar) + (j - i);
                        view.leftMargin = BottomAppBar.access$2500(bottomappbar);
                        view.rightMargin = BottomAppBar.access$2600(bottomappbar);
                        if (ViewUtils.isLayoutRtl(floatingactionbutton))
                        {
                            view.leftMargin = ((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) (view)).leftMargin + BottomAppBar.access$2700(bottomappbar);
                            return;
                        }
                        view.rightMargin = ((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) (view)).rightMargin + BottomAppBar.access$2700(bottomappbar);
                    }
                    return;
                } else
                {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
            }

            
            {
                this$0 = BottomAppBar.Behavior.this;
                super();
            }
        };
        fabContentRect = new Rect();
    }

    public fabContentRect(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        fabLayoutListener = new _cls1();
        fabContentRect = new Rect();
    }
}
