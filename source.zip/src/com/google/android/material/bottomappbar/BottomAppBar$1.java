// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

class this._cls0 extends AnimatorListenerAdapter
{

    final BottomAppBar this$0;

    public void onAnimationStart(Animator animator)
    {
        animator = BottomAppBar.this;
        BottomAppBar.access$200(animator, BottomAppBar.access$000(animator), BottomAppBar.access$100(BottomAppBar.this));
    }

    ()
    {
        this$0 = BottomAppBar.this;
        super();
    }
}
