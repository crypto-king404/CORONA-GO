// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.customview.view.AbsSavedState;
import com.google.android.material.animation.TransformationCallback;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.internal.ThemeEnforcement;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.resources.MaterialResources;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.MaterialShapeUtils;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.theme.overlay.MaterialThemeOverlay;
import java.lang.annotation.Annotation;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBarTopEdgeTreatment

public class BottomAppBar extends Toolbar
    implements androidx.coordinatorlayout.widget.CoordinatorLayout.AttachedBehavior
{
    static interface AnimationListener
    {

        public abstract void onAnimationEnd(BottomAppBar bottomappbar);

        public abstract void onAnimationStart(BottomAppBar bottomappbar);
    }

    public static class Behavior extends HideBottomViewOnScrollBehavior
    {

        private final Rect fabContentRect;
        private final android.view.View.OnLayoutChangeListener fabLayoutListener;
        private int originalBottomMargin;
        private WeakReference viewRef;

        public volatile boolean onLayoutChild(CoordinatorLayout coordinatorlayout, View view, int i)
        {
            return onLayoutChild(coordinatorlayout, (BottomAppBar)view, i);
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorlayout, BottomAppBar bottomappbar, int i)
        {
            viewRef = new WeakReference(bottomappbar);
            Object obj = bottomappbar.findDependentView();
            if (obj != null && !ViewCompat.isLaidOut(((View) (obj))))
            {
                androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams layoutparams = (androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)((View) (obj)).getLayoutParams();
                layoutparams.anchorGravity = 49;
                originalBottomMargin = layoutparams.bottomMargin;
                if (obj instanceof FloatingActionButton)
                {
                    obj = (FloatingActionButton)obj;
                    ((FloatingActionButton) (obj)).addOnLayoutChangeListener(fabLayoutListener);
                    bottomappbar.addFabAnimationListeners(((FloatingActionButton) (obj)));
                }
                bottomappbar.setCutoutState();
            }
            coordinatorlayout.onLayoutChild(bottomappbar, i);
            return super.onLayoutChild(coordinatorlayout, bottomappbar, i);
        }

        public volatile boolean onStartNestedScroll(CoordinatorLayout coordinatorlayout, View view, View view1, View view2, int i, int j)
        {
            return onStartNestedScroll(coordinatorlayout, (BottomAppBar)view, view1, view2, i, j);
        }

        public boolean onStartNestedScroll(CoordinatorLayout coordinatorlayout, BottomAppBar bottomappbar, View view, View view1, int i, int j)
        {
            return bottomappbar.getHideOnScroll() && super.onStartNestedScroll(coordinatorlayout, bottomappbar, view, view1, i, j);
        }




        public Behavior()
        {
            fabLayoutListener = new _cls1();
            fabContentRect = new Rect();
        }

        public Behavior(Context context, AttributeSet attributeset)
        {
            super(context, attributeset);
            fabLayoutListener = new _cls1();
            fabContentRect = new Rect();
        }
    }

    public static interface FabAlignmentMode
        extends Annotation
    {
    }

    public static interface FabAnimationMode
        extends Annotation
    {
    }

    static class SavedState extends AbsSavedState
    {

        public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.ClassLoaderCreator() {

            public SavedState createFromParcel(Parcel parcel)
            {
                return new SavedState(parcel, null);
            }

            public SavedState createFromParcel(Parcel parcel, ClassLoader classloader)
            {
                return new SavedState(parcel, classloader);
            }

            public volatile Object createFromParcel(Parcel parcel)
            {
                return createFromParcel(parcel);
            }

            public volatile Object createFromParcel(Parcel parcel, ClassLoader classloader)
            {
                return createFromParcel(parcel, classloader);
            }

            public SavedState[] newArray(int i)
            {
                return new SavedState[i];
            }

            public volatile Object[] newArray(int i)
            {
                return newArray(i);
            }

        };
        int fabAlignmentMode;
        boolean fabAttached;

        public void writeToParcel(Parcel parcel, int i)
        {
            throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
        }


        public SavedState(Parcel parcel, ClassLoader classloader)
        {
            super(parcel, classloader);
            fabAlignmentMode = parcel.readInt();
            boolean flag;
            if (parcel.readInt() != 0)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            fabAttached = flag;
        }

        public SavedState(Parcelable parcelable)
        {
            super(parcelable);
        }
    }


    private static final long ANIMATION_DURATION = 300L;
    private static final int DEF_STYLE_RES;
    public static final int FAB_ALIGNMENT_MODE_CENTER = 0;
    public static final int FAB_ALIGNMENT_MODE_END = 1;
    public static final int FAB_ANIMATION_MODE_SCALE = 0;
    public static final int FAB_ANIMATION_MODE_SLIDE = 1;
    private int animatingModeChangeCounter;
    private ArrayList animationListeners;
    private Behavior behavior;
    private int bottomInset;
    private int fabAlignmentMode;
    AnimatorListenerAdapter fabAnimationListener = new AnimatorListenerAdapter() {

        final BottomAppBar this$0;

        public void onAnimationStart(Animator animator)
        {
            animator = BottomAppBar.this;
            animator.maybeAnimateMenuView(((BottomAppBar) (animator)).fabAlignmentMode, fabAttached);
        }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
    };
    private int fabAnimationMode;
    private boolean fabAttached;
    private final int fabOffsetEndMode;
    TransformationCallback fabTransformationCallback = new TransformationCallback() {

        final BottomAppBar this$0;

        public volatile void onScaleChanged(View view)
        {
            onScaleChanged((FloatingActionButton)view);
        }

        public void onScaleChanged(FloatingActionButton floatingactionbutton)
        {
            MaterialShapeDrawable materialshapedrawable = materialShapeDrawable;
            float f3;
            if (floatingactionbutton.getVisibility() == 0)
            {
                f3 = floatingactionbutton.getScaleY();
            } else
            {
                f3 = 0.0F;
            }
            materialshapedrawable.setInterpolation(f3);
        }

        public volatile void onTranslationChanged(View view)
        {
            onTranslationChanged((FloatingActionButton)view);
        }

        public void onTranslationChanged(FloatingActionButton floatingactionbutton)
        {
            float f3 = floatingactionbutton.getTranslationX();
            if (getTopEdgeTreatment().getHorizontalOffset() != f3)
            {
                getTopEdgeTreatment().setHorizontalOffset(f3);
                materialShapeDrawable.invalidateSelf();
            }
            float f4 = -floatingactionbutton.getTranslationY();
            f3 = 0.0F;
            f4 = Math.max(0.0F, f4);
            if (getTopEdgeTreatment().getCradleVerticalOffset() != f4)
            {
                getTopEdgeTreatment().setCradleVerticalOffset(f4);
                materialShapeDrawable.invalidateSelf();
            }
            MaterialShapeDrawable materialshapedrawable = materialShapeDrawable;
            if (floatingactionbutton.getVisibility() == 0)
            {
                f3 = floatingactionbutton.getScaleY();
            }
            materialshapedrawable.setInterpolation(f3);
        }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
    };
    private boolean hideOnScroll;
    private int leftInset;
    private final MaterialShapeDrawable materialShapeDrawable;
    private Animator menuAnimator;
    private Animator modeAnimator;
    private final boolean paddingBottomSystemWindowInsets;
    private final boolean paddingLeftSystemWindowInsets;
    private final boolean paddingRightSystemWindowInsets;
    private int rightInset;

    public BottomAppBar(Context context)
    {
        this(context, null, 0);
    }

    public BottomAppBar(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, com.google.android.material.R.attr.bottomAppBarStyle);
    }

    public BottomAppBar(Context context, AttributeSet attributeset, int i)
    {
        int j = DEF_STYLE_RES;
        super(MaterialThemeOverlay.wrap(context, attributeset, i, j), attributeset, i);
        context = new MaterialShapeDrawable();
        materialShapeDrawable = context;
        animatingModeChangeCounter = 0;
        fabAttached = true;
        Context context1 = getContext();
        Object obj = ThemeEnforcement.obtainStyledAttributes(context1, attributeset, com.google.android.material.R.styleable.BottomAppBar, i, j, new int[0]);
        ColorStateList colorstatelist = MaterialResources.getColorStateList(context1, ((TypedArray) (obj)), com.google.android.material.R.styleable.BottomAppBar_backgroundTint);
        int k = ((TypedArray) (obj)).getDimensionPixelSize(com.google.android.material.R.styleable.BottomAppBar_elevation, 0);
        float f = ((TypedArray) (obj)).getDimensionPixelOffset(com.google.android.material.R.styleable.BottomAppBar_fabCradleMargin, 0);
        float f1 = ((TypedArray) (obj)).getDimensionPixelOffset(com.google.android.material.R.styleable.BottomAppBar_fabCradleRoundedCornerRadius, 0);
        float f2 = ((TypedArray) (obj)).getDimensionPixelOffset(com.google.android.material.R.styleable.BottomAppBar_fabCradleVerticalOffset, 0);
        fabAlignmentMode = ((TypedArray) (obj)).getInt(com.google.android.material.R.styleable.BottomAppBar_fabAlignmentMode, 0);
        fabAnimationMode = ((TypedArray) (obj)).getInt(com.google.android.material.R.styleable.BottomAppBar_fabAnimationMode, 0);
        hideOnScroll = ((TypedArray) (obj)).getBoolean(com.google.android.material.R.styleable.BottomAppBar_hideOnScroll, false);
        paddingBottomSystemWindowInsets = ((TypedArray) (obj)).getBoolean(com.google.android.material.R.styleable.BottomAppBar_paddingBottomSystemWindowInsets, false);
        paddingLeftSystemWindowInsets = ((TypedArray) (obj)).getBoolean(com.google.android.material.R.styleable.BottomAppBar_paddingLeftSystemWindowInsets, false);
        paddingRightSystemWindowInsets = ((TypedArray) (obj)).getBoolean(com.google.android.material.R.styleable.BottomAppBar_paddingRightSystemWindowInsets, false);
        ((TypedArray) (obj)).recycle();
        fabOffsetEndMode = getResources().getDimensionPixelOffset(com.google.android.material.R.dimen.mtrl_bottomappbar_fabOffsetEndMode);
        obj = new BottomAppBarTopEdgeTreatment(f, f1, f2);
        context.setShapeAppearanceModel(ShapeAppearanceModel.builder().setTopEdge(((com.google.android.material.shape.EdgeTreatment) (obj))).build());
        context.setShadowCompatibilityMode(2);
        context.setPaintStyle(android.graphics.Paint.Style.FILL);
        context.initializeElevationOverlay(context1);
        setElevation(k);
        DrawableCompat.setTintList(context, colorstatelist);
        ViewCompat.setBackground(this, context);
        ViewUtils.doOnApplyWindowInsets(this, attributeset, i, j, new com.google.android.material.internal.ViewUtils.OnApplyWindowInsetsListener() {

            final BottomAppBar this$0;

            public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowinsetscompat, com.google.android.material.internal.ViewUtils.RelativePadding relativepadding)
            {
                boolean flag2 = false;
                boolean flag4 = false;
                if (paddingBottomSystemWindowInsets)
                {
                    bottomInset = windowinsetscompat.getSystemWindowInsetBottom();
                }
                boolean flag5 = paddingLeftSystemWindowInsets;
                boolean flag3 = true;
                if (flag5)
                {
                    boolean flag;
                    if (leftInset != windowinsetscompat.getSystemWindowInsetLeft())
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    leftInset = windowinsetscompat.getSystemWindowInsetLeft();
                    flag2 = flag;
                }
                boolean flag1 = flag4;
                if (paddingRightSystemWindowInsets)
                {
                    if (rightInset != windowinsetscompat.getSystemWindowInsetRight())
                    {
                        flag1 = flag3;
                    } else
                    {
                        flag1 = false;
                    }
                    rightInset = windowinsetscompat.getSystemWindowInsetRight();
                }
                if (flag2 || flag1)
                {
                    cancelAnimations();
                    setCutoutState();
                    setActionMenuViewPosition();
                }
                return windowinsetscompat;
            }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
        });
    }

    private void addFabAnimationListeners(FloatingActionButton floatingactionbutton)
    {
        floatingactionbutton.addOnHideAnimationListener(fabAnimationListener);
        floatingactionbutton.addOnShowAnimationListener(new AnimatorListenerAdapter() {

            final BottomAppBar this$0;

            public void onAnimationStart(Animator animator)
            {
                fabAnimationListener.onAnimationStart(animator);
                animator = findDependentFab();
                if (animator != null)
                {
                    animator.setTranslationX(getFabTranslationX());
                }
            }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
        });
        floatingactionbutton.addTransformationCallback(fabTransformationCallback);
    }

    private void cancelAnimations()
    {
        Animator animator = menuAnimator;
        if (animator != null)
        {
            animator.cancel();
        }
        animator = modeAnimator;
        if (animator != null)
        {
            animator.cancel();
        }
    }

    private void createFabTranslationXAnimation(int i, List list)
    {
        ObjectAnimator objectanimator = ObjectAnimator.ofFloat(findDependentFab(), "translationX", new float[] {
            getFabTranslationX(i)
        });
        objectanimator.setDuration(300L);
        list.add(objectanimator);
    }

    private void createMenuViewTranslationAnimation(final int targetMode, final boolean targetAttached, List list)
    {
        final Object actionMenuView = getActionMenuView();
        if (actionMenuView == null)
        {
            return;
        }
        ObjectAnimator objectanimator = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[] {
            1.0F
        });
        if (Math.abs(((ActionMenuView) (actionMenuView)).getTranslationX() - (float)getActionMenuViewTranslationX(((ActionMenuView) (actionMenuView)), targetMode, targetAttached)) > 1.0F)
        {
            ObjectAnimator objectanimator1 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[] {
                0.0F
            });
            objectanimator1.addListener(new AnimatorListenerAdapter() {

                public boolean cancelled;
                final BottomAppBar this$0;
                final ActionMenuView val$actionMenuView;
                final boolean val$targetAttached;
                final int val$targetMode;

                public void onAnimationCancel(Animator animator)
                {
                    cancelled = true;
                }

                public void onAnimationEnd(Animator animator)
                {
                    if (!cancelled)
                    {
                        translateActionMenuView(actionMenuView, targetMode, targetAttached);
                    }
                }

            
            {
                this$0 = BottomAppBar.this;
                actionMenuView = actionmenuview;
                targetMode = i;
                targetAttached = flag;
                super();
            }
            });
            actionMenuView = new AnimatorSet();
            ((AnimatorSet) (actionMenuView)).setDuration(150L);
            ((AnimatorSet) (actionMenuView)).playSequentially(new Animator[] {
                objectanimator1, objectanimator
            });
            list.add(actionMenuView);
        } else
        if (((ActionMenuView) (actionMenuView)).getAlpha() < 1.0F)
        {
            list.add(objectanimator);
            return;
        }
    }

    private void dispatchAnimationEnd()
    {
        int i = animatingModeChangeCounter - 1;
        animatingModeChangeCounter = i;
        if (i == 0)
        {
            Object obj = animationListeners;
            if (obj != null)
            {
                for (obj = ((ArrayList) (obj)).iterator(); ((Iterator) (obj)).hasNext(); ((AnimationListener)((Iterator) (obj)).next()).onAnimationEnd(this)) { }
            }
        }
    }

    private void dispatchAnimationStart()
    {
        int i = animatingModeChangeCounter;
        animatingModeChangeCounter = i + 1;
        if (i == 0)
        {
            Object obj = animationListeners;
            if (obj != null)
            {
                for (obj = ((ArrayList) (obj)).iterator(); ((Iterator) (obj)).hasNext(); ((AnimationListener)((Iterator) (obj)).next()).onAnimationStart(this)) { }
            }
        }
    }

    private FloatingActionButton findDependentFab()
    {
        View view = findDependentView();
        if (view instanceof FloatingActionButton)
        {
            return (FloatingActionButton)view;
        } else
        {
            return null;
        }
    }

    private View findDependentView()
    {
        if (!(getParent() instanceof CoordinatorLayout))
        {
            return null;
        }
        for (Iterator iterator = ((CoordinatorLayout)getParent()).getDependents(this).iterator(); iterator.hasNext();)
        {
            View view = (View)iterator.next();
            if (!(view instanceof FloatingActionButton))
            {
                if (view instanceof ExtendedFloatingActionButton)
                {
                    return view;
                }
            } else
            {
                return view;
            }
        }

        return null;
    }

    private ActionMenuView getActionMenuView()
    {
        for (int i = 0; i < getChildCount(); i++)
        {
            View view = getChildAt(i);
            if (view instanceof ActionMenuView)
            {
                return (ActionMenuView)view;
            }
        }

        return null;
    }

    private int getBottomInset()
    {
        return bottomInset;
    }

    private float getFabTranslationX()
    {
        return getFabTranslationX(fabAlignmentMode);
    }

    private float getFabTranslationX(int i)
    {
        boolean flag = ViewUtils.isLayoutRtl(this);
        byte byte0 = 1;
        if (i == 1)
        {
            if (flag)
            {
                i = leftInset;
            } else
            {
                i = rightInset;
            }
            int j = fabOffsetEndMode;
            int k = getMeasuredWidth() / 2;
            if (flag)
            {
                byte0 = -1;
            }
            return (float)((k - (j + i)) * byte0);
        } else
        {
            return 0.0F;
        }
    }

    private float getFabTranslationY()
    {
        return -getTopEdgeTreatment().getCradleVerticalOffset();
    }

    private int getLeftInset()
    {
        return leftInset;
    }

    private int getRightInset()
    {
        return rightInset;
    }

    private BottomAppBarTopEdgeTreatment getTopEdgeTreatment()
    {
        return (BottomAppBarTopEdgeTreatment)materialShapeDrawable.getShapeAppearanceModel().getTopEdge();
    }

    private boolean isFabVisibleOrWillBeShown()
    {
        FloatingActionButton floatingactionbutton = findDependentFab();
        return floatingactionbutton != null && floatingactionbutton.isOrWillBeShown();
    }

    private void maybeAnimateMenuView(int i, boolean flag)
    {
        if (!ViewCompat.isLaidOut(this))
        {
            return;
        }
        Object obj = menuAnimator;
        if (obj != null)
        {
            ((Animator) (obj)).cancel();
        }
        obj = new ArrayList();
        if (!isFabVisibleOrWillBeShown())
        {
            i = 0;
            flag = false;
        }
        createMenuViewTranslationAnimation(i, flag, ((List) (obj)));
        AnimatorSet animatorset = new AnimatorSet();
        animatorset.playTogether(((java.util.Collection) (obj)));
        menuAnimator = animatorset;
        animatorset.addListener(new AnimatorListenerAdapter() {

            final BottomAppBar this$0;

            public void onAnimationEnd(Animator animator)
            {
                dispatchAnimationEnd();
                menuAnimator = null;
            }

            public void onAnimationStart(Animator animator)
            {
                dispatchAnimationStart();
            }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
        });
        menuAnimator.start();
    }

    private void maybeAnimateModeChange(int i)
    {
        if (fabAlignmentMode != i)
        {
            if (!ViewCompat.isLaidOut(this))
            {
                return;
            }
            Object obj = modeAnimator;
            if (obj != null)
            {
                ((Animator) (obj)).cancel();
            }
            obj = new ArrayList();
            if (fabAnimationMode == 1)
            {
                createFabTranslationXAnimation(i, ((List) (obj)));
            } else
            {
                createFabDefaultXAnimation(i, ((List) (obj)));
            }
            AnimatorSet animatorset = new AnimatorSet();
            animatorset.playTogether(((java.util.Collection) (obj)));
            modeAnimator = animatorset;
            animatorset.addListener(new AnimatorListenerAdapter() {

                final BottomAppBar this$0;

                public void onAnimationEnd(Animator animator)
                {
                    dispatchAnimationEnd();
                }

                public void onAnimationStart(Animator animator)
                {
                    dispatchAnimationStart();
                }

            
            {
                this$0 = BottomAppBar.this;
                super();
            }
            });
            modeAnimator.start();
            return;
        } else
        {
            return;
        }
    }

    private void setActionMenuViewPosition()
    {
        ActionMenuView actionmenuview = getActionMenuView();
        if (actionmenuview != null)
        {
            actionmenuview.setAlpha(1.0F);
            if (!isFabVisibleOrWillBeShown())
            {
                translateActionMenuView(actionmenuview, 0, false);
                return;
            }
            translateActionMenuView(actionmenuview, fabAlignmentMode, fabAttached);
        }
    }

    private void setCutoutState()
    {
        getTopEdgeTreatment().setHorizontalOffset(getFabTranslationX());
        View view = findDependentView();
        MaterialShapeDrawable materialshapedrawable = materialShapeDrawable;
        float f;
        if (fabAttached && isFabVisibleOrWillBeShown())
        {
            f = 1.0F;
        } else
        {
            f = 0.0F;
        }
        materialshapedrawable.setInterpolation(f);
        if (view != null)
        {
            view.setTranslationY(getFabTranslationY());
            view.setTranslationX(getFabTranslationX());
        }
    }

    private void translateActionMenuView(ActionMenuView actionmenuview, int i, boolean flag)
    {
        actionmenuview.setTranslationX(getActionMenuViewTranslationX(actionmenuview, i, flag));
    }

    void addAnimationListener(AnimationListener animationlistener)
    {
        if (animationListeners == null)
        {
            animationListeners = new ArrayList();
        }
        animationListeners.add(animationlistener);
    }

    protected void createFabDefaultXAnimation(final int targetMode, List list)
    {
        list = findDependentFab();
        if (list != null)
        {
            if (list.isOrWillBeHidden())
            {
                return;
            } else
            {
                dispatchAnimationStart();
                list.hide(new com.google.android.material.floatingactionbutton.FloatingActionButton.OnVisibilityChangedListener() {

                    final BottomAppBar this$0;
                    final int val$targetMode;

                    public void onHidden(FloatingActionButton floatingactionbutton)
                    {
                        floatingactionbutton.setTranslationX(getFabTranslationX(targetMode));
                        floatingactionbutton.show(new com.google.android.material.floatingactionbutton.FloatingActionButton.OnVisibilityChangedListener() {

                            final _cls5 this$1;

                            public void onShown(FloatingActionButton floatingactionbutton)
                            {
                                dispatchAnimationEnd();
                            }

            
            {
                this$1 = _cls5.this;
                super();
            }
                        });
                    }

            
            {
                this$0 = BottomAppBar.this;
                targetMode = i;
                super();
            }
                });
                return;
            }
        } else
        {
            return;
        }
    }

    protected int getActionMenuViewTranslationX(ActionMenuView actionmenuview, int i, boolean flag)
    {
        if (i == 1)
        {
            if (!flag)
            {
                return 0;
            }
            flag = ViewUtils.isLayoutRtl(this);
            if (flag)
            {
                i = getMeasuredWidth();
            } else
            {
                i = 0;
            }
            for (int j = 0; j < getChildCount();)
            {
                View view = getChildAt(j);
                boolean flag1;
                if ((view.getLayoutParams() instanceof androidx.appcompat.widget.Toolbar.LayoutParams) && (((androidx.appcompat.widget.Toolbar.LayoutParams)view.getLayoutParams()).gravity & 0x800007) == 0x800003)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                int l = i;
                if (flag1)
                {
                    if (flag)
                    {
                        i = Math.min(i, view.getLeft());
                    } else
                    {
                        i = Math.max(i, view.getRight());
                    }
                    l = i;
                }
                j++;
                i = l;
            }

            int k;
            if (flag)
            {
                k = actionmenuview.getRight();
            } else
            {
                k = actionmenuview.getLeft();
            }
            int i1;
            if (flag)
            {
                i1 = rightInset;
            } else
            {
                i1 = -leftInset;
            }
            return i - (k + i1);
        } else
        {
            return 0;
        }
    }

    public ColorStateList getBackgroundTint()
    {
        return materialShapeDrawable.getTintList();
    }

    public volatile androidx.coordinatorlayout.widget.CoordinatorLayout.Behavior getBehavior()
    {
        return getBehavior();
    }

    public Behavior getBehavior()
    {
        if (behavior == null)
        {
            behavior = new Behavior();
        }
        return behavior;
    }

    public float getCradleVerticalOffset()
    {
        return getTopEdgeTreatment().getCradleVerticalOffset();
    }

    public int getFabAlignmentMode()
    {
        return fabAlignmentMode;
    }

    public int getFabAnimationMode()
    {
        return fabAnimationMode;
    }

    public float getFabCradleMargin()
    {
        return getTopEdgeTreatment().getFabCradleMargin();
    }

    public float getFabCradleRoundedCornerRadius()
    {
        return getTopEdgeTreatment().getFabCradleRoundedCornerRadius();
    }

    public boolean getHideOnScroll()
    {
        return hideOnScroll;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        MaterialShapeUtils.setParentAbsoluteElevation(this, materialShapeDrawable);
        if (getParent() instanceof ViewGroup)
        {
            ((ViewGroup)getParent()).setClipChildren(false);
        }
    }

    protected void onLayout(boolean flag, int i, int j, int k, int l)
    {
        super.onLayout(flag, i, j, k, l);
        if (flag)
        {
            cancelAnimations();
            setCutoutState();
        }
        setActionMenuViewPosition();
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        if (!(parcelable instanceof SavedState))
        {
            super.onRestoreInstanceState(parcelable);
            return;
        } else
        {
            parcelable = (SavedState)parcelable;
            super.onRestoreInstanceState(parcelable.getSuperState());
            fabAlignmentMode = ((SavedState) (parcelable)).fabAlignmentMode;
            fabAttached = ((SavedState) (parcelable)).fabAttached;
            return;
        }
    }

    protected Parcelable onSaveInstanceState()
    {
        SavedState savedstate = new SavedState(super.onSaveInstanceState());
        savedstate.fabAlignmentMode = fabAlignmentMode;
        savedstate.fabAttached = fabAttached;
        return savedstate;
    }

    public void performHide()
    {
        getBehavior().slideDown(this);
    }

    public void performShow()
    {
        getBehavior().slideUp(this);
    }

    void removeAnimationListener(AnimationListener animationlistener)
    {
        ArrayList arraylist = animationListeners;
        if (arraylist == null)
        {
            return;
        } else
        {
            arraylist.remove(animationlistener);
            return;
        }
    }

    public void replaceMenu(int i)
    {
        getMenu().clear();
        inflateMenu(i);
    }

    public void setBackgroundTint(ColorStateList colorstatelist)
    {
        DrawableCompat.setTintList(materialShapeDrawable, colorstatelist);
    }

    public void setCradleVerticalOffset(float f)
    {
        if (f != getCradleVerticalOffset())
        {
            getTopEdgeTreatment().setCradleVerticalOffset(f);
            materialShapeDrawable.invalidateSelf();
            setCutoutState();
        }
    }

    public void setElevation(float f)
    {
        materialShapeDrawable.setElevation(f);
        int i = materialShapeDrawable.getShadowRadius();
        int j = materialShapeDrawable.getShadowOffsetY();
        getBehavior().setAdditionalHiddenOffsetY(this, i - j);
    }

    public void setFabAlignmentMode(int i)
    {
        maybeAnimateModeChange(i);
        maybeAnimateMenuView(i, fabAttached);
        fabAlignmentMode = i;
    }

    public void setFabAnimationMode(int i)
    {
        fabAnimationMode = i;
    }

    public void setFabCradleMargin(float f)
    {
        if (f != getFabCradleMargin())
        {
            getTopEdgeTreatment().setFabCradleMargin(f);
            materialShapeDrawable.invalidateSelf();
        }
    }

    public void setFabCradleRoundedCornerRadius(float f)
    {
        if (f != getFabCradleRoundedCornerRadius())
        {
            getTopEdgeTreatment().setFabCradleRoundedCornerRadius(f);
            materialShapeDrawable.invalidateSelf();
        }
    }

    boolean setFabDiameter(int i)
    {
        if ((float)i != getTopEdgeTreatment().getFabDiameter())
        {
            getTopEdgeTreatment().setFabDiameter(i);
            materialShapeDrawable.invalidateSelf();
            return true;
        } else
        {
            return false;
        }
    }

    public void setHideOnScroll(boolean flag)
    {
        hideOnScroll = flag;
    }

    public void setSubtitle(CharSequence charsequence)
    {
    }

    public void setTitle(CharSequence charsequence)
    {
    }

    static 
    {
        DEF_STYLE_RES = com.google.android.material.R.style.Widget_MaterialComponents_BottomAppBar;
    }





/*
    static int access$1002(BottomAppBar bottomappbar, int i)
    {
        bottomappbar.rightInset = i;
        return i;
    }

*/








/*
    static Animator access$1702(BottomAppBar bottomappbar, Animator animator)
    {
        bottomappbar.menuAnimator = animator;
        return animator;
    }

*/















/*
    static int access$602(BottomAppBar bottomappbar, int i)
    {
        bottomappbar.bottomInset = i;
        return i;
    }

*/




/*
    static int access$802(BottomAppBar bottomappbar, int i)
    {
        bottomappbar.leftInset = i;
        return i;
    }

*/


    // Unreferenced inner class com/google/android/material/bottomappbar/BottomAppBar$Behavior$1

/* anonymous class */
    class Behavior._cls1
        implements android.view.View.OnLayoutChangeListener
    {

        final Behavior this$0;

        public void onLayoutChange(View view, int i, int j, int k, int l, int i1, int j1, 
                int k1, int l1)
        {
            BottomAppBar bottomappbar = (BottomAppBar)viewRef.get();
            if (bottomappbar != null && (view instanceof FloatingActionButton))
            {
                FloatingActionButton floatingactionbutton = (FloatingActionButton)view;
                floatingactionbutton.getMeasuredContentRect(fabContentRect);
                i = fabContentRect.height();
                bottomappbar.setFabDiameter(i);
                view = (androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)view.getLayoutParams();
                if (originalBottomMargin == 0)
                {
                    i = (floatingactionbutton.getMeasuredHeight() - i) / 2;
                    j = bottomappbar.getResources().getDimensionPixelOffset(com.google.android.material.R.dimen.mtrl_bottomappbar_fab_bottom_margin);
                    view.bottomMargin = bottomappbar.getBottomInset() + (j - i);
                    view.leftMargin = bottomappbar.getLeftInset();
                    view.rightMargin = bottomappbar.getRightInset();
                    if (ViewUtils.isLayoutRtl(floatingactionbutton))
                    {
                        view.leftMargin = ((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) (view)).leftMargin + bottomappbar.fabOffsetEndMode;
                        return;
                    }
                    view.rightMargin = ((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) (view)).rightMargin + bottomappbar.fabOffsetEndMode;
                }
                return;
            } else
            {
                view.removeOnLayoutChangeListener(this);
                return;
            }
        }

            
            {
                this$0 = Behavior.this;
                super();
            }
    }

}
