// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import com.google.android.material.shape.EdgeTreatment;
import com.google.android.material.shape.ShapePath;

public class BottomAppBarTopEdgeTreatment extends EdgeTreatment
    implements Cloneable
{

    private static final int ANGLE_LEFT = 180;
    private static final int ANGLE_UP = 270;
    private static final int ARC_HALF = 180;
    private static final int ARC_QUARTER = 90;
    private float cradleVerticalOffset;
    private float fabDiameter;
    private float fabMargin;
    private float horizontalOffset;
    private float roundedCornerRadius;

    public BottomAppBarTopEdgeTreatment(float f, float f1, float f2)
    {
        fabMargin = f;
        roundedCornerRadius = f1;
        setCradleVerticalOffset(f2);
        horizontalOffset = 0.0F;
    }

    float getCradleVerticalOffset()
    {
        return cradleVerticalOffset;
    }

    public void getEdgePath(float f, float f1, float f2, ShapePath shapepath)
    {
        float f3 = fabDiameter;
        if (f3 == 0.0F)
        {
            shapepath.lineTo(f, 0.0F);
            return;
        }
        f3 = (fabMargin * 2.0F + f3) / 2.0F;
        float f4 = f2 * roundedCornerRadius;
        f1 += horizontalOffset;
        f2 = cradleVerticalOffset * f2 + (1.0F - f2) * f3;
        if (f2 / f3 >= 1.0F)
        {
            shapepath.lineTo(f, 0.0F);
            return;
        } else
        {
            float f5 = f3 + f4;
            float f7 = f2 + f4;
            float f8 = (float)Math.sqrt(f5 * f5 - f7 * f7);
            f5 = f1 - f8;
            float f6 = f1 + f8;
            f7 = (float)Math.toDegrees(Math.atan(f8 / f7));
            f8 = 90F - f7;
            shapepath.lineTo(f5, 0.0F);
            shapepath.addArc(f5 - f4, 0.0F, f5 + f4, f4 * 2.0F, 270F, f7);
            shapepath.addArc(f1 - f3, -f3 - f2, f1 + f3, f3 - f2, 180F - f8, f8 * 2.0F - 180F);
            shapepath.addArc(f6 - f4, 0.0F, f6 + f4, f4 * 2.0F, 270F - f7, f7);
            shapepath.lineTo(f, 0.0F);
            return;
        }
    }

    float getFabCradleMargin()
    {
        return fabMargin;
    }

    float getFabCradleRoundedCornerRadius()
    {
        return roundedCornerRadius;
    }

    public float getFabDiameter()
    {
        return fabDiameter;
    }

    public float getHorizontalOffset()
    {
        return horizontalOffset;
    }

    void setCradleVerticalOffset(float f)
    {
        if (f >= 0.0F)
        {
            cradleVerticalOffset = f;
            return;
        } else
        {
            throw new IllegalArgumentException("cradleVerticalOffset must be positive.");
        }
    }

    void setFabCradleMargin(float f)
    {
        fabMargin = f;
    }

    void setFabCradleRoundedCornerRadius(float f)
    {
        roundedCornerRadius = f;
    }

    public void setFabDiameter(float f)
    {
        fabDiameter = f;
    }

    void setHorizontalOffset(float f)
    {
        horizontalOffset = f;
    }
}
