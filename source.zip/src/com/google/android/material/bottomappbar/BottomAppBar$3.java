// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.view.View;
import androidx.core.view.WindowInsetsCompat;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar

class this._cls0
    implements com.google.android.material.internal.lyWindowInsetsListener
{

    final BottomAppBar this$0;

    public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowinsetscompat, com.google.android.material.internal.ivePadding ivepadding)
    {
        boolean flag2 = false;
        boolean flag4 = false;
        if (BottomAppBar.access$500(BottomAppBar.this))
        {
            BottomAppBar.access$602(BottomAppBar.this, windowinsetscompat.getSystemWindowInsetBottom());
        }
        boolean flag5 = BottomAppBar.access$700(BottomAppBar.this);
        boolean flag3 = true;
        if (flag5)
        {
            boolean flag;
            if (BottomAppBar.access$800(BottomAppBar.this) != windowinsetscompat.getSystemWindowInsetLeft())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            BottomAppBar.access$802(BottomAppBar.this, windowinsetscompat.getSystemWindowInsetLeft());
            flag2 = flag;
        }
        boolean flag1 = flag4;
        if (BottomAppBar.access$900(BottomAppBar.this))
        {
            if (BottomAppBar.access$1000(BottomAppBar.this) != windowinsetscompat.getSystemWindowInsetRight())
            {
                flag1 = flag3;
            } else
            {
                flag1 = false;
            }
            BottomAppBar.access$1002(BottomAppBar.this, windowinsetscompat.getSystemWindowInsetRight());
        }
        if (flag2 || flag1)
        {
            BottomAppBar.access$1100(BottomAppBar.this);
            BottomAppBar.access$1200(BottomAppBar.this);
            BottomAppBar.access$1300(BottomAppBar.this);
        }
        return windowinsetscompat;
    }

    adding()
    {
        this$0 = BottomAppBar.this;
        super();
    }
}
