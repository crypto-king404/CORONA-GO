// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.bottomappbar;

import android.view.View;
import com.google.android.material.animation.TransformationCallback;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.shape.MaterialShapeDrawable;

// Referenced classes of package com.google.android.material.bottomappbar:
//            BottomAppBar, BottomAppBarTopEdgeTreatment

class this._cls0
    implements TransformationCallback
{

    final BottomAppBar this$0;

    public volatile void onScaleChanged(View view)
    {
        onScaleChanged((FloatingActionButton)view);
    }

    public void onScaleChanged(FloatingActionButton floatingactionbutton)
    {
        MaterialShapeDrawable materialshapedrawable = BottomAppBar.access$300(BottomAppBar.this);
        float f;
        if (floatingactionbutton.getVisibility() == 0)
        {
            f = floatingactionbutton.getScaleY();
        } else
        {
            f = 0.0F;
        }
        materialshapedrawable.setInterpolation(f);
    }

    public volatile void onTranslationChanged(View view)
    {
        onTranslationChanged((FloatingActionButton)view);
    }

    public void onTranslationChanged(FloatingActionButton floatingactionbutton)
    {
        float f = floatingactionbutton.getTranslationX();
        if (BottomAppBar.access$400(BottomAppBar.this).getHorizontalOffset() != f)
        {
            BottomAppBar.access$400(BottomAppBar.this).setHorizontalOffset(f);
            BottomAppBar.access$300(BottomAppBar.this).invalidateSelf();
        }
        float f1 = -floatingactionbutton.getTranslationY();
        f = 0.0F;
        f1 = Math.max(0.0F, f1);
        if (BottomAppBar.access$400(BottomAppBar.this).getCradleVerticalOffset() != f1)
        {
            BottomAppBar.access$400(BottomAppBar.this).setCradleVerticalOffset(f1);
            BottomAppBar.access$300(BottomAppBar.this).invalidateSelf();
        }
        MaterialShapeDrawable materialshapedrawable = BottomAppBar.access$300(BottomAppBar.this);
        if (floatingactionbutton.getVisibility() == 0)
        {
            f = floatingactionbutton.getScaleY();
        }
        materialshapedrawable.setInterpolation(f);
    }

    gActionButton()
    {
        this$0 = BottomAppBar.this;
        super();
    }
}
