// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.textview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatTextView;
import com.google.android.material.resources.MaterialAttributes;
import com.google.android.material.resources.MaterialResources;
import com.google.android.material.theme.overlay.MaterialThemeOverlay;

public class MaterialTextView extends AppCompatTextView
{

    public MaterialTextView(Context context)
    {
        this(context, null);
    }

    public MaterialTextView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0x1010084);
    }

    public MaterialTextView(Context context, AttributeSet attributeset, int i)
    {
        this(context, attributeset, i, 0);
    }

    public MaterialTextView(Context context, AttributeSet attributeset, int i, int j)
    {
        super(MaterialThemeOverlay.wrap(context, attributeset, i, j), attributeset, i);
        context = getContext();
        if (canApplyTextAppearanceLineHeight(context))
        {
            android.content.res.Resources.Theme theme = context.getTheme();
            if (!viewAttrsHasLineHeight(context, theme, attributeset, i, j))
            {
                i = findViewAppearanceResourceId(theme, attributeset, i, j);
                if (i != -1)
                {
                    applyLineHeightFromViewAppearance(theme, i);
                }
            }
        }
    }

    private void applyLineHeightFromViewAppearance(android.content.res.Resources.Theme theme, int i)
    {
        theme = theme.obtainStyledAttributes(i, com.google.android.material.R.styleable.MaterialTextAppearance);
        i = readFirstAvailableDimension(getContext(), theme, new int[] {
            com.google.android.material.R.styleable.MaterialTextAppearance_android_lineHeight, com.google.android.material.R.styleable.MaterialTextAppearance_lineHeight
        });
        theme.recycle();
        if (i >= 0)
        {
            setLineHeight(i);
        }
    }

    private static boolean canApplyTextAppearanceLineHeight(Context context)
    {
        return MaterialAttributes.resolveBoolean(context, com.google.android.material.R.attr.textAppearanceLineHeightEnabled, true);
    }

    private static int findViewAppearanceResourceId(android.content.res.Resources.Theme theme, AttributeSet attributeset, int i, int j)
    {
        theme = theme.obtainStyledAttributes(attributeset, com.google.android.material.R.styleable.MaterialTextView, i, j);
        i = theme.getResourceId(com.google.android.material.R.styleable.MaterialTextView_android_textAppearance, -1);
        theme.recycle();
        return i;
    }

    private static transient int readFirstAvailableDimension(Context context, TypedArray typedarray, int ai[])
    {
        int j = -1;
        for (int i = 0; i < ai.length && j < 0; i++)
        {
            j = MaterialResources.getDimensionPixelSize(context, typedarray, ai[i], -1);
        }

        return j;
    }

    private static boolean viewAttrsHasLineHeight(Context context, android.content.res.Resources.Theme theme, AttributeSet attributeset, int i, int j)
    {
        theme = theme.obtainStyledAttributes(attributeset, com.google.android.material.R.styleable.MaterialTextView, i, j);
        i = com.google.android.material.R.styleable.MaterialTextView_android_lineHeight;
        boolean flag = false;
        i = readFirstAvailableDimension(context, theme, new int[] {
            i, com.google.android.material.R.styleable.MaterialTextView_lineHeight
        });
        theme.recycle();
        if (i != -1)
        {
            flag = true;
        }
        return flag;
    }

    public void setTextAppearance(Context context, int i)
    {
        super.setTextAppearance(context, i);
        if (canApplyTextAppearanceLineHeight(context))
        {
            applyLineHeightFromViewAppearance(context.getTheme(), i);
        }
    }
}
