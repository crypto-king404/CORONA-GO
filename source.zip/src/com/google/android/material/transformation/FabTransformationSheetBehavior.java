// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.animation.MotionSpec;
import com.google.android.material.animation.Positioning;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package com.google.android.material.transformation:
//            FabTransformationBehavior, FabTransformationScrimBehavior

public class FabTransformationSheetBehavior extends FabTransformationBehavior
{

    private Map importantForAccessibilityMap;

    public FabTransformationSheetBehavior()
    {
    }

    public FabTransformationSheetBehavior(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
    }

    private void updateImportantForAccessibility(View view, boolean flag)
    {
        Object obj = view.getParent();
        if (!(obj instanceof CoordinatorLayout))
        {
            return;
        }
        obj = (CoordinatorLayout)obj;
        int j = ((CoordinatorLayout) (obj)).getChildCount();
        if (android.os.Build.VERSION.SDK_INT >= 16 && flag)
        {
            importantForAccessibilityMap = new HashMap(j);
        }
        for (int i = 0; i < j; i++)
        {
            View view1 = ((CoordinatorLayout) (obj)).getChildAt(i);
            boolean flag1;
            if ((view1.getLayoutParams() instanceof androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) && (((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)view1.getLayoutParams()).getBehavior() instanceof FabTransformationScrimBehavior))
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (view1 == view || flag1)
            {
                continue;
            }
            if (!flag)
            {
                Map map = importantForAccessibilityMap;
                if (map != null && map.containsKey(view1))
                {
                    ViewCompat.setImportantForAccessibility(view1, ((Integer)importantForAccessibilityMap.get(view1)).intValue());
                }
                continue;
            }
            if (android.os.Build.VERSION.SDK_INT >= 16)
            {
                importantForAccessibilityMap.put(view1, Integer.valueOf(view1.getImportantForAccessibility()));
            }
            ViewCompat.setImportantForAccessibility(view1, 4);
        }

        if (!flag)
        {
            importantForAccessibilityMap = null;
        }
    }

    protected FabTransformationBehavior.FabTransformationSpec onCreateMotionSpec(Context context, boolean flag)
    {
        int i;
        if (flag)
        {
            i = com.google.android.material.R.animator.mtrl_fab_transformation_sheet_expand_spec;
        } else
        {
            i = com.google.android.material.R.animator.mtrl_fab_transformation_sheet_collapse_spec;
        }
        FabTransformationBehavior.FabTransformationSpec fabtransformationspec = new FabTransformationBehavior.FabTransformationSpec();
        fabtransformationspec.timings = MotionSpec.createFromResource(context, i);
        fabtransformationspec.positioning = new Positioning(17, 0.0F, 0.0F);
        return fabtransformationspec;
    }

    protected boolean onExpandedStateChange(View view, View view1, boolean flag, boolean flag1)
    {
        updateImportantForAccessibility(view1, flag);
        return super.onExpandedStateChange(view, view1, flag, flag1);
    }
}
