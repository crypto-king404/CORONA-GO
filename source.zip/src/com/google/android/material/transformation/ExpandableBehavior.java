// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.expandable.ExpandableWidget;
import java.util.List;

public abstract class ExpandableBehavior extends androidx.coordinatorlayout.widget.CoordinatorLayout.Behavior
{

    private static final int STATE_COLLAPSED = 2;
    private static final int STATE_EXPANDED = 1;
    private static final int STATE_UNINITIALIZED = 0;
    private int currentState;

    public ExpandableBehavior()
    {
        currentState = 0;
    }

    public ExpandableBehavior(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        currentState = 0;
    }

    private boolean didStateChange(boolean flag)
    {
        boolean flag2;
label0:
        {
label1:
            {
                flag2 = false;
                boolean flag1 = false;
                if (!flag)
                {
                    break label0;
                }
                int i = currentState;
                if (i != 0)
                {
                    flag = flag1;
                    if (i != 2)
                    {
                        break label1;
                    }
                }
                flag = true;
            }
            return flag;
        }
        flag = flag2;
        if (currentState == 1)
        {
            flag = true;
        }
        return flag;
    }

    public static ExpandableBehavior from(View view, Class class1)
    {
        view = view.getLayoutParams();
        if (view instanceof androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)
        {
            view = ((androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams)view).getBehavior();
            if (view instanceof ExpandableBehavior)
            {
                return (ExpandableBehavior)class1.cast(view);
            } else
            {
                throw new IllegalArgumentException("The view is not associated with ExpandableBehavior");
            }
        } else
        {
            throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
        }
    }

    protected ExpandableWidget findExpandableWidget(CoordinatorLayout coordinatorlayout, View view)
    {
        List list = coordinatorlayout.getDependencies(view);
        int i = 0;
        for (int j = list.size(); i < j; i++)
        {
            View view1 = (View)list.get(i);
            if (layoutDependsOn(coordinatorlayout, view, view1))
            {
                return (ExpandableWidget)view1;
            }
        }

        return null;
    }

    public abstract boolean layoutDependsOn(CoordinatorLayout coordinatorlayout, View view, View view1);

    public boolean onDependentViewChanged(CoordinatorLayout coordinatorlayout, View view, View view1)
    {
        coordinatorlayout = (ExpandableWidget)view1;
        if (didStateChange(coordinatorlayout.isExpanded()))
        {
            int i;
            if (coordinatorlayout.isExpanded())
            {
                i = 1;
            } else
            {
                i = 2;
            }
            currentState = i;
            return onExpandedStateChange((View)coordinatorlayout, view, coordinatorlayout.isExpanded(), true);
        } else
        {
            return false;
        }
    }

    protected abstract boolean onExpandedStateChange(View view, View view1, boolean flag, boolean flag1);

    public boolean onLayoutChild(final CoordinatorLayout dep, final View child, final int expectedState)
    {
        if (!ViewCompat.isLaidOut(child))
        {
            dep = findExpandableWidget(dep, child);
            if (dep != null && didStateChange(dep.isExpanded()))
            {
                if (dep.isExpanded())
                {
                    expectedState = 1;
                } else
                {
                    expectedState = 2;
                }
                currentState = expectedState;
                expectedState = currentState;
                child.getViewTreeObserver().addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {

                    final ExpandableBehavior this$0;
                    final View val$child;
                    final ExpandableWidget val$dep;
                    final int val$expectedState;

                    public boolean onPreDraw()
                    {
                        child.getViewTreeObserver().removeOnPreDrawListener(this);
                        if (currentState == expectedState)
                        {
                            ExpandableBehavior expandablebehavior = ExpandableBehavior.this;
                            ExpandableWidget expandablewidget = dep;
                            expandablebehavior.onExpandedStateChange((View)expandablewidget, child, expandablewidget.isExpanded(), false);
                        }
                        return false;
                    }

            
            {
                this$0 = ExpandableBehavior.this;
                child = view;
                expectedState = i;
                dep = expandablewidget;
                super();
            }
                });
            }
        }
        return false;
    }

}
