// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

// Referenced classes of package com.google.android.material.transformation:
//            ExpandableBehavior

public abstract class ExpandableTransformationBehavior extends ExpandableBehavior
{

    private AnimatorSet currentAnimation;

    public ExpandableTransformationBehavior()
    {
    }

    public ExpandableTransformationBehavior(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
    }

    protected abstract AnimatorSet onCreateExpandedStateChangeAnimation(View view, View view1, boolean flag, boolean flag1);

    protected boolean onExpandedStateChange(View view, View view1, boolean flag, boolean flag1)
    {
        AnimatorSet animatorset = currentAnimation;
        boolean flag2;
        if (animatorset != null)
        {
            flag2 = true;
        } else
        {
            flag2 = false;
        }
        if (flag2)
        {
            animatorset.cancel();
        }
        view = onCreateExpandedStateChangeAnimation(view, view1, flag, flag2);
        currentAnimation = view;
        view.addListener(new AnimatorListenerAdapter() {

            final ExpandableTransformationBehavior this$0;

            public void onAnimationEnd(Animator animator)
            {
                currentAnimation = null;
            }

            
            {
                this$0 = ExpandableTransformationBehavior.this;
                super();
            }
        });
        currentAnimation.start();
        if (!flag1)
        {
            currentAnimation.end();
        }
        return true;
    }


/*
    static AnimatorSet access$002(ExpandableTransformationBehavior expandabletransformationbehavior, AnimatorSet animatorset)
    {
        expandabletransformationbehavior.currentAnimation = animatorset;
        return animatorset;
    }

*/
}
