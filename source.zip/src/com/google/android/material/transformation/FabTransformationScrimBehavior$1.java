// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

// Referenced classes of package com.google.android.material.transformation:
//            FabTransformationScrimBehavior

class val.child extends AnimatorListenerAdapter
{

    final FabTransformationScrimBehavior this$0;
    final View val$child;
    final boolean val$expanded;

    public void onAnimationEnd(Animator animator)
    {
        if (!val$expanded)
        {
            val$child.setVisibility(4);
        }
    }

    public void onAnimationStart(Animator animator)
    {
        if (val$expanded)
        {
            val$child.setVisibility(0);
        }
    }

    Q()
    {
        this$0 = final_fabtransformationscrimbehavior;
        val$expanded = flag;
        val$child = View.this;
        super();
    }
}
