// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.circularreveal.CircularRevealFrameLayout;

public class TransformationChildLayout extends CircularRevealFrameLayout
{

    public TransformationChildLayout(Context context)
    {
        this(context, null);
    }

    public TransformationChildLayout(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
    }
}
