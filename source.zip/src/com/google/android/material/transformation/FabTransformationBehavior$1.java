// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

// Referenced classes of package com.google.android.material.transformation:
//            FabTransformationBehavior

class val.dependency extends AnimatorListenerAdapter
{

    final FabTransformationBehavior this$0;
    final View val$child;
    final View val$dependency;
    final boolean val$expanded;

    public void onAnimationEnd(Animator animator)
    {
        if (!val$expanded)
        {
            val$child.setVisibility(4);
            val$dependency.setAlpha(1.0F);
            val$dependency.setVisibility(0);
        }
    }

    public void onAnimationStart(Animator animator)
    {
        if (val$expanded)
        {
            val$child.setVisibility(0);
            val$dependency.setAlpha(0.0F);
            val$dependency.setVisibility(4);
        }
    }

    ()
    {
        this$0 = final_fabtransformationbehavior;
        val$expanded = flag;
        val$child = view;
        val$dependency = View.this;
        super();
    }
}
