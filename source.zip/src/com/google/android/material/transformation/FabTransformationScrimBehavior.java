// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.animation.AnimatorSetCompat;
import com.google.android.material.animation.MotionTiming;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.android.material.transformation:
//            ExpandableTransformationBehavior

public class FabTransformationScrimBehavior extends ExpandableTransformationBehavior
{

    public static final long COLLAPSE_DELAY = 0L;
    public static final long COLLAPSE_DURATION = 150L;
    public static final long EXPAND_DELAY = 75L;
    public static final long EXPAND_DURATION = 150L;
    private final MotionTiming collapseTiming;
    private final MotionTiming expandTiming;

    public FabTransformationScrimBehavior()
    {
        expandTiming = new MotionTiming(75L, 150L);
        collapseTiming = new MotionTiming(0L, 150L);
    }

    public FabTransformationScrimBehavior(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        expandTiming = new MotionTiming(75L, 150L);
        collapseTiming = new MotionTiming(0L, 150L);
    }

    private void createScrimAnimation(View view, boolean flag, boolean flag1, List list, List list1)
    {
        if (flag)
        {
            list1 = expandTiming;
        } else
        {
            list1 = collapseTiming;
        }
        if (flag)
        {
            if (!flag1)
            {
                view.setAlpha(0.0F);
            }
            view = ObjectAnimator.ofFloat(view, View.ALPHA, new float[] {
                1.0F
            });
        } else
        {
            view = ObjectAnimator.ofFloat(view, View.ALPHA, new float[] {
                0.0F
            });
        }
        list1.apply(view);
        list.add(view);
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorlayout, View view, View view1)
    {
        return view1 instanceof FloatingActionButton;
    }

    protected AnimatorSet onCreateExpandedStateChangeAnimation(View view, final View child, final boolean expanded, boolean flag)
    {
        view = new ArrayList();
        createScrimAnimation(child, expanded, flag, view, new ArrayList());
        AnimatorSet animatorset = new AnimatorSet();
        AnimatorSetCompat.playTogether(animatorset, view);
        animatorset.addListener(new AnimatorListenerAdapter() {

            final FabTransformationScrimBehavior this$0;
            final View val$child;
            final boolean val$expanded;

            public void onAnimationEnd(Animator animator)
            {
                if (!expanded)
                {
                    child.setVisibility(4);
                }
            }

            public void onAnimationStart(Animator animator)
            {
                if (expanded)
                {
                    child.setVisibility(0);
                }
            }

            
            {
                this$0 = FabTransformationScrimBehavior.this;
                expanded = flag;
                child = view;
                super();
            }
        });
        return animatorset;
    }

    public boolean onTouchEvent(CoordinatorLayout coordinatorlayout, View view, MotionEvent motionevent)
    {
        return super.onTouchEvent(coordinatorlayout, view, motionevent);
    }
}
