// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.animation.AnimationUtils;
import com.google.android.material.animation.AnimatorSetCompat;
import com.google.android.material.animation.ArgbEvaluatorCompat;
import com.google.android.material.animation.ChildrenAlphaProperty;
import com.google.android.material.animation.DrawableAlphaProperty;
import com.google.android.material.animation.MotionSpec;
import com.google.android.material.animation.MotionTiming;
import com.google.android.material.animation.Positioning;
import com.google.android.material.circularreveal.CircularRevealCompat;
import com.google.android.material.circularreveal.CircularRevealHelper;
import com.google.android.material.circularreveal.CircularRevealWidget;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.math.MathUtils;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.android.material.transformation:
//            ExpandableTransformationBehavior, TransformationChildLayout, TransformationChildCard

public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior
{
    protected static class FabTransformationSpec
    {

        public Positioning positioning;
        public MotionSpec timings;

        protected FabTransformationSpec()
        {
        }
    }


    private float dependencyOriginalTranslationX;
    private float dependencyOriginalTranslationY;
    private final int tmpArray[];
    private final Rect tmpRect;
    private final RectF tmpRectF1;
    private final RectF tmpRectF2;

    public FabTransformationBehavior()
    {
        tmpRect = new Rect();
        tmpRectF1 = new RectF();
        tmpRectF2 = new RectF();
        tmpArray = new int[2];
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        tmpRect = new Rect();
        tmpRectF1 = new RectF();
        tmpRectF2 = new RectF();
        tmpArray = new int[2];
    }

    private ViewGroup calculateChildContentContainer(View view)
    {
        View view1 = view.findViewById(com.google.android.material.R.id.mtrl_child_content_container);
        if (view1 != null)
        {
            return toViewGroupOrNull(view1);
        }
        if (!(view instanceof TransformationChildLayout) && !(view instanceof TransformationChildCard))
        {
            return toViewGroupOrNull(view);
        } else
        {
            return toViewGroupOrNull(((ViewGroup)view).getChildAt(0));
        }
    }

    private void calculateChildVisibleBoundsAtEndOfExpansion(View view, FabTransformationSpec fabtransformationspec, MotionTiming motiontiming, MotionTiming motiontiming1, float f, float f1, float f2, 
            float f3, RectF rectf)
    {
        f = calculateValueOfAnimationAtEndOfExpansion(fabtransformationspec, motiontiming, f, f2);
        f1 = calculateValueOfAnimationAtEndOfExpansion(fabtransformationspec, motiontiming1, f1, f3);
        motiontiming = tmpRect;
        view.getWindowVisibleDisplayFrame(motiontiming);
        fabtransformationspec = tmpRectF1;
        fabtransformationspec.set(motiontiming);
        motiontiming = tmpRectF2;
        calculateWindowBounds(view, motiontiming);
        motiontiming.offset(f, f1);
        motiontiming.intersect(fabtransformationspec);
        rectf.set(motiontiming);
    }

    private void calculateDependencyWindowBounds(View view, RectF rectf)
    {
        calculateWindowBounds(view, rectf);
        rectf.offset(dependencyOriginalTranslationX, dependencyOriginalTranslationY);
    }

    private Pair calculateMotionTiming(float f, float f1, boolean flag, FabTransformationSpec fabtransformationspec)
    {
        MotionTiming motiontiming;
        if (f != 0.0F && f1 != 0.0F)
        {
            if (flag && f1 < 0.0F || !flag && f1 > 0.0F)
            {
                motiontiming = fabtransformationspec.timings.getTiming("translationXCurveUpwards");
                MotionTiming motiontiming1 = fabtransformationspec.timings.getTiming("translationYCurveUpwards");
                fabtransformationspec = motiontiming;
                motiontiming = motiontiming1;
            } else
            {
                motiontiming = fabtransformationspec.timings.getTiming("translationXCurveDownwards");
                MotionTiming motiontiming2 = fabtransformationspec.timings.getTiming("translationYCurveDownwards");
                fabtransformationspec = motiontiming;
                motiontiming = motiontiming2;
            }
        } else
        {
            MotionTiming motiontiming3 = fabtransformationspec.timings.getTiming("translationXLinear");
            motiontiming = fabtransformationspec.timings.getTiming("translationYLinear");
            fabtransformationspec = motiontiming3;
        }
        return new Pair(fabtransformationspec, motiontiming);
    }

    private float calculateRevealCenterX(View view, View view1, Positioning positioning)
    {
        RectF rectf = tmpRectF1;
        RectF rectf1 = tmpRectF2;
        calculateDependencyWindowBounds(view, rectf);
        calculateWindowBounds(view1, rectf1);
        rectf1.offset(-calculateTranslationX(view, view1, positioning), 0.0F);
        return rectf.centerX() - rectf1.left;
    }

    private float calculateRevealCenterY(View view, View view1, Positioning positioning)
    {
        RectF rectf = tmpRectF1;
        RectF rectf1 = tmpRectF2;
        calculateDependencyWindowBounds(view, rectf);
        calculateWindowBounds(view1, rectf1);
        rectf1.offset(0.0F, -calculateTranslationY(view, view1, positioning));
        return rectf.centerY() - rectf1.top;
    }

    private float calculateTranslationX(View view, View view1, Positioning positioning)
    {
        RectF rectf = tmpRectF1;
        RectF rectf1 = tmpRectF2;
        calculateDependencyWindowBounds(view, rectf);
        calculateWindowBounds(view1, rectf1);
        float f = 0.0F;
        int i = positioning.gravity & 7;
        if (i != 1)
        {
            if (i != 3)
            {
                if (i == 5)
                {
                    f = rectf1.right - rectf.right;
                }
            } else
            {
                f = rectf1.left - rectf.left;
            }
        } else
        {
            f = rectf1.centerX() - rectf.centerX();
        }
        return f + positioning.xAdjustment;
    }

    private float calculateTranslationY(View view, View view1, Positioning positioning)
    {
        RectF rectf = tmpRectF1;
        RectF rectf1 = tmpRectF2;
        calculateDependencyWindowBounds(view, rectf);
        calculateWindowBounds(view1, rectf1);
        float f = 0.0F;
        int i = positioning.gravity & 0x70;
        if (i != 16)
        {
            if (i != 48)
            {
                if (i == 80)
                {
                    f = rectf1.bottom - rectf.bottom;
                }
            } else
            {
                f = rectf1.top - rectf.top;
            }
        } else
        {
            f = rectf1.centerY() - rectf.centerY();
        }
        return f + positioning.yAdjustment;
    }

    private float calculateValueOfAnimationAtEndOfExpansion(FabTransformationSpec fabtransformationspec, MotionTiming motiontiming, float f, float f1)
    {
        long l = motiontiming.getDelay();
        long l1 = motiontiming.getDuration();
        fabtransformationspec = fabtransformationspec.timings.getTiming("expansion");
        float f2 = (float)((fabtransformationspec.getDelay() + fabtransformationspec.getDuration() + 17L) - l) / (float)l1;
        return AnimationUtils.lerp(f, f1, motiontiming.getInterpolator().getInterpolation(f2));
    }

    private void calculateWindowBounds(View view, RectF rectf)
    {
        rectf.set(0.0F, 0.0F, view.getWidth(), view.getHeight());
        int ai[] = tmpArray;
        view.getLocationInWindow(ai);
        rectf.offsetTo(ai[0], ai[1]);
        rectf.offset((int)(-view.getTranslationX()), (int)(-view.getTranslationY()));
    }

    private void createChildrenFadeAnimation(View view, View view1, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, List list, List list1)
    {
        if (!(view1 instanceof ViewGroup))
        {
            return;
        }
        if ((view1 instanceof CircularRevealWidget) && CircularRevealHelper.STRATEGY == 0)
        {
            return;
        }
        view = calculateChildContentContainer(view1);
        if (view == null)
        {
            return;
        }
        if (flag)
        {
            if (!flag1)
            {
                ChildrenAlphaProperty.CHILDREN_ALPHA.set(view, Float.valueOf(0.0F));
            }
            view = ObjectAnimator.ofFloat(view, ChildrenAlphaProperty.CHILDREN_ALPHA, new float[] {
                1.0F
            });
        } else
        {
            view = ObjectAnimator.ofFloat(view, ChildrenAlphaProperty.CHILDREN_ALPHA, new float[] {
                0.0F
            });
        }
        fabtransformationspec.timings.getTiming("contentFade").apply(view);
        list.add(view);
    }

    private void createColorAnimation(View view, View view1, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, List list, List list1)
    {
        if (!(view1 instanceof CircularRevealWidget))
        {
            return;
        }
        view1 = (CircularRevealWidget)view1;
        int i = getBackgroundTint(view);
        if (flag)
        {
            if (!flag1)
            {
                view1.setCircularRevealScrimColor(i);
            }
            view = ObjectAnimator.ofInt(view1, com.google.android.material.circularreveal.CircularRevealWidget.CircularRevealScrimColorProperty.CIRCULAR_REVEAL_SCRIM_COLOR, new int[] {
                0xffffff & i
            });
        } else
        {
            view = ObjectAnimator.ofInt(view1, com.google.android.material.circularreveal.CircularRevealWidget.CircularRevealScrimColorProperty.CIRCULAR_REVEAL_SCRIM_COLOR, new int[] {
                i
            });
        }
        view.setEvaluator(ArgbEvaluatorCompat.getInstance());
        fabtransformationspec.timings.getTiming("color").apply(view);
        list.add(view);
    }

    private void createDependencyTranslationAnimation(View view, View view1, boolean flag, FabTransformationSpec fabtransformationspec, List list)
    {
        float f = calculateTranslationX(view, view1, fabtransformationspec.positioning);
        float f1 = calculateTranslationY(view, view1, fabtransformationspec.positioning);
        fabtransformationspec = calculateMotionTiming(f, f1, flag, fabtransformationspec);
        view1 = (MotionTiming)((Pair) (fabtransformationspec)).first;
        fabtransformationspec = (MotionTiming)((Pair) (fabtransformationspec)).second;
        Object obj = View.TRANSLATION_X;
        if (!flag)
        {
            f = dependencyOriginalTranslationX;
        }
        obj = ObjectAnimator.ofFloat(view, ((Property) (obj)), new float[] {
            f
        });
        Property property = View.TRANSLATION_Y;
        if (flag)
        {
            f = f1;
        } else
        {
            f = dependencyOriginalTranslationY;
        }
        view = ObjectAnimator.ofFloat(view, property, new float[] {
            f
        });
        view1.apply(((Animator) (obj)));
        fabtransformationspec.apply(view);
        list.add(obj);
        list.add(view);
    }

    private void createElevationAnimation(View view, View view1, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, List list, List list1)
    {
        float f = ViewCompat.getElevation(view1) - ViewCompat.getElevation(view);
        if (flag)
        {
            if (!flag1)
            {
                view1.setTranslationZ(-f);
            }
            view = ObjectAnimator.ofFloat(view1, View.TRANSLATION_Z, new float[] {
                0.0F
            });
        } else
        {
            view = ObjectAnimator.ofFloat(view1, View.TRANSLATION_Z, new float[] {
                -f
            });
        }
        fabtransformationspec.timings.getTiming("elevation").apply(view);
        list.add(view);
    }

    private void createExpansionAnimation(View view, View view1, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, float f, float f1, 
            List list, List list1)
    {
        if (!(view1 instanceof CircularRevealWidget))
        {
            return;
        }
        final CircularRevealWidget circularRevealChild = (CircularRevealWidget)view1;
        float f3 = calculateRevealCenterX(view, view1, fabtransformationspec.positioning);
        float f4 = calculateRevealCenterY(view, view1, fabtransformationspec.positioning);
        ((FloatingActionButton)view).getContentRect(tmpRect);
        float f2 = (float)tmpRect.width() / 2.0F;
        MotionTiming motiontiming = fabtransformationspec.timings.getTiming("expansion");
        if (flag)
        {
            if (!flag1)
            {
                circularRevealChild.setRevealInfo(new com.google.android.material.circularreveal.CircularRevealWidget.RevealInfo(f3, f4, f2));
            }
            if (flag1)
            {
                f2 = circularRevealChild.getRevealInfo().radius;
            }
            view = CircularRevealCompat.createCircularReveal(circularRevealChild, f3, f4, MathUtils.distanceToFurthestCorner(f3, f4, 0.0F, 0.0F, f, f1));
            view.addListener(new AnimatorListenerAdapter() {

                final FabTransformationBehavior this$0;
                final CircularRevealWidget val$circularRevealChild;

                public void onAnimationEnd(Animator animator1)
                {
                    animator1 = circularRevealChild.getRevealInfo();
                    animator1.radius = 3.402823E+38F;
                    circularRevealChild.setRevealInfo(animator1);
                }

            
            {
                this$0 = FabTransformationBehavior.this;
                circularRevealChild = circularrevealwidget;
                super();
            }
            });
            createPreFillRadialExpansion(view1, motiontiming.getDelay(), (int)f3, (int)f4, f2, list);
        } else
        {
            view = motiontiming;
            f = circularRevealChild.getRevealInfo().radius;
            Animator animator = CircularRevealCompat.createCircularReveal(circularRevealChild, f3, f4, f2);
            createPreFillRadialExpansion(view1, view.getDelay(), (int)f3, (int)f4, f, list);
            createPostFillRadialExpansion(view1, view.getDelay(), view.getDuration(), fabtransformationspec.timings.getTotalDuration(), (int)f3, (int)f4, f2, list);
            view = animator;
        }
        motiontiming.apply(view);
        list.add(view);
        list1.add(CircularRevealCompat.createCircularRevealListener(circularRevealChild));
    }

    private void createIconFadeAnimation(View view, final View child, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, List list, List list1)
    {
        if (child instanceof CircularRevealWidget)
        {
            if (!(view instanceof ImageView))
            {
                return;
            }
            final CircularRevealWidget circularRevealChild = (CircularRevealWidget)child;
            final Drawable icon = ((ImageView)view).getDrawable();
            if (icon == null)
            {
                return;
            }
            icon.mutate();
            if (flag)
            {
                if (!flag1)
                {
                    icon.setAlpha(255);
                }
                view = ObjectAnimator.ofInt(icon, DrawableAlphaProperty.DRAWABLE_ALPHA_COMPAT, new int[] {
                    0
                });
            } else
            {
                view = ObjectAnimator.ofInt(icon, DrawableAlphaProperty.DRAWABLE_ALPHA_COMPAT, new int[] {
                    255
                });
            }
            view.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {

                final FabTransformationBehavior this$0;
                final View val$child;

                public void onAnimationUpdate(ValueAnimator valueanimator)
                {
                    child.invalidate();
                }

            
            {
                this$0 = FabTransformationBehavior.this;
                child = view;
                super();
            }
            });
            fabtransformationspec.timings.getTiming("iconFade").apply(view);
            list.add(view);
            list1.add(new AnimatorListenerAdapter() {

                final FabTransformationBehavior this$0;
                final CircularRevealWidget val$circularRevealChild;
                final Drawable val$icon;

                public void onAnimationEnd(Animator animator)
                {
                    circularRevealChild.setCircularRevealOverlayDrawable(null);
                }

                public void onAnimationStart(Animator animator)
                {
                    circularRevealChild.setCircularRevealOverlayDrawable(icon);
                }

            
            {
                this$0 = FabTransformationBehavior.this;
                circularRevealChild = circularrevealwidget;
                icon = drawable;
                super();
            }
            });
            return;
        } else
        {
            return;
        }
    }

    private void createPostFillRadialExpansion(View view, long l, long l1, long l2, 
            int i, int j, float f, List list)
    {
        if (android.os.Build.VERSION.SDK_INT >= 21 && l + l1 < l2)
        {
            view = ViewAnimationUtils.createCircularReveal(view, i, j, f, f);
            view.setStartDelay(l + l1);
            view.setDuration(l2 - (l + l1));
            list.add(view);
        }
    }

    private void createPreFillRadialExpansion(View view, long l, int i, int j, float f, List list)
    {
        if (android.os.Build.VERSION.SDK_INT >= 21 && l > 0L)
        {
            view = ViewAnimationUtils.createCircularReveal(view, i, j, f, f);
            view.setStartDelay(0L);
            view.setDuration(l);
            list.add(view);
        }
    }

    private void createTranslationAnimation(View view, View view1, boolean flag, boolean flag1, FabTransformationSpec fabtransformationspec, List list, List list1, 
            RectF rectf)
    {
        float f = calculateTranslationX(view, view1, fabtransformationspec.positioning);
        float f1 = calculateTranslationY(view, view1, fabtransformationspec.positioning);
        view = calculateMotionTiming(f, f1, flag, fabtransformationspec);
        MotionTiming motiontiming = (MotionTiming)((Pair) (view)).first;
        MotionTiming motiontiming1 = (MotionTiming)((Pair) (view)).second;
        if (flag)
        {
            if (!flag1)
            {
                view1.setTranslationX(-f);
                view1.setTranslationY(-f1);
            }
            view = ObjectAnimator.ofFloat(view1, View.TRANSLATION_X, new float[] {
                0.0F
            });
            list1 = ObjectAnimator.ofFloat(view1, View.TRANSLATION_Y, new float[] {
                0.0F
            });
            calculateChildVisibleBoundsAtEndOfExpansion(view1, fabtransformationspec, motiontiming, motiontiming1, -f, -f1, 0.0F, 0.0F, rectf);
            view1 = list1;
        } else
        {
            view = ObjectAnimator.ofFloat(view1, View.TRANSLATION_X, new float[] {
                -f
            });
            view1 = ObjectAnimator.ofFloat(view1, View.TRANSLATION_Y, new float[] {
                -f1
            });
        }
        motiontiming.apply(view);
        motiontiming1.apply(view1);
        list.add(view);
        list.add(view1);
    }

    private int getBackgroundTint(View view)
    {
        ColorStateList colorstatelist = ViewCompat.getBackgroundTintList(view);
        if (colorstatelist != null)
        {
            return colorstatelist.getColorForState(view.getDrawableState(), colorstatelist.getDefaultColor());
        } else
        {
            return 0;
        }
    }

    private ViewGroup toViewGroupOrNull(View view)
    {
        if (view instanceof ViewGroup)
        {
            return (ViewGroup)view;
        } else
        {
            return null;
        }
    }

    public boolean layoutDependsOn(CoordinatorLayout coordinatorlayout, View view, View view1)
    {
        if (view.getVisibility() != 8)
        {
            boolean flag1 = view1 instanceof FloatingActionButton;
            boolean flag = false;
            if (flag1)
            {
                int i = ((FloatingActionButton)view1).getExpandedComponentIdHint();
                if (i == 0 || i == view.getId())
                {
                    flag = true;
                }
                return flag;
            } else
            {
                return false;
            }
        } else
        {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        }
    }

    public void onAttachedToLayoutParams(androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams layoutparams)
    {
        if (layoutparams.dodgeInsetEdges == 0)
        {
            layoutparams.dodgeInsetEdges = 80;
        }
    }

    protected AnimatorSet onCreateExpandedStateChangeAnimation(final View dependency, final View child, final boolean expanded, boolean flag)
    {
        Object obj = onCreateMotionSpec(child.getContext(), expanded);
        if (expanded)
        {
            dependencyOriginalTranslationX = dependency.getTranslationX();
            dependencyOriginalTranslationY = dependency.getTranslationY();
        }
        ArrayList arraylist = new ArrayList();
        ArrayList arraylist1 = new ArrayList();
        if (android.os.Build.VERSION.SDK_INT >= 21)
        {
            createElevationAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), arraylist, arraylist1);
        }
        RectF rectf = tmpRectF1;
        createTranslationAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), arraylist, arraylist1, rectf);
        float f = rectf.width();
        float f1 = rectf.height();
        createDependencyTranslationAnimation(dependency, child, expanded, ((FabTransformationSpec) (obj)), arraylist);
        createIconFadeAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), arraylist, arraylist1);
        createExpansionAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), f, f1, arraylist, arraylist1);
        createColorAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), arraylist, arraylist1);
        createChildrenFadeAnimation(dependency, child, expanded, flag, ((FabTransformationSpec) (obj)), arraylist, arraylist1);
        obj = new AnimatorSet();
        AnimatorSetCompat.playTogether(((AnimatorSet) (obj)), arraylist);
        ((AnimatorSet) (obj)).addListener(new AnimatorListenerAdapter() {

            final FabTransformationBehavior this$0;
            final View val$child;
            final View val$dependency;
            final boolean val$expanded;

            public void onAnimationEnd(Animator animator)
            {
                if (!expanded)
                {
                    child.setVisibility(4);
                    dependency.setAlpha(1.0F);
                    dependency.setVisibility(0);
                }
            }

            public void onAnimationStart(Animator animator)
            {
                if (expanded)
                {
                    child.setVisibility(0);
                    dependency.setAlpha(0.0F);
                    dependency.setVisibility(4);
                }
            }

            
            {
                this$0 = FabTransformationBehavior.this;
                expanded = flag;
                child = view;
                dependency = view1;
                super();
            }
        });
        int i = 0;
        for (int j = arraylist1.size(); i < j; i++)
        {
            ((AnimatorSet) (obj)).addListener((android.animation.Animator.AnimatorListener)arraylist1.get(i));
        }

        return ((AnimatorSet) (obj));
    }

    protected abstract FabTransformationSpec onCreateMotionSpec(Context context, boolean flag);
}
