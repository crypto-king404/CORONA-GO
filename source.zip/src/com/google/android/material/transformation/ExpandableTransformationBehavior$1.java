// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

// Referenced classes of package com.google.android.material.transformation:
//            ExpandableTransformationBehavior

class this._cls0 extends AnimatorListenerAdapter
{

    final ExpandableTransformationBehavior this$0;

    public void onAnimationEnd(Animator animator)
    {
        ExpandableTransformationBehavior.access$002(ExpandableTransformationBehavior.this, null);
    }

    ()
    {
        this$0 = ExpandableTransformationBehavior.this;
        super();
    }
}
