// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.view.View;
import android.view.ViewTreeObserver;
import com.google.android.material.expandable.ExpandableWidget;

// Referenced classes of package com.google.android.material.transformation:
//            ExpandableBehavior

class val.dep
    implements android.view.eDrawListener
{

    final ExpandableBehavior this$0;
    final View val$child;
    final ExpandableWidget val$dep;
    final int val$expectedState;

    public boolean onPreDraw()
    {
        val$child.getViewTreeObserver().removeOnPreDrawListener(this);
        if (ExpandableBehavior.access$000(ExpandableBehavior.this) == val$expectedState)
        {
            ExpandableBehavior expandablebehavior = ExpandableBehavior.this;
            ExpandableWidget expandablewidget = val$dep;
            expandablebehavior.onExpandedStateChange((View)expandablewidget, val$child, expandablewidget.isExpanded(), false);
        }
        return false;
    }

    ()
    {
        this$0 = final_expandablebehavior;
        val$child = view;
        val$expectedState = i;
        val$dep = ExpandableWidget.this;
        super();
    }
}
