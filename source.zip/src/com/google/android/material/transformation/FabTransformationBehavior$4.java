// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.circularreveal.CircularRevealWidget;

// Referenced classes of package com.google.android.material.transformation:
//            FabTransformationBehavior

class val.circularRevealChild extends AnimatorListenerAdapter
{

    final FabTransformationBehavior this$0;
    final CircularRevealWidget val$circularRevealChild;

    public void onAnimationEnd(Animator animator)
    {
        animator = val$circularRevealChild.getRevealInfo();
        animator.radius = 3.402823E+38F;
        val$circularRevealChild.setRevealInfo(animator);
    }

    nfo()
    {
        this$0 = final_fabtransformationbehavior;
        val$circularRevealChild = CircularRevealWidget.this;
        super();
    }
}
