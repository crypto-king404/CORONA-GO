// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.transformation;

import android.animation.ValueAnimator;
import android.view.View;

// Referenced classes of package com.google.android.material.transformation:
//            FabTransformationBehavior

class val.child
    implements android.animation.Listener
{

    final FabTransformationBehavior this$0;
    final View val$child;

    public void onAnimationUpdate(ValueAnimator valueanimator)
    {
        val$child.invalidate();
    }

    ()
    {
        this$0 = final_fabtransformationbehavior;
        val$child = View.this;
        super();
    }
}
