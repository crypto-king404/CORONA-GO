// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.theme.overlay;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.appcompat.view.ContextThemeWrapper;

public class MaterialThemeOverlay
{

    private static final int ANDROID_THEME_OVERLAY_ATTRS[];
    private static final int MATERIAL_THEME_OVERLAY_ATTR[];

    private MaterialThemeOverlay()
    {
    }

    private static int obtainAndroidThemeOverlayId(Context context, AttributeSet attributeset)
    {
        context = context.obtainStyledAttributes(attributeset, ANDROID_THEME_OVERLAY_ATTRS);
        int i = context.getResourceId(0, 0);
        int j = context.getResourceId(1, 0);
        context.recycle();
        if (i != 0)
        {
            return i;
        } else
        {
            return j;
        }
    }

    private static int obtainMaterialThemeOverlayId(Context context, AttributeSet attributeset, int i, int j)
    {
        context = context.obtainStyledAttributes(attributeset, MATERIAL_THEME_OVERLAY_ATTR, i, j);
        i = context.getResourceId(0, 0);
        context.recycle();
        return i;
    }

    public static Context wrap(Context context, AttributeSet attributeset, int i, int j)
    {
        j = obtainMaterialThemeOverlayId(context, attributeset, i, j);
        if ((context instanceof ContextThemeWrapper) && ((ContextThemeWrapper)context).getThemeResId() == j)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (j != 0)
        {
            if (i != 0)
            {
                return context;
            }
            ContextThemeWrapper contextthemewrapper = new ContextThemeWrapper(context, j);
            i = obtainAndroidThemeOverlayId(context, attributeset);
            if (i != 0)
            {
                contextthemewrapper.getTheme().applyStyle(i, true);
            }
            return contextthemewrapper;
        } else
        {
            return context;
        }
    }

    static 
    {
        ANDROID_THEME_OVERLAY_ATTRS = (new int[] {
            0x1010000, com.google.android.material.R.attr.theme
        });
        MATERIAL_THEME_OVERLAY_ATTR = (new int[] {
            com.google.android.material.R.attr.materialThemeOverlay
        });
    }
}
