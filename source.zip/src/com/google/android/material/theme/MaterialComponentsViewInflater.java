// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.app.AppCompatViewInflater;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatTextView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textview.MaterialTextView;

public class MaterialComponentsViewInflater extends AppCompatViewInflater
{

    public MaterialComponentsViewInflater()
    {
    }

    protected AppCompatAutoCompleteTextView createAutoCompleteTextView(Context context, AttributeSet attributeset)
    {
        return new MaterialAutoCompleteTextView(context, attributeset);
    }

    protected AppCompatButton createButton(Context context, AttributeSet attributeset)
    {
        return new MaterialButton(context, attributeset);
    }

    protected AppCompatCheckBox createCheckBox(Context context, AttributeSet attributeset)
    {
        return new MaterialCheckBox(context, attributeset);
    }

    protected AppCompatRadioButton createRadioButton(Context context, AttributeSet attributeset)
    {
        return new MaterialRadioButton(context, attributeset);
    }

    protected AppCompatTextView createTextView(Context context, AttributeSet attributeset)
    {
        return new MaterialTextView(context, attributeset);
    }
}
