// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.card;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.cardview.widget.CardView;
import com.google.android.material.internal.ThemeEnforcement;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.MaterialShapeUtils;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;
import com.google.android.material.theme.overlay.MaterialThemeOverlay;

// Referenced classes of package com.google.android.material.card:
//            MaterialCardViewHelper

public class MaterialCardView extends CardView
    implements Checkable, Shapeable
{
    public static interface OnCheckedChangeListener
    {

        public abstract void onCheckedChanged(MaterialCardView materialcardview, boolean flag);
    }


    private static final String ACCESSIBILITY_CLASS_NAME = "androidx.cardview.widget.CardView";
    private static final int CHECKABLE_STATE_SET[] = {
        0x101009f
    };
    private static final int CHECKED_STATE_SET[] = {
        0x10100a0
    };
    private static final int DEF_STYLE_RES;
    private static final int DRAGGED_STATE_SET[];
    private static final String LOG_TAG = "MaterialCardView";
    private final MaterialCardViewHelper cardViewHelper;
    private boolean checked;
    private boolean dragged;
    private boolean isParentCardViewDoneInitializing;
    private OnCheckedChangeListener onCheckedChangeListener;

    public MaterialCardView(Context context)
    {
        this(context, null);
    }

    public MaterialCardView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, com.google.android.material.R.attr.materialCardViewStyle);
    }

    public MaterialCardView(Context context, AttributeSet attributeset, int i)
    {
        int j = DEF_STYLE_RES;
        super(MaterialThemeOverlay.wrap(context, attributeset, i, j), attributeset, i);
        checked = false;
        dragged = false;
        isParentCardViewDoneInitializing = true;
        context = ThemeEnforcement.obtainStyledAttributes(getContext(), attributeset, com.google.android.material.R.styleable.MaterialCardView, i, j, new int[0]);
        attributeset = new MaterialCardViewHelper(this, attributeset, i, j);
        cardViewHelper = attributeset;
        attributeset.setCardBackgroundColor(super.getCardBackgroundColor());
        attributeset.setUserContentPadding(super.getContentPaddingLeft(), super.getContentPaddingTop(), super.getContentPaddingRight(), super.getContentPaddingBottom());
        attributeset.loadFromAttributes(context);
        context.recycle();
    }

    private void forceRippleRedrawIfNeeded()
    {
        if (android.os.Build.VERSION.SDK_INT > 26)
        {
            cardViewHelper.forceRippleRedraw();
        }
    }

    private RectF getBoundsAsRectF()
    {
        RectF rectf = new RectF();
        rectf.set(cardViewHelper.getBackground().getBounds());
        return rectf;
    }

    public ColorStateList getCardBackgroundColor()
    {
        return cardViewHelper.getCardBackgroundColor();
    }

    public ColorStateList getCardForegroundColor()
    {
        return cardViewHelper.getCardForegroundColor();
    }

    float getCardViewRadius()
    {
        return getRadius();
    }

    public Drawable getCheckedIcon()
    {
        return cardViewHelper.getCheckedIcon();
    }

    public ColorStateList getCheckedIconTint()
    {
        return cardViewHelper.getCheckedIconTint();
    }

    public int getContentPaddingBottom()
    {
        return cardViewHelper.getUserContentPadding().bottom;
    }

    public int getContentPaddingLeft()
    {
        return cardViewHelper.getUserContentPadding().left;
    }

    public int getContentPaddingRight()
    {
        return cardViewHelper.getUserContentPadding().right;
    }

    public int getContentPaddingTop()
    {
        return cardViewHelper.getUserContentPadding().top;
    }

    public float getProgress()
    {
        return cardViewHelper.getProgress();
    }

    public float getRadius()
    {
        return cardViewHelper.getCornerRadius();
    }

    public ColorStateList getRippleColor()
    {
        return cardViewHelper.getRippleColor();
    }

    public ShapeAppearanceModel getShapeAppearanceModel()
    {
        return cardViewHelper.getShapeAppearanceModel();
    }

    public int getStrokeColor()
    {
        return cardViewHelper.getStrokeColor();
    }

    public ColorStateList getStrokeColorStateList()
    {
        return cardViewHelper.getStrokeColorStateList();
    }

    public int getStrokeWidth()
    {
        return cardViewHelper.getStrokeWidth();
    }

    public boolean isCheckable()
    {
        MaterialCardViewHelper materialcardviewhelper = cardViewHelper;
        return materialcardviewhelper != null && materialcardviewhelper.isCheckable();
    }

    public boolean isChecked()
    {
        return checked;
    }

    public boolean isDragged()
    {
        return dragged;
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        MaterialShapeUtils.setParentAbsoluteElevation(this, cardViewHelper.getBackground());
    }

    protected int[] onCreateDrawableState(int i)
    {
        int ai[] = super.onCreateDrawableState(i + 3);
        if (isCheckable())
        {
            mergeDrawableStates(ai, CHECKABLE_STATE_SET);
        }
        if (isChecked())
        {
            mergeDrawableStates(ai, CHECKED_STATE_SET);
        }
        if (isDragged())
        {
            mergeDrawableStates(ai, DRAGGED_STATE_SET);
        }
        return ai;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        super.onInitializeAccessibilityEvent(accessibilityevent);
        accessibilityevent.setClassName("androidx.cardview.widget.CardView");
        accessibilityevent.setChecked(isChecked());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilitynodeinfo)
    {
        super.onInitializeAccessibilityNodeInfo(accessibilitynodeinfo);
        accessibilitynodeinfo.setClassName("androidx.cardview.widget.CardView");
        accessibilitynodeinfo.setCheckable(isCheckable());
        accessibilitynodeinfo.setClickable(isClickable());
        accessibilitynodeinfo.setChecked(isChecked());
    }

    protected void onMeasure(int i, int j)
    {
        super.onMeasure(i, j);
        cardViewHelper.onMeasure(getMeasuredWidth(), getMeasuredHeight());
    }

    void setAncestorContentPadding(int i, int j, int k, int l)
    {
        super.setContentPadding(i, j, k, l);
    }

    public void setBackground(Drawable drawable)
    {
        setBackgroundDrawable(drawable);
    }

    public void setBackgroundDrawable(Drawable drawable)
    {
        if (isParentCardViewDoneInitializing)
        {
            if (!cardViewHelper.isBackgroundOverwritten())
            {
                Log.i("MaterialCardView", "Setting a custom background is not supported.");
                cardViewHelper.setBackgroundOverwritten(true);
            }
            super.setBackgroundDrawable(drawable);
        }
    }

    void setBackgroundInternal(Drawable drawable)
    {
        super.setBackgroundDrawable(drawable);
    }

    public void setCardBackgroundColor(int i)
    {
        cardViewHelper.setCardBackgroundColor(ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorstatelist)
    {
        cardViewHelper.setCardBackgroundColor(colorstatelist);
    }

    public void setCardElevation(float f)
    {
        super.setCardElevation(f);
        cardViewHelper.updateElevation();
    }

    public void setCardForegroundColor(ColorStateList colorstatelist)
    {
        cardViewHelper.setCardForegroundColor(colorstatelist);
    }

    public void setCheckable(boolean flag)
    {
        cardViewHelper.setCheckable(flag);
    }

    public void setChecked(boolean flag)
    {
        if (checked != flag)
        {
            toggle();
        }
    }

    public void setCheckedIcon(Drawable drawable)
    {
        cardViewHelper.setCheckedIcon(drawable);
    }

    public void setCheckedIconResource(int i)
    {
        cardViewHelper.setCheckedIcon(AppCompatResources.getDrawable(getContext(), i));
    }

    public void setCheckedIconTint(ColorStateList colorstatelist)
    {
        cardViewHelper.setCheckedIconTint(colorstatelist);
    }

    public void setClickable(boolean flag)
    {
        super.setClickable(flag);
        MaterialCardViewHelper materialcardviewhelper = cardViewHelper;
        if (materialcardviewhelper != null)
        {
            materialcardviewhelper.updateClickable();
        }
    }

    public void setContentPadding(int i, int j, int k, int l)
    {
        cardViewHelper.setUserContentPadding(i, j, k, l);
    }

    public void setDragged(boolean flag)
    {
        if (dragged != flag)
        {
            dragged = flag;
            refreshDrawableState();
            forceRippleRedrawIfNeeded();
            invalidate();
        }
    }

    public void setMaxCardElevation(float f)
    {
        super.setMaxCardElevation(f);
        cardViewHelper.updateInsets();
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener oncheckedchangelistener)
    {
        onCheckedChangeListener = oncheckedchangelistener;
    }

    public void setPreventCornerOverlap(boolean flag)
    {
        super.setPreventCornerOverlap(flag);
        cardViewHelper.updateInsets();
        cardViewHelper.updateContentPadding();
    }

    public void setProgress(float f)
    {
        cardViewHelper.setProgress(f);
    }

    public void setRadius(float f)
    {
        super.setRadius(f);
        cardViewHelper.setCornerRadius(f);
    }

    public void setRippleColor(ColorStateList colorstatelist)
    {
        cardViewHelper.setRippleColor(colorstatelist);
    }

    public void setRippleColorResource(int i)
    {
        cardViewHelper.setRippleColor(AppCompatResources.getColorStateList(getContext(), i));
    }

    public void setShapeAppearanceModel(ShapeAppearanceModel shapeappearancemodel)
    {
        if (android.os.Build.VERSION.SDK_INT >= 21)
        {
            setClipToOutline(shapeappearancemodel.isRoundRect(getBoundsAsRectF()));
        }
        cardViewHelper.setShapeAppearanceModel(shapeappearancemodel);
    }

    public void setStrokeColor(int i)
    {
        cardViewHelper.setStrokeColor(ColorStateList.valueOf(i));
    }

    public void setStrokeColor(ColorStateList colorstatelist)
    {
        cardViewHelper.setStrokeColor(colorstatelist);
    }

    public void setStrokeWidth(int i)
    {
        cardViewHelper.setStrokeWidth(i);
    }

    public void setUseCompatPadding(boolean flag)
    {
        super.setUseCompatPadding(flag);
        cardViewHelper.updateInsets();
        cardViewHelper.updateContentPadding();
    }

    public void toggle()
    {
        if (isCheckable() && isEnabled())
        {
            checked = checked ^ true;
            refreshDrawableState();
            forceRippleRedrawIfNeeded();
            OnCheckedChangeListener oncheckedchangelistener = onCheckedChangeListener;
            if (oncheckedchangelistener != null)
            {
                oncheckedchangelistener.onCheckedChanged(this, checked);
            }
        }
    }

    static 
    {
        DRAGGED_STATE_SET = (new int[] {
            com.google.android.material.R.attr.state_dragged
        });
        DEF_STYLE_RES = com.google.android.material.R.style.Widget_MaterialComponents_CardView;
    }

}
