// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.card;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ViewCompat;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.resources.MaterialResources;
import com.google.android.material.ripple.RippleUtils;
import com.google.android.material.shape.CornerTreatment;
import com.google.android.material.shape.CutCornerTreatment;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.RoundedCornerTreatment;
import com.google.android.material.shape.ShapeAppearanceModel;

// Referenced classes of package com.google.android.material.card:
//            MaterialCardView

class MaterialCardViewHelper
{

    private static final float CARD_VIEW_SHADOW_MULTIPLIER = 1.5F;
    private static final int CHECKED_ICON_LAYER_INDEX = 2;
    private static final int CHECKED_STATE_SET[] = {
        0x10100a0
    };
    private static final double COS_45 = Math.cos(Math.toRadians(45D));
    private static final int DEFAULT_STROKE_VALUE = -1;
    private final MaterialShapeDrawable bgDrawable;
    private boolean checkable;
    private Drawable checkedIcon;
    private final int checkedIconMargin;
    private final int checkedIconSize;
    private ColorStateList checkedIconTint;
    private LayerDrawable clickableForegroundDrawable;
    private MaterialShapeDrawable compatRippleDrawable;
    private Drawable fgDrawable;
    private final MaterialShapeDrawable foregroundContentDrawable = new MaterialShapeDrawable();
    private MaterialShapeDrawable foregroundShapeDrawable;
    private boolean isBackgroundOverwritten;
    private final MaterialCardView materialCardView;
    private ColorStateList rippleColor;
    private Drawable rippleDrawable;
    private ShapeAppearanceModel shapeAppearanceModel;
    private ColorStateList strokeColor;
    private int strokeWidth;
    private final Rect userContentPadding = new Rect();

    public MaterialCardViewHelper(MaterialCardView materialcardview, AttributeSet attributeset, int i, int j)
    {
        isBackgroundOverwritten = false;
        materialCardView = materialcardview;
        Object obj = new MaterialShapeDrawable(materialcardview.getContext(), attributeset, i, j);
        bgDrawable = ((MaterialShapeDrawable) (obj));
        ((MaterialShapeDrawable) (obj)).initializeElevationOverlay(materialcardview.getContext());
        ((MaterialShapeDrawable) (obj)).setShadowColor(0xff444444);
        obj = ((MaterialShapeDrawable) (obj)).getShapeAppearanceModel().toBuilder();
        attributeset = materialcardview.getContext().obtainStyledAttributes(attributeset, com.google.android.material.R.styleable.CardView, i, com.google.android.material.R.style.CardView);
        if (attributeset.hasValue(com.google.android.material.R.styleable.CardView_cardCornerRadius))
        {
            ((com.google.android.material.shape.ShapeAppearanceModel.Builder) (obj)).setAllCornerSizes(attributeset.getDimension(com.google.android.material.R.styleable.CardView_cardCornerRadius, 0.0F));
        }
        setShapeAppearanceModel(((com.google.android.material.shape.ShapeAppearanceModel.Builder) (obj)).build());
        materialcardview = materialcardview.getResources();
        checkedIconMargin = materialcardview.getDimensionPixelSize(com.google.android.material.R.dimen.mtrl_card_checked_icon_margin);
        checkedIconSize = materialcardview.getDimensionPixelSize(com.google.android.material.R.dimen.mtrl_card_checked_icon_size);
        attributeset.recycle();
    }

    private float calculateActualCornerPadding()
    {
        return Math.max(Math.max(calculateCornerPaddingForCornerTreatment(shapeAppearanceModel.getTopLeftCorner(), bgDrawable.getTopLeftCornerResolvedSize()), calculateCornerPaddingForCornerTreatment(shapeAppearanceModel.getTopRightCorner(), bgDrawable.getTopRightCornerResolvedSize())), Math.max(calculateCornerPaddingForCornerTreatment(shapeAppearanceModel.getBottomRightCorner(), bgDrawable.getBottomRightCornerResolvedSize()), calculateCornerPaddingForCornerTreatment(shapeAppearanceModel.getBottomLeftCorner(), bgDrawable.getBottomLeftCornerResolvedSize())));
    }

    private float calculateCornerPaddingForCornerTreatment(CornerTreatment cornertreatment, float f)
    {
        if (cornertreatment instanceof RoundedCornerTreatment)
        {
            return (float)((1.0D - COS_45) * (double)f);
        }
        if (cornertreatment instanceof CutCornerTreatment)
        {
            return f / 2.0F;
        } else
        {
            return 0.0F;
        }
    }

    private float calculateHorizontalBackgroundPadding()
    {
        float f1 = materialCardView.getMaxCardElevation();
        float f;
        if (shouldAddCornerPaddingOutsideCardBackground())
        {
            f = calculateActualCornerPadding();
        } else
        {
            f = 0.0F;
        }
        return f1 + f;
    }

    private float calculateVerticalBackgroundPadding()
    {
        float f1 = materialCardView.getMaxCardElevation();
        float f;
        if (shouldAddCornerPaddingOutsideCardBackground())
        {
            f = calculateActualCornerPadding();
        } else
        {
            f = 0.0F;
        }
        return f1 * 1.5F + f;
    }

    private boolean canClipToOutline()
    {
        return android.os.Build.VERSION.SDK_INT >= 21 && bgDrawable.isRoundRect();
    }

    private Drawable createCheckedIconLayer()
    {
        StateListDrawable statelistdrawable = new StateListDrawable();
        Drawable drawable = checkedIcon;
        if (drawable != null)
        {
            statelistdrawable.addState(CHECKED_STATE_SET, drawable);
        }
        return statelistdrawable;
    }

    private Drawable createCompatRippleDrawable()
    {
        StateListDrawable statelistdrawable = new StateListDrawable();
        MaterialShapeDrawable materialshapedrawable = createForegroundShapeDrawable();
        compatRippleDrawable = materialshapedrawable;
        materialshapedrawable.setFillColor(rippleColor);
        materialshapedrawable = compatRippleDrawable;
        statelistdrawable.addState(new int[] {
            0x10100a7
        }, materialshapedrawable);
        return statelistdrawable;
    }

    private Drawable createForegroundRippleDrawable()
    {
        if (RippleUtils.USE_FRAMEWORK_RIPPLE)
        {
            foregroundShapeDrawable = createForegroundShapeDrawable();
            return new RippleDrawable(rippleColor, null, foregroundShapeDrawable);
        } else
        {
            return createCompatRippleDrawable();
        }
    }

    private MaterialShapeDrawable createForegroundShapeDrawable()
    {
        return new MaterialShapeDrawable(shapeAppearanceModel);
    }

    private Drawable getClickableForeground()
    {
        if (rippleDrawable == null)
        {
            rippleDrawable = createForegroundRippleDrawable();
        }
        if (clickableForegroundDrawable == null)
        {
            Object obj = createCheckedIconLayer();
            obj = new LayerDrawable(new Drawable[] {
                rippleDrawable, foregroundContentDrawable, obj
            });
            clickableForegroundDrawable = ((LayerDrawable) (obj));
            ((LayerDrawable) (obj)).setId(2, com.google.android.material.R.id.mtrl_card_checked_layer_id);
        }
        return clickableForegroundDrawable;
    }

    private float getParentCardViewCalculatedCornerPadding()
    {
        if (materialCardView.getPreventCornerOverlap() && (android.os.Build.VERSION.SDK_INT < 21 || materialCardView.getUseCompatPadding()))
        {
            return (float)((1.0D - COS_45) * (double)materialCardView.getCardViewRadius());
        } else
        {
            return 0.0F;
        }
    }

    private Drawable insetDrawable(Drawable drawable)
    {
        int i;
        int j;
label0:
        {
            boolean flag1 = false;
            j = 0;
            boolean flag;
            if (android.os.Build.VERSION.SDK_INT < 21)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                i = ((flag1) ? 1 : 0);
                if (!materialCardView.getUseCompatPadding())
                {
                    break label0;
                }
            }
            i = (int)Math.ceil(calculateVerticalBackgroundPadding());
            j = (int)Math.ceil(calculateHorizontalBackgroundPadding());
        }
        return new InsetDrawable(drawable, j, i, j, i) {

            final MaterialCardViewHelper this$0;

            public int getMinimumHeight()
            {
                return -1;
            }

            public int getMinimumWidth()
            {
                return -1;
            }

            public boolean getPadding(Rect rect)
            {
                return false;
            }

            
            {
                this$0 = MaterialCardViewHelper.this;
                super(drawable, i, j, k, l);
            }
        };
    }

    private boolean shouldAddCornerPaddingInsideCardBackground()
    {
        return materialCardView.getPreventCornerOverlap() && !canClipToOutline();
    }

    private boolean shouldAddCornerPaddingOutsideCardBackground()
    {
        return materialCardView.getPreventCornerOverlap() && canClipToOutline() && materialCardView.getUseCompatPadding();
    }

    private void updateInsetForeground(Drawable drawable)
    {
        if (android.os.Build.VERSION.SDK_INT >= 23 && (materialCardView.getForeground() instanceof InsetDrawable))
        {
            ((InsetDrawable)materialCardView.getForeground()).setDrawable(drawable);
            return;
        } else
        {
            materialCardView.setForeground(insetDrawable(drawable));
            return;
        }
    }

    private void updateRippleColor()
    {
        if (RippleUtils.USE_FRAMEWORK_RIPPLE)
        {
            Drawable drawable = rippleDrawable;
            if (drawable != null)
            {
                ((RippleDrawable)drawable).setColor(rippleColor);
                return;
            }
        }
        MaterialShapeDrawable materialshapedrawable = compatRippleDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setFillColor(rippleColor);
        }
    }

    void forceRippleRedraw()
    {
        Object obj = rippleDrawable;
        if (obj != null)
        {
            obj = ((Drawable) (obj)).getBounds();
            int i = ((Rect) (obj)).bottom;
            rippleDrawable.setBounds(((Rect) (obj)).left, ((Rect) (obj)).top, ((Rect) (obj)).right, i - 1);
            rippleDrawable.setBounds(((Rect) (obj)).left, ((Rect) (obj)).top, ((Rect) (obj)).right, i);
        }
    }

    MaterialShapeDrawable getBackground()
    {
        return bgDrawable;
    }

    ColorStateList getCardBackgroundColor()
    {
        return bgDrawable.getFillColor();
    }

    ColorStateList getCardForegroundColor()
    {
        return foregroundContentDrawable.getFillColor();
    }

    Drawable getCheckedIcon()
    {
        return checkedIcon;
    }

    ColorStateList getCheckedIconTint()
    {
        return checkedIconTint;
    }

    float getCornerRadius()
    {
        return bgDrawable.getTopLeftCornerResolvedSize();
    }

    float getProgress()
    {
        return bgDrawable.getInterpolation();
    }

    ColorStateList getRippleColor()
    {
        return rippleColor;
    }

    ShapeAppearanceModel getShapeAppearanceModel()
    {
        return shapeAppearanceModel;
    }

    int getStrokeColor()
    {
        ColorStateList colorstatelist = strokeColor;
        if (colorstatelist == null)
        {
            return -1;
        } else
        {
            return colorstatelist.getDefaultColor();
        }
    }

    ColorStateList getStrokeColorStateList()
    {
        return strokeColor;
    }

    int getStrokeWidth()
    {
        return strokeWidth;
    }

    Rect getUserContentPadding()
    {
        return userContentPadding;
    }

    boolean isBackgroundOverwritten()
    {
        return isBackgroundOverwritten;
    }

    boolean isCheckable()
    {
        return checkable;
    }

    void loadFromAttributes(TypedArray typedarray)
    {
        ColorStateList colorstatelist = MaterialResources.getColorStateList(materialCardView.getContext(), typedarray, com.google.android.material.R.styleable.MaterialCardView_strokeColor);
        strokeColor = colorstatelist;
        if (colorstatelist == null)
        {
            strokeColor = ColorStateList.valueOf(-1);
        }
        strokeWidth = typedarray.getDimensionPixelSize(com.google.android.material.R.styleable.MaterialCardView_strokeWidth, 0);
        boolean flag = typedarray.getBoolean(com.google.android.material.R.styleable.MaterialCardView_android_checkable, false);
        checkable = flag;
        materialCardView.setLongClickable(flag);
        checkedIconTint = MaterialResources.getColorStateList(materialCardView.getContext(), typedarray, com.google.android.material.R.styleable.MaterialCardView_checkedIconTint);
        setCheckedIcon(MaterialResources.getDrawable(materialCardView.getContext(), typedarray, com.google.android.material.R.styleable.MaterialCardView_checkedIcon));
        colorstatelist = MaterialResources.getColorStateList(materialCardView.getContext(), typedarray, com.google.android.material.R.styleable.MaterialCardView_rippleColor);
        rippleColor = colorstatelist;
        if (colorstatelist == null)
        {
            rippleColor = ColorStateList.valueOf(MaterialColors.getColor(materialCardView, com.google.android.material.R.attr.colorControlHighlight));
        }
        setCardForegroundColor(MaterialResources.getColorStateList(materialCardView.getContext(), typedarray, com.google.android.material.R.styleable.MaterialCardView_cardForegroundColor));
        updateRippleColor();
        updateElevation();
        updateStroke();
        materialCardView.setBackgroundInternal(insetDrawable(bgDrawable));
        if (materialCardView.isClickable())
        {
            typedarray = getClickableForeground();
        } else
        {
            typedarray = foregroundContentDrawable;
        }
        fgDrawable = typedarray;
        materialCardView.setForeground(insetDrawable(typedarray));
    }

    void onMeasure(int i, int j)
    {
label0:
        {
label1:
            {
                if (clickableForegroundDrawable == null)
                {
                    break label0;
                }
                int i1 = checkedIconMargin;
                int k1 = checkedIconSize;
                int k = i - i1 - k1;
                i1 = j - i1 - k1;
                if (android.os.Build.VERSION.SDK_INT < 21)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    j = i1;
                    i = k;
                    if (!materialCardView.getUseCompatPadding())
                    {
                        break label1;
                    }
                }
                j = i1 - (int)Math.ceil(calculateVerticalBackgroundPadding() * 2.0F);
                i = k - (int)Math.ceil(calculateHorizontalBackgroundPadding() * 2.0F);
            }
            int l = checkedIconMargin;
            int l1 = i;
            int j1 = l;
            if (ViewCompat.getLayoutDirection(materialCardView) == 1)
            {
                j1 = i;
                l1 = l;
            }
            clickableForegroundDrawable.setLayerInset(2, l1, checkedIconMargin, j1, j);
        }
    }

    void setBackgroundOverwritten(boolean flag)
    {
        isBackgroundOverwritten = flag;
    }

    void setCardBackgroundColor(ColorStateList colorstatelist)
    {
        bgDrawable.setFillColor(colorstatelist);
    }

    void setCardForegroundColor(ColorStateList colorstatelist)
    {
        MaterialShapeDrawable materialshapedrawable = foregroundContentDrawable;
        if (colorstatelist == null)
        {
            colorstatelist = ColorStateList.valueOf(0);
        }
        materialshapedrawable.setFillColor(colorstatelist);
    }

    void setCheckable(boolean flag)
    {
        checkable = flag;
    }

    void setCheckedIcon(Drawable drawable)
    {
        checkedIcon = drawable;
        if (drawable != null)
        {
            drawable = DrawableCompat.wrap(drawable.mutate());
            checkedIcon = drawable;
            DrawableCompat.setTintList(drawable, checkedIconTint);
        }
        if (clickableForegroundDrawable != null)
        {
            drawable = createCheckedIconLayer();
            clickableForegroundDrawable.setDrawableByLayerId(com.google.android.material.R.id.mtrl_card_checked_layer_id, drawable);
        }
    }

    void setCheckedIconTint(ColorStateList colorstatelist)
    {
        checkedIconTint = colorstatelist;
        Drawable drawable = checkedIcon;
        if (drawable != null)
        {
            DrawableCompat.setTintList(drawable, colorstatelist);
        }
    }

    void setCornerRadius(float f)
    {
        setShapeAppearanceModel(shapeAppearanceModel.withCornerSize(f));
        fgDrawable.invalidateSelf();
        if (shouldAddCornerPaddingOutsideCardBackground() || shouldAddCornerPaddingInsideCardBackground())
        {
            updateContentPadding();
        }
        if (shouldAddCornerPaddingOutsideCardBackground())
        {
            updateInsets();
        }
    }

    void setProgress(float f)
    {
        bgDrawable.setInterpolation(f);
        MaterialShapeDrawable materialshapedrawable = foregroundContentDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setInterpolation(f);
        }
        materialshapedrawable = foregroundShapeDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setInterpolation(f);
        }
    }

    void setRippleColor(ColorStateList colorstatelist)
    {
        rippleColor = colorstatelist;
        updateRippleColor();
    }

    void setShapeAppearanceModel(ShapeAppearanceModel shapeappearancemodel)
    {
        shapeAppearanceModel = shapeappearancemodel;
        bgDrawable.setShapeAppearanceModel(shapeappearancemodel);
        MaterialShapeDrawable materialshapedrawable = bgDrawable;
        materialshapedrawable.setShadowBitmapDrawingEnable(materialshapedrawable.isRoundRect() ^ true);
        materialshapedrawable = foregroundContentDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setShapeAppearanceModel(shapeappearancemodel);
        }
        materialshapedrawable = foregroundShapeDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setShapeAppearanceModel(shapeappearancemodel);
        }
        materialshapedrawable = compatRippleDrawable;
        if (materialshapedrawable != null)
        {
            materialshapedrawable.setShapeAppearanceModel(shapeappearancemodel);
        }
    }

    void setStrokeColor(ColorStateList colorstatelist)
    {
        if (strokeColor == colorstatelist)
        {
            return;
        } else
        {
            strokeColor = colorstatelist;
            updateStroke();
            return;
        }
    }

    void setStrokeWidth(int i)
    {
        if (i == strokeWidth)
        {
            return;
        } else
        {
            strokeWidth = i;
            updateStroke();
            return;
        }
    }

    void setUserContentPadding(int i, int j, int k, int l)
    {
        userContentPadding.set(i, j, k, l);
        updateContentPadding();
    }

    void updateClickable()
    {
        Drawable drawable = fgDrawable;
        Object obj;
        if (materialCardView.isClickable())
        {
            obj = getClickableForeground();
        } else
        {
            obj = foregroundContentDrawable;
        }
        fgDrawable = ((Drawable) (obj));
        if (drawable != obj)
        {
            updateInsetForeground(((Drawable) (obj)));
        }
    }

    void updateContentPadding()
    {
        boolean flag;
        if (!shouldAddCornerPaddingInsideCardBackground() && !shouldAddCornerPaddingOutsideCardBackground())
        {
            flag = false;
        } else
        {
            flag = true;
        }
        float f;
        if (flag)
        {
            f = calculateActualCornerPadding();
        } else
        {
            f = 0.0F;
        }
        int i = (int)(f - getParentCardViewCalculatedCornerPadding());
        materialCardView.setAncestorContentPadding(userContentPadding.left + i, userContentPadding.top + i, userContentPadding.right + i, userContentPadding.bottom + i);
    }

    void updateElevation()
    {
        bgDrawable.setElevation(materialCardView.getCardElevation());
    }

    void updateInsets()
    {
        if (!isBackgroundOverwritten())
        {
            materialCardView.setBackgroundInternal(insetDrawable(bgDrawable));
        }
        materialCardView.setForeground(insetDrawable(fgDrawable));
    }

    void updateStroke()
    {
        foregroundContentDrawable.setStroke(strokeWidth, strokeColor);
    }

}
