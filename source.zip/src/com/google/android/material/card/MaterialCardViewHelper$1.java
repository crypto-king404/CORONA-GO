// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.android.material.card;

import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;

// Referenced classes of package com.google.android.material.card:
//            MaterialCardViewHelper

class this._cls0 extends InsetDrawable
{

    final MaterialCardViewHelper this$0;

    public int getMinimumHeight()
    {
        return -1;
    }

    public int getMinimumWidth()
    {
        return -1;
    }

    public boolean getPadding(Rect rect)
    {
        return false;
    }

    (Drawable drawable, int i, int j, int k, int l)
    {
        this$0 = MaterialCardViewHelper.this;
        super(drawable, i, j, k, l);
    }
}
